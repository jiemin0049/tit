package de.travelit.profileadmin.webservice;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService;

import de.travelit.profileadmin.model.mixer.CfgMixerList;

/**
 * http://localhost:8081/ProfileAdmin/webservice/Mixer?wsdl
 * @author zhang
 *
 */
@WebService
public interface MixerWebService {

    @WebMethod
    @WebResult(name = "answer")
    String sayHi(@WebParam(name = "name") String name);

    @WebMethod
    @WebResult(name = "cfgs")
    CfgMixerList getCfgs();

    @WebMethod
    @WebResult(name = "cfgs")
    CfgMixerList getCfgsWithMixerType(@WebParam(name = "mixerType") String mixerType);

}
