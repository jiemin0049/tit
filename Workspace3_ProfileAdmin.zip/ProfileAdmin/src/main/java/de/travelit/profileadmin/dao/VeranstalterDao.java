package de.travelit.profileadmin.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.transform.Transformers;
import org.springframework.stereotype.Repository;

import de.travelit.profileadmin.model.HicContactPerson;
import de.travelit.profileadmin.model.TourOperator;

@Repository
public class VeranstalterDao extends AbstractDao {

    @SuppressWarnings("unchecked")
    public List<TourOperator> getVeranstalterList(String shortname, String name) {
        //String sqlStr = "SELECT tourop, touropname, active FROM touroperator WHERE tourop ~* $$" + shortname + "$$ and touropname ~* $$" + name + "$$ ORDER BY tourop";
        Session session = getSession();

        Criterion c1 = Restrictions.ilike("tourop", "%" + shortname + "%");
        Criterion c2 = Restrictions.ilike("touropName", "%" + name + "%");

        // @formatter:off
        return (List<TourOperator>) session.createCriteria(TourOperator.class)
                                    .add(Restrictions.and(c1, c2)).addOrder(Order.asc("tourop"))
                                    .setProjection(Projections.projectionList()
                                           .add(Projections.property("tourop"), "tourop")
                                           .add(Projections.property("touropName"), "touropName")
                                           .add(Projections.property("active"), "active")
                                           .add(Projections.property("serviceCharge"), "serviceCharge"))
                                    .setResultTransformer(Transformers.aliasToBean(TourOperator.class))
                                    .list();
        // @formatter:on
    }

    public List<TourOperator> getActiveVeranstalterList() {
        Session session = getSession();
        Criterion c1 = Restrictions.eq("active", Boolean.TRUE);
        return (List<TourOperator>) session.createCriteria(TourOperator.class).add(c1).addOrder(Order.asc("tourop")).list();
    }

    public List<TourOperator> getVeranstalterList(List<String> touropList) {
        Session session = getSession();
        return (List<TourOperator>) session.createCriteria(TourOperator.class).add(Restrictions.in("tourop", touropList)).list();
    }

    public List<String> pickoutLineflight(List<String> touropList) {
        Session session = getSession();
        Criterion c1 = Restrictions.in("tourop", touropList);
        Criterion c2 = Restrictions.eq("serviceCharge", 2);
        return (List<String>) session.createCriteria(TourOperator.class).add(Restrictions.and(c1, c2)).setProjection(Projections.property("tourop")).list();
    }

    public TourOperator getVeranstalterByCode(String shortname) {
        Session session = getSession();
        return (TourOperator) session.get(TourOperator.class, shortname);
    }

    public HicContactPerson getHicContactPersonByCode(String shortname) {
        Session session = getSession();
        return (HicContactPerson) session.get(HicContactPerson.class, shortname);
    }

    public void save(TourOperator tourop) {
        persist(tourop);
    }

    public void save(HicContactPerson contactPerson) {
        persist(contactPerson);
    }

    public void update(TourOperator tourop) {
        Session session = getSession();
        session.merge(tourop);
    }

    public void update(HicContactPerson contactPerson) {
        Session session = getSession();
        session.merge(contactPerson);
    }
}
