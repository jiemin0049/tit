package de.travelit.profileadmin.dao;

import org.hibernate.Session;
import org.springframework.stereotype.Repository;

import de.travelit.profileadmin.model.HicContent;

@Repository
public class HicContentDao extends AbstractDao {

    public void createHicConent(HicContent hicContent) {
        persist(hicContent);
    }

    public HicContent readHicContent(int cfg) {
        Session session = getSession();
        HicContent hic = (HicContent) session.get(HicContent.class, cfg);
        if (null == hic) {
            hic = new HicContent();
            hic.setHotelContent(true);
            hic.setCatalog(true);
            hic.setClimate(true);
            hic.setVideo(true);
            hic.setContact(true);
            hic.setFacts(true);
            hic.setGeo(true);
        }
        return hic;
    }

    public void saveOrUpdateHicContent(HicContent hicContent) {
        getSession().saveOrUpdate(hicContent);
    }
}
