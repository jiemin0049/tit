package de.travelit.profileadmin.interceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import de.travelit.profileadmin.Constants;
import de.travelit.profileadmin.model.Authenticity;

/**
 * Avoid user write request directly on browser.
 *
 * @author zhang
 *
 */
public class ReadPermissionInterceptor extends HandlerInterceptorAdapter {

    private static final Logger LOGGER = Logger.getLogger(ReadPermissionInterceptor.class);

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {

        Authenticity auth = (Authenticity) request.getSession().getAttribute(Constants.SESSION_KEY_AUTHENTICITY);
        if (null != auth && (auth.getRoleId() == 1 || auth.getRoleId() == 32)) {
            return true;
        } else {
            if (auth == null) {
                LOGGER.fatal("Authenticity failed, logout!!!!");
                request.getRequestDispatcher("/sessiontimeout").forward(request, response);
                return false;
            } else {
                //Other roles can not read veranstalter list and va-set
                //This exception will be catched by GlobalDefaultExceptionHandler.java
                throw new UnsupportedOperationException(auth.getName() + " has no read veranstalter or veranstalter-set permission!");
            }
        }
    }
}
