package de.travelit.profileadmin.service;

import java.io.StringReader;
import java.math.BigInteger;
import java.util.List;

import javax.xml.bind.JAXB;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.google.common.base.Strings;
import com.google.common.collect.Lists;

import de.travelit.profileadmin.Constants;
import de.travelit.profileadmin.dao.AuthenticityDao;
import de.travelit.profileadmin.model.Authenticity;
import de.travelit.profileadmin.model.LmwebBackofficeAuthentication;

@Service
public class AuthenticityService {

    private static final Logger LOGGER = Logger.getLogger(AuthenticityService.class);

    @Autowired
    private AuthenticityDao authenticityDao;

    public Authenticity getAuthenticity(String name, String password) {
        return getAuth(name, password);
        //return authenticityDao.getAuthenticity(name, password);
    }

    private Authenticity getAuth(String name, String password) {
        Authenticity authenticity = new Authenticity();
        StringBuilder authUrl = new StringBuilder(System.getProperty("authentication_url").trim());
        authUrl.append("?multiCFG=1").append(Constants.AND).append("username=").append(name).append(Constants.AND).append("password=").append(password);
        String response = ServiceUtils.sendRequest(authUrl.toString());

        if (response.isEmpty()) {
            LOGGER.error("Can not get authentication response!");
            return authenticity;
        }

        LmwebBackofficeAuthentication backoffice = JAXB.unmarshal(new StringReader(response), LmwebBackofficeAuthentication.class);

        if ("OK".equalsIgnoreCase(backoffice.getStatus()) && "OK".equalsIgnoreCase(backoffice.getCode())) {
            authenticity.setName(backoffice.getUsername());
            authenticity.setFullName(backoffice.getUserFullname());
            List<String> cfgList = authenticity.getCfgList();
            String rbCfg = backoffice.getRbCFG();
            if (!Strings.isNullOrEmpty(rbCfg)) {
                cfgList.add(rbCfg);
            }

            String cfgAdd = backoffice.getRbAdditionalCFGs();
            if (!Strings.isNullOrEmpty(cfgAdd)) {
                Iterable<String> iterable = Constants.ON_COMMA_OMITEMPTY.split(cfgAdd);
                cfgList.addAll(Lists.newArrayList(iterable));
            }

            Integer role = backoffice.getUserRole();
            authenticity.setRoleId(getUserRightId(role));
        }

        return authenticity;
    }

    /**
     *
     * @param roleIdStr
     * @return
     */
    private int getUserRightId(Integer role) {
        if (role == 0) {
            return role;
        }

        /**
         * position 0 is 1, Travel_IT Admin, 3 - RB-Admin, 4 - Expedient, 5 - Applikation(neu).
         * @see Authenticity.java
         */
        int[] bitPositions = new int[] { 0, 3, 4, 5 };

        BigInteger bigInt = BigInteger.valueOf(role.intValue());
        for (int p : bitPositions) {
            if (bigInt.testBit(p)) {
                return (int) Math.pow(2, p);
            }
        }

        // return 16 - Expedient, expedient can do nothing.
        return 16;
    }

}
