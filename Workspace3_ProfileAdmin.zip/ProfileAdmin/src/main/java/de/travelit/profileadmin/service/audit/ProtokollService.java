package de.travelit.profileadmin.service.audit;

import java.beans.IntrospectionException;
import java.io.File;
import java.io.FileFilter;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Comparator;
import java.util.Date;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.opencsv.CSVWriter;
import com.opencsv.bean.BeanToCsv;
import com.opencsv.bean.ColumnPositionMappingStrategy;
import com.opencsv.bean.MappingStrategy;

import de.travelit.profileadmin.Constants;
import de.travelit.profileadmin.dao.ProtokollDao;
import de.travelit.profileadmin.model.Protokoll;
import de.travelit.profileadmin.model.ProtokollSearch;

@Service
@Transactional
public class ProtokollService {

    private static final Logger LOGGER = Logger.getLogger(ProtokollService.class);
    private static final String PROTOKOLL_FILE_PATTERN = "^(Protokoll.csv.)+(\\d{1,})$";
    private static final String PROTOKOLL_FILE = Constants.PROTOKOLL_FILENAME + Constants.DOT_CSV;

    @Autowired
    private ProtokollDao protokollDao;

    public List<Protokoll> search(ProtokollSearch search, int limit) {
        return protokollDao.list(search, limit);
    }

    public List<Protokoll> list(Integer offset, Integer maxResults) {
        return protokollDao.list(offset, maxResults);
    }

    public void backupAndCleanProtokoll(int days, String dir) {
        if (days <= 0) {
            LOGGER.fatal("Can not clean and backup protokolls, keep-days error!");
            return;
        }
        Calendar calendar = Calendar.getInstance();
        calendar.add(Calendar.DATE, -days);
        long time = calendar.getTimeInMillis();
        // Get midnight of the day
        Date d = new Date(time - time % (24 * 60 * 60 * 1000));
        String datetime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS").format(d);

        List<Protokoll> protokolls = protokollDao.getProtokolls(datetime);
        if (protokolls.isEmpty()) {
            return;
        }

        boolean successful = writeProtokollsToFile(protokolls, dir);
        if (successful) {
            protokollDao.cleanProtokoll(protokolls);
        }
    }

    private boolean writeProtokollsToFile(List<Protokoll> protokolls, String dir) {
        if (protokolls.isEmpty()) {
            return false;
        }

        try {
            File protokollFile = getFile(dir);
            writeFile(protokollFile, protokolls);
        } catch (IOException e) {
            LOGGER.fatal("Get protokoll file or write protokolls failed", e);
            return false;
        }
        return true;
    }

    /**
     * Get protokoll file in given directory.
     * There should some protokoll files, Protokoll.csv, Protokoll.csv.0 ... Protokoll.csv.n
     * If the Protokoll.csv is bigger than 10MB, change name like Protokoll.csv to Protokoll.csv.0,
     * ..., Protokoll.csv.n to Protokoll.csv.n+1 and create a new empty Protokoll.csv
     *
     * @param dir
     * @return
     * @throws IOException
     */
    private File getFile(String dir) throws IOException {
        File protokollFile = new File(dir + "/" + PROTOKOLL_FILE);
        if (!protokollFile.exists()) {
            protokollFile.createNewFile();
            return protokollFile;
        } else {
            if (protokollFile.length() < Constants.TEN_MB) {
                return protokollFile;
            } else {
                updateProtokollFileName(dir);
                File newFile = new File(protokollFile.getParentFile() + "/" + PROTOKOLL_FILE + ".0");
                FileUtils.moveFile(protokollFile, newFile);
                protokollFile.createNewFile();
                return protokollFile;
            }
        }
    }

    private void updateProtokollFileName(String dir) throws IOException {
        File root = new File(dir);

        File[] files = root.listFiles(new FileFilter() {
            @Override
            public boolean accept(File file) {
                return file.isFile() && file.getName().matches(PROTOKOLL_FILE_PATTERN);
            }
        });

        sortFiles(files);
        for (File f : files) {
            fileNamePlusOne(f);
        }
    }

    private void fileNamePlusOne(File file) throws IOException {
        String oldName = file.getName();
        int i = extractNumber(oldName);
        i += 1;
        File newFile = new File(file.getParentFile() + "/" + PROTOKOLL_FILE + "." + i);
        FileUtils.moveFile(file, newFile);
    }

    /**
     * Sort files to Protokoll.csv.n, Protokoll.csv.n-1, Protokoll.csv.n-2, Protokoll.csv.0
     *
     * @param files
     */
    private void sortFiles(File[] files) {
        Arrays.sort(files, new Comparator<File>() {
            @Override
            public int compare(File f1, File f2) {
                int i1 = extractNumber(f1.getName());
                int i2 = extractNumber(f2.getName());
                return i2 - i1;
            }
        });
    }

    private int extractNumber(String name) {
        int i = 0;
        try {
            int e = name.lastIndexOf('.');
            String number = name.substring(e + 1, name.length());
            i = Integer.parseInt(number);
        } catch (Exception e) {
            // Here should not happen!!!
            LOGGER.fatal("Compares protoll files failed", e);
        }
        return i;
    }

    private void writeFile(File protokollFile, List<Protokoll> protokolls) {
        try (CSVWriter fw = new CSVWriter(new FileWriter(protokollFile, true))) {
            ColumnPositionMappingStrategy<Protokoll> strategy = new ColumnPositionMappingStrategy<Protokoll>();
            strategy.setType(Protokoll.class);
            strategy.setColumnMapping(new String[] { "datetime", "operation", "tabelle", "field", "pk1", "pk2", "pk3", "oldValue", "newValue", "updateBy" });

            BeanToCsvWithoutHeader<Protokoll> bean = new BeanToCsvWithoutHeader<Protokoll>();
            LOGGER.info("Begin to write protokolls in file.");
            bean.write(strategy, fw, protokolls);
        } catch (IOException e) {
            LOGGER.fatal("Write protolls in file failed", e);
        }
    }

    /**
     * I did not find how does BeanToCsv(@see BeanToCsv) write a Csv file without header, so I create this class.
     *
     * @param <T> - Type of object that is being processed.
     */
    static class BeanToCsvWithoutHeader<T> extends BeanToCsv<T> {
        public BeanToCsvWithoutHeader() {
            super();
        }

        @Override
        protected String[] processObject(List<Method> getters, Object bean) throws IntrospectionException, IllegalAccessException, InvocationTargetException {
            List<String> values = new ArrayList<String>();
            for (Method getter : getters) {
                Object value = getter.invoke(bean, (Object[]) null);
                if (value == null) {
                    // Here is the difference to original code.
                    values.add("");
                } else {
                    values.add(value.toString());
                }
            }
            return values.toArray(new String[0]);
        }

        @Override
        protected String[] processHeader(MappingStrategy<T> mapper) throws IntrospectionException {
            return null;
        }
    }

}
