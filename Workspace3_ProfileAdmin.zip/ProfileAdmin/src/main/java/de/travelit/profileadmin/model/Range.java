package de.travelit.profileadmin.model;

/**
 * @author zhang
 */
public class Range {

    private int cfg;

    /** Veranstalter kuerze */
    private String code;

    /** Veranstalter name */
    private String name;

    /** Veranstalter active or not for a CFG */
    private boolean active;

    /** Veranstalter- cache: active or not */
    private boolean cache;

    /** Veranstalter- hub: active or not */
    private boolean hub;

    /** online durchbuchen */
    private boolean online;

    private int serviceCharge;

    private int lf_short;

    private int lf_middle;

    private int lf_long;

    public int getCfg() {
        return cfg;
    }

    public void setCfg(int cfg) {
        this.cfg = cfg;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public boolean getCache() {
        return cache;
    }

    public void setCache(boolean cache) {
        this.cache = cache;
    }

    public boolean getHub() {
        return hub;
    }

    public void setHub(boolean hub) {
        this.hub = hub;
    }

    public boolean getOnline() {
        return online;
    }

    public void setOnline(boolean online) {
        this.online = online;
    }

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

    public int getServiceCharge() {
        return serviceCharge;
    }

    public void setServiceCharge(int serviceCharge) {
        this.serviceCharge = serviceCharge;
    }

    public int getLf_short() {
        return lf_short;
    }

    public void setLf_short(int lf_short) {
        this.lf_short = lf_short;
    }

    public int getLf_middle() {
        return lf_middle;
    }

    public void setLf_middle(int lf_middle) {
        this.lf_middle = lf_middle;
    }

    public int getLf_long() {
        return lf_long;
    }

    public void setLf_long(int lf_long) {
        this.lf_long = lf_long;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((code == null) ? 0 : code.hashCode());
        result = prime * result + ((name == null) ? 0 : name.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        Range other = (Range) obj;
        if (code == null) {
            if (other.code != null)
                return false;
        } else if (!code.equals(other.code))
            return false;
        if (name == null) {
            if (other.name != null)
                return false;
        } else if (!name.equals(other.name))
            return false;
        return true;
    }

}
