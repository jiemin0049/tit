package de.travelit.profileadmin.model;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "auth")
@XmlAccessorType(XmlAccessType.PROPERTY)
public class LmwebBackofficeAuthentication {
    private String status;
    private String code;
    private String username;
    private String userFullname;
    private Integer userRole;
    private String userBumaTerminalId;
    private String userBumaTerminalPw;
    private Integer rbId;
    private String rbName;
    private String rbCFG;
    private String rbAgent;
    private String rbAdditionalCFGs;
    private String rbAdditionalAgents;
    private String rbLMwebPw;
    private Integer lmpWebserverPort;
    private String callcenterMode;
    private String rbGruppe;

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getUserFullname() {
        return userFullname;
    }

    public void setUserFullname(String userFullname) {
        this.userFullname = userFullname;
    }

    public Integer getUserRole() {
        return userRole;
    }

    public void setUserRole(Integer userRole) {
        this.userRole = userRole;
    }

    public String getRbCFG() {
        return rbCFG;
    }

    public void setRbCFG(String rbCFG) {
        this.rbCFG = rbCFG;
    }

    public String getRbAdditionalCFGs() {
        return rbAdditionalCFGs;
    }

    public void setRbAdditionalCFGs(String rbAdditionalCFGs) {
        this.rbAdditionalCFGs = rbAdditionalCFGs;
    }
}
