package de.travelit.profileadmin.webservice;

import javax.xml.ws.handler.LogicalHandler;
import javax.xml.ws.handler.LogicalMessageContext;
import javax.xml.ws.handler.MessageContext;

public class AddCustomizedPartHandler implements LogicalHandler<LogicalMessageContext> {

    @Override
    public boolean handleMessage(LogicalMessageContext context) {
        boolean outbound = (Boolean) context.get(MessageContext.MESSAGE_OUTBOUND_PROPERTY);

        if (outbound) {
            System.out.println("This is an outbound message");
        } else {
            System.out.println("This is an inbound message");
        }

        return true;
    }

    @Override
    public boolean handleFault(LogicalMessageContext context) {
        System.out.println("AddCustomizedPartHandler->handleFault(context) invoked");
        return true;
    }

    @Override
    public void close(MessageContext context) {
        System.out.println("AddCustomizedPartHandler->close(context) invoked");

    }

}