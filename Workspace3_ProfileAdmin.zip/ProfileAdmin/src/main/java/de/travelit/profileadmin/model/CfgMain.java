package de.travelit.profileadmin.model;

import java.sql.Date;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "cfg")
@XmlAccessorType(XmlAccessType.NONE)
public class CfgMain {
    @XmlAttribute(name = "id")
    private int cfgNumber;
    @XmlElement(name = "kunde")
    private String cfgName;
    private boolean cfgStatus;
    private int configMode;
    private Date licenceValidDate;
    private String cfgComment;
    private int layoutId;
    private boolean affiliates;
    private int maxdays;
    private String xpwp;
    private String bumaAgency;
    private String terminal;
    private String bumaPassword;
    private String terminalweb;
    private String passwordweb;
    private boolean hotelInfoCenter;
    private int reviewProvider;
    private boolean reviews;
    private String debitorenNr;
    private int cfgMainVasetOrHaupt;
    private String cfgMainVaset;
    private boolean opControl;
    private String inkasso;
    private String giataXmlUser;
    private String giataXmlpwd;
    private Date lastUpdate;

    public int getCfgNumber() {
        return cfgNumber;
    }

    public void setCfgNumber(int cfgNumber) {
        this.cfgNumber = cfgNumber;
    }

    public String getCfgName() {
        return cfgName;
    }

    public void setCfgName(String cfgName) {
        this.cfgName = cfgName;
    }

    public boolean isCfgStatus() {
        return cfgStatus;
    }

    public void setCfgStatus(boolean cfgStatus) {
        this.cfgStatus = cfgStatus;
    }

    public int getConfigMode() {
        return configMode;
    }

    public void setConfigMode(int configMode) {
        this.configMode = configMode;
    }

    public Date getLicenceValidDate() {
        return licenceValidDate;
    }

    public void setLicenceValidDate(Date licenceValidDate) {
        this.licenceValidDate = licenceValidDate;
    }

    public String getCfgComment() {
        return cfgComment;
    }

    public void setCfgComment(String cfgComment) {
        this.cfgComment = cfgComment;
    }

    public int getLayoutId() {
        return layoutId;
    }

    public void setLayoutId(int layoutId) {
        this.layoutId = layoutId;
    }

    public boolean isAffiliates() {
        return affiliates;
    }

    public void setAffiliates(boolean affiliates) {
        this.affiliates = affiliates;
    }

    public int getMaxdays() {
        return maxdays;
    }

    public void setMaxdays(int maxdays) {
        this.maxdays = maxdays;
    }

    public String getXpwp() {
        return xpwp;
    }

    public void setXpwp(String xpwp) {
        this.xpwp = xpwp;
    }

    public String getBumaAgency() {
        return bumaAgency;
    }

    public void setBumaAgency(String bumaAgency) {
        this.bumaAgency = bumaAgency;
    }

    public String getTerminal() {
        return terminal;
    }

    public void setTerminal(String terminal) {
        this.terminal = terminal;
    }

    public String getBumaPassword() {
        return bumaPassword;
    }

    public void setBumaPassword(String bumaPassword) {
        this.bumaPassword = bumaPassword;
    }

    public String getTerminalweb() {
        return terminalweb;
    }

    public void setTerminalweb(String terminalweb) {
        this.terminalweb = terminalweb;
    }

    public String getPasswordweb() {
        return passwordweb;
    }

    public void setPasswordweb(String passwordweb) {
        this.passwordweb = passwordweb;
    }

    public boolean isHotelInfoCenter() {
        return hotelInfoCenter;
    }

    public void setHotelInfoCenter(boolean hotelInfoCenter) {
        this.hotelInfoCenter = hotelInfoCenter;
    }

    public int getReviewProvider() {
        return reviewProvider;
    }

    public void setReviewProvider(int reviewProvider) {
        this.reviewProvider = reviewProvider;
    }

    public boolean isReviews() {
        return reviews;
    }

    public void setReviews(boolean reviews) {
        this.reviews = reviews;
    }

    public String getDebitorenNr() {
        return debitorenNr;
    }

    public void setDebitorenNr(String debitorenNr) {
        this.debitorenNr = debitorenNr;
    }

    public String getCfgMainVaset() {
        return cfgMainVaset;
    }

    public void setCfgMainVaset(String cfgMainVaset) {
        this.cfgMainVaset = cfgMainVaset;
    }

    public boolean isOpControl() {
        return opControl;
    }

    public void setOpControl(boolean opControl) {
        this.opControl = opControl;
    }

    public int getCfgMainVasetOrHaupt() {
        return cfgMainVasetOrHaupt;
    }

    public void setCfgMainVasetOrHaupt(int cfgMainVasetOrHaupt) {
        this.cfgMainVasetOrHaupt = cfgMainVasetOrHaupt;
    }

    public String getInkasso() {
        return inkasso;
    }

    public void setInkasso(String inkasso) {
        this.inkasso = inkasso;
    }

    public String getGiataXmlUser() {
        return giataXmlUser;
    }

    public void setGiataXmlUser(String giataXmlUser) {
        this.giataXmlUser = giataXmlUser;
    }

    public String getGiataXmlpwd() {
        return giataXmlpwd;
    }

    public void setGiataXmlpwd(String giataXmlpwd) {
        this.giataXmlpwd = giataXmlpwd;
    }

    public Date getLastUpdate() {
        return lastUpdate;
    }

    public void setLastUpdate(Date lastUpdate) {
        this.lastUpdate = lastUpdate;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }

        CfgMain other = (CfgMain) obj;
        if (cfgNumber == other.cfgNumber) {
            return true;
        }
        return false;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + (affiliates ? 1231 : 1237);
        result = prime * result + ((bumaAgency == null) ? 0 : bumaAgency.hashCode());
        result = prime * result + ((bumaPassword == null) ? 0 : bumaPassword.hashCode());
        result = prime * result + ((cfgComment == null) ? 0 : cfgComment.hashCode());
        result = prime * result + ((cfgMainVaset == null) ? 0 : cfgMainVaset.hashCode());
        result = prime * result + ((cfgName == null) ? 0 : cfgName.hashCode());
        result = prime * result + cfgNumber;
        result = prime * result + (cfgStatus ? 1231 : 1237);
        result = prime * result + (opControl ? 1231 : 1237);
        result = prime * result + configMode;
        result = prime * result + ((debitorenNr == null) ? 0 : debitorenNr.hashCode());
        result = prime * result + ((giataXmlUser == null) ? 0 : giataXmlUser.hashCode());
        result = prime * result + ((giataXmlpwd == null) ? 0 : giataXmlpwd.hashCode());
        result = prime * result + (hotelInfoCenter ? 1231 : 1237);
        result = prime * result + ((inkasso == null) ? 0 : inkasso.hashCode());
        result = prime * result + ((lastUpdate == null) ? 0 : lastUpdate.hashCode());
        result = prime * result + layoutId;
        result = prime * result + ((licenceValidDate == null) ? 0 : licenceValidDate.hashCode());
        result = prime * result + maxdays;
        result = prime * result + ((passwordweb == null) ? 0 : passwordweb.hashCode());
        result = prime * result + ((terminal == null) ? 0 : terminal.hashCode());
        result = prime * result + ((terminalweb == null) ? 0 : terminalweb.hashCode());
        result = prime * result + ((xpwp == null) ? 0 : xpwp.hashCode());
        return result;
    }

}