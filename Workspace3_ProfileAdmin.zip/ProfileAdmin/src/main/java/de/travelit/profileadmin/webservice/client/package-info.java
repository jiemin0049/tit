@javax.xml.bind.annotation.XmlSchema(namespace = "http://webservice.profileadmin.travelit.de/")
package de.travelit.profileadmin.webservice.client;
