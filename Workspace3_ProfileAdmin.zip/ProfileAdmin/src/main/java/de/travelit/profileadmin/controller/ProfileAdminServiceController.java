package de.travelit.profileadmin.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import de.travelit.profileadmin.model.CfgList;
import de.travelit.profileadmin.model.CfgMain;
import de.travelit.profileadmin.model.Hubva;
import de.travelit.profileadmin.service.CfgService;

/**
 * Provide some services for difference requests.
 *
 * @author zhang
 *
 */
@Controller
public class ProfileAdminServiceController {

    @Autowired
    private CfgService cfgService;

    @RequestMapping(value = "/cfgs")
    public @ResponseBody CfgList getActiveCfgList() {
        List<CfgMain> activeList = cfgService.getActiveCfgList();
        CfgList list = new CfgList();
        list.setCfgs(activeList);
        return list;
    }

    @RequestMapping(value = "/hubva")
    public @ResponseBody Hubva getHubvaList() {
        List<String> hubvaList = cfgService.getActiveHubvaList();
        Hubva hubva = new Hubva();
        hubva.setHubvaList(hubvaList);
        return hubva;
    }

    @RequestMapping(value = "/formdata/{cfg}")
    public @ResponseBody String getCfgTouroperator(@PathVariable("cfg") int cfg) {
        return cfgService.getCfgTouroperator(cfg);
    }

    @RequestMapping(value = "/formdata")
    public @ResponseBody String getCfgTouroperator() {
        return cfgService.getCfgTouroperator();
    }

}
