package de.travelit.profileadmin.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "valist_cfg")
public class ValistCfg implements Serializable {

    private static final long serialVersionUID = 7230951221416099045L;

    @EmbeddedId
    private ValistCfgPK valistCfgPK;

    @Column(name = "update_by")
    private String updateBy;

    public ValistCfgPK getValistCfgPK() {
        return valistCfgPK;
    }

    public void setValistCfgPK(ValistCfgPK valistCfgPK) {
        this.valistCfgPK = valistCfgPK;
    }

    public String getUpdateBy() {
        return updateBy;
    }

    public void setUpdateBy(String updateBy) {
        this.updateBy = updateBy;
    }

    @Embeddable
    public static class ValistCfgPK implements Serializable {

        private static final long serialVersionUID = -8616789009636365521L;
        private Integer cfg;
        private String code;

        public ValistCfgPK() {
        }

        public ValistCfgPK(Integer cfg, String code) {
            this.cfg = cfg;
            this.code = code;
        }

        public Integer getCfg() {
            return cfg;
        }

        public void setCfg(Integer cfg) {
            this.cfg = cfg;
        }

        public String getCode() {
            return code;
        }

        public void setCode(String code) {
            this.code = code;
        }

        @Override
        public int hashCode() {
            final int prime = 31;
            int result = 1;
            result = prime * result + ((cfg == null) ? 0 : cfg.hashCode());
            result = prime * result + ((code == null) ? 0 : code.hashCode());
            return result;
        }

        @Override
        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }

            if (obj == null) {
                return false;
            }

            if (getClass() != obj.getClass()) {
                return false;
            }

            ValistCfgPK other = (ValistCfgPK) obj;
            if (cfg == null) {
                if (other.cfg != null)
                    return false;
            } else if (!cfg.equals(other.cfg)) {
                return false;
            }

            if (code == null) {
                if (other.code != null)
                    return false;
            } else if (!code.equals(other.code)) {
                return false;
            }

            return true;
        }
    }

}
