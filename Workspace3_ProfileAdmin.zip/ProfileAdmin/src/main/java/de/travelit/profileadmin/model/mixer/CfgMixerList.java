package de.travelit.profileadmin.model.mixer;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "cfgs")
public class CfgMixerList implements Serializable {

    private static final long serialVersionUID = 4418121570493280862L;

    private List<CfgMixer> cfgs = new ArrayList<CfgMixer>();

    @XmlElement(name = "cfg")
    public List<CfgMixer> getCfgs() {
        return cfgs;
    }

    public void setCfgs(List<CfgMixer> cfgs) {
        this.cfgs = cfgs;
    }
}
