package de.travelit.profileadmin.model;

import java.util.HashSet;
import java.util.Set;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

@XmlRootElement(name = "cfg")
@XmlAccessorType(XmlAccessType.NONE)
public class CfgHic {

    @XmlAttribute
    private int id;

    @XmlElement
    private String kunde;

    @XmlTransient
    private Integer primaryCfg;

    @XmlElement
    private boolean status;

    @XmlElement
    private int provider;

    @XmlElement
    private boolean reviews;

    @XmlElement
    private boolean hotelInfoCenter;

    @XmlElement
    private String giataIhgUid = "";

    @XmlElement
    private String giataIhgXmlUser = "";

    @XmlElement
    private String giataIhgXmlPassword = "";

    @XmlElementWrapper(name = "veranstalters")
    @XmlElement(name = "veranstalter")
    private Set<String> veranstalters = new HashSet<>();

    @XmlElement
    private HicContent hicContent;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getKunde() {
        return kunde;
    }

    public void setKunde(String kunde) {
        this.kunde = kunde;
    }

    public Integer getPrimaryCfg() {
        return primaryCfg;
    }

    public void setPrimaryCfg(Integer primaryCfg) {
        this.primaryCfg = primaryCfg;
    }

    public boolean isStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }

    public int getProvider() {
        return provider;
    }

    public void setProvider(int provider) {
        this.provider = provider;
    }

    public boolean isReviews() {
        return reviews;
    }

    public void setReviews(boolean reviews) {
        this.reviews = reviews;
    }

    public boolean isHotelInfoCenter() {
        return hotelInfoCenter;
    }

    public void setHotelInfoCenter(boolean hotelInfoCenter) {
        this.hotelInfoCenter = hotelInfoCenter;
    }

    public String getGiataIhgUid() {
        return giataIhgUid;
    }

    public void setGiataIhgUid(String giataIhgUid) {
        this.giataIhgUid = giataIhgUid;
    }

    public String getGiataIhgXmlUser() {
        return giataIhgXmlUser;
    }

    public void setGiataIhgXmlUser(String giataIhgXmlUser) {
        this.giataIhgXmlUser = giataIhgXmlUser;
    }

    public String getGiataIhgXmlPassword() {
        return giataIhgXmlPassword;
    }

    public void setGiataIhgXmlPassword(String giataIhgXmlPassword) {
        this.giataIhgXmlPassword = giataIhgXmlPassword;
    }

    public Set<String> getVeranstalters() {
        return veranstalters;
    }

    public void setVeranstalters(Set<String> veranstalters) {
        this.veranstalters = veranstalters;
    }

    public HicContent getHicContent() {
        return hicContent;
    }

    public void setHicContent(HicContent hicContent) {
        this.hicContent = hicContent;
    }
}
