package de.travelit.profileadmin.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.common.base.Strings;

import de.travelit.profileadmin.Constants;
import de.travelit.profileadmin.model.Authenticity;
import de.travelit.profileadmin.model.HicContactPerson;
import de.travelit.profileadmin.model.TourOperator;
import de.travelit.profileadmin.service.VeranstalterService;

@Controller
public class VeranstalterController {

    private static final Logger LOGGER = Logger.getLogger(VeranstalterController.class);

    @Autowired
    private VeranstalterService vaService;

    @RequestMapping("begin_va_anlegen")
    public String vaanlegen(HttpServletRequest request) {
        return "va_anlegen1";
    }

    @RequestMapping(value = "va_anlegen_check_tourop", method = RequestMethod.POST)
    @ResponseBody
    public String veranstatlerAnlegenCheckTourop(@RequestParam(value = "tourop") String tourop, Model model) {
        if (Strings.isNullOrEmpty(tourop)) {
            return "Das Veranstalterkürzel darf nicht leer sein!";
        }

        if (vaService.getVeranstalterByCode(tourop) != null) {
            return "Das Veranstalterkürzel ist vorhanden!";
        }

        return "";
    }

    @RequestMapping(value = "va_anlegen1_save", method = RequestMethod.POST)
    public String veranstatlerSave(TourOperator op, HicContactPerson contactPerson, HttpServletRequest request, Model model) {
        Authenticity auth = (Authenticity) request.getSession().getAttribute(Constants.SESSION_KEY_AUTHENTICITY);
        vaService.save(auth.getName(), op, contactPerson);

        model.addAttribute("tourop", op);
        model.addAttribute("contactPerson", contactPerson);
        return "va_anlegen2";
    }

    @RequestMapping(value = "va_get_from_menu")
    public String veranstalterGetFromMenu(HttpServletRequest request) {
        request.getSession().removeAttribute("veranstalter_get_code");
        request.getSession().removeAttribute("veranstalter_get_name");
        request.getSession().removeAttribute("allOps");
        return "va_get";
    }

    @RequestMapping(value = "va_get", method = RequestMethod.POST)
    public String veranstalterGet(@RequestParam(value = "code") String pshortname, @RequestParam(value = "name") String pname, HttpServletRequest request, Model model) {

        String shortname = pshortname.trim();
        String name = pname.trim();

        request.getSession().setAttribute("veranstalter_get_code", shortname);
        request.getSession().setAttribute("veranstalter_get_name", name);

        List<TourOperator> touropList = vaService.getVeranstalterList(shortname, name);
        if (touropList.isEmpty()) {
            String errorMessage = "Veranstalter nicht gefunden!";
            LOGGER.error(errorMessage);

            model.addAttribute("va_get_error", errorMessage);
            return "va_get";
        }

        request.getSession().setAttribute("allOps", touropList);

        if (touropList.size() == 1) {
            return toVeranstalterSeeResult(touropList.get(0).getTourop(), model);
        }

        return "va_show_list";
    }

    @RequestMapping(value = "va_show_back", method = RequestMethod.POST)
    public String veranstalterShowBack() {
        return "va_get";
    }

    @RequestMapping(value = { "va_show_see", "va_change_back" }, method = RequestMethod.POST)
    public String veranstalterChangeBack(@RequestParam(value = "tourop") String code, Model model) {
        return toVeranstalterSeeResult(code, model);
    }

    private String toVeranstalterSeeResult(String code, Model model) {
        TourOperator op = vaService.getVeranstalterByCode(code);
        model.addAttribute("va_see_op", op);
        HicContactPerson person = vaService.getHicContactPersonByCode(code);
        model.addAttribute("va_see_contractperson", person);
        return "va_see_result";
    }

    @RequestMapping(value = { "va_see_result_back" }, method = RequestMethod.POST)
    public String veranstalterSeeBack(HttpServletRequest request) {
        List<TourOperator> touropList = (List<TourOperator>) request.getSession().getAttribute("allOps");
        if (touropList.size() == 1) {
            return "va_get";
        }

        return "va_show_list";
    }

    @RequestMapping(value = "va_change", method = RequestMethod.POST)
    public String veranstalterShowChange(@RequestParam(value = "tourop") String vacode, Model model) {
        TourOperator op = vaService.getVeranstalterByCode(vacode);
        model.addAttribute("va_change_op", op);
        HicContactPerson person = vaService.getHicContactPersonByCode(vacode);
        model.addAttribute("va_change_contractperson", person);
        return "va_change";
    }

    @RequestMapping(value = "va_change_save", method = RequestMethod.POST)
    public String veranstalterUpdate(TourOperator tourOperator, HicContactPerson contactPerson, BindingResult result, HttpServletRequest request, Model model) {
        Authenticity auth = (Authenticity) request.getSession().getAttribute(Constants.SESSION_KEY_AUTHENTICITY);
        vaService.update(auth.getName(), tourOperator, contactPerson);
        String tourop = tourOperator.getTourop();
        String name = tourOperator.getTouropName();

        //MAYBE a Veranstalter name is changed, here refresh the list.
        List<TourOperator> touropList = (List<TourOperator>) request.getSession().getAttribute("allOps");
        for (TourOperator t : touropList) {
            if (t.getTourop().equals(tourop)) {
                t.setTouropName(name);
                break;
            }
        }

        model.addAttribute("dialog_title", "Change Veranstalter");
        model.addAttribute("dialog_message", "Veranstalter [<b>" + tourop + ": " + name + "</b>] is changed!");
        model.addAttribute("tourop", tourop);

        return "va_change_success_dialog";
    }

}
