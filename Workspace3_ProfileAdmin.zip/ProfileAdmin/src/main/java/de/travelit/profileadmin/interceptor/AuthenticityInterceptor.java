package de.travelit.profileadmin.interceptor;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import de.travelit.profileadmin.Constants;
import de.travelit.profileadmin.model.Authenticity;

/**
 * Check whether user is login.
 *
 * @author zhang
 *
 */
public class AuthenticityInterceptor extends HandlerInterceptorAdapter {

    private static final Logger LOGGER = Logger.getLogger(AuthenticityInterceptor.class);

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {

        Authenticity auth = (Authenticity) request.getSession().getAttribute(Constants.SESSION_KEY_AUTHENTICITY);
        if (null == auth) {
            LOGGER.fatal("Authenticity failed, redirect to login page!!!!");
            try {
                //response.sendRedirect("sessiontimeout");
                request.getRequestDispatcher("/sessiontimeout").forward(request, response);
                return false;
            } catch (IOException e) {
                LOGGER.fatal("Authenticity failed, redirect failed!!!!");
            }
        }
        return true;
    }
}
