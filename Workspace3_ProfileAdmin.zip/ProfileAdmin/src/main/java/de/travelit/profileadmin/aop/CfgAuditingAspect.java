package de.travelit.profileadmin.aop;

import java.util.List;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.beans.factory.annotation.Autowired;

import com.google.common.collect.ListMultimap;

import de.travelit.profileadmin.service.audit.CfgAuditService;

/**
 * Audit database table changing. Class audits only for delete and insert
 * records of tables. Table updating is audited by db trigger.
 *
 * @author zhang
 *
 */
@Aspect
public class CfgAuditingAspect extends DataAuditingAspect {

    @Autowired
    private CfgAuditService cfgAuditService;

    public CfgAuditingAspect() {
        super();
    }

    /**
     * Only intercept 2 methods "removeVasetFromValistCfg" and "removeVaaktivCfgs",
     * if add remove method, please correct this pointcut.
     */
    @Pointcut(" execution(* de.travelit.profileadmin.service.CfgService.remove*(..))")
    public void loggingRemove() {
    }

    @After("loggingRemove()&& args(cfgId, vasetList)")
    public void removeVasetAdvice(JoinPoint joinPoint, int cfgId, List<String> vasetList) {
        String tableName = "Error! Check CfgAutditingAspect!";
        String methodName = joinPoint.getSignature().getName();
        if ("removeVasetFromValistCfg".equals(methodName)) {
            tableName = "valist_cfg";
        } else if ("removeVaaktivCfgs".equals(methodName)) {
            tableName = "va_aktiv_cfgs";
        }
        cfgAuditService.logRemoveVasetFromCfg(getAuthName(), cfgId, tableName, vasetList);
    }

    @After(" execution(* de.travelit.profileadmin.service.CfgService.insertValistCfg(..)) && args(cfgId,vasetList)")
    public void insertValistCfgAdvice(int cfgId, List<String> vasetList) {
        cfgAuditService.logInsertValistCfg(getAuthName(), cfgId, vasetList);
    }

    @After(" execution(* de.travelit.profileadmin.service.CfgService.insertVaaktivCfgs(..)) && args(cfgId,vasetList,..)")
    public void insertVaaktivCfgsAdvice(int cfgId, final List<String> vasetList) {
        cfgAuditService.logInsertVaaktivCfgs(getAuthName(), cfgId, vasetList);
    }

    @After(" execution(* de.travelit.profileadmin.service.CfgService.insertLinienflugProvisionen(..)) && args(cfgKeys,insertMap)")
    public void insertLinienflugProvisionenAdvice(List<Integer> cfgKeys, final ListMultimap<String, String> insertMap) {
        cfgAuditService.logInsertLinienflugProvisionen(getAuthName(), cfgKeys, insertMap);
    }

    @After("loggingRemove()&& args(cfgKeys, opList)")
    public void removeLinienflugProvisionenAdvice(List<Integer> cfgKeys, List<String> opList) {
        cfgAuditService.logRemoveLinienflugProvisionen(getAuthName(), cfgKeys, opList);
    }
}
