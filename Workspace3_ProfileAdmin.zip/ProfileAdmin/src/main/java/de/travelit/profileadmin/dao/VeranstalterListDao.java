package de.travelit.profileadmin.dao;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map.Entry;
import java.util.Set;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.support.rowset.SqlRowSet;
import org.springframework.stereotype.Repository;

import com.google.common.collect.SetMultimap;

import de.travelit.profileadmin.Constants;
import de.travelit.profileadmin.model.Range;
import de.travelit.profileadmin.model.TourOperator;
import de.travelit.profileadmin.model.TouropList;

@Repository
public class VeranstalterListDao {

    private static final Logger LOGGER = Logger.getLogger(VeranstalterListDao.class);

    @Autowired
    private JdbcTemplate jdbcTemplate;

    public int getVeranstalterSetCountBy(final String shortname) {
        String sqlStr = "SELECT count(*) FROM touroplist WHERE code =?";
        return jdbcTemplate.queryForObject(sqlStr, new Object[] { shortname }, Integer.class);
    }

    /**
     * Get cfg list by given vaset id.
     * @param code vaset id.
     * @return
     */
    public List<String> getCfgListBy(String code) {
        String sqlStr = "SELECT cfg FROM valist_cfg WHERE code =$$" + code + "$$";
        return jdbcTemplate.queryForList(sqlStr, String.class);
    }

    public List<TouropList> getVeranstalterSetList(String shortname, String name) {
        List<TouropList> tourOpList = new ArrayList<>();
        String sqlStr = "SELECT code, name FROM touroplist WHERE code ~*'" + shortname + "' and name ~*'" + name + "' ORDER BY code";
        SqlRowSet rowSet = jdbcTemplate.queryForRowSet(sqlStr);
        while (rowSet.next()) {
            TouropList op = new TouropList();
            op.setCode(rowSet.getString("code"));
            op.setName(rowSet.getString("name"));
            tourOpList.add(op);
        }
        return tourOpList;
    }

    public int vasetsCount(Set<String> vasetSet) {
        if (vasetSet.isEmpty()) {
            return 0;
        }
        StringBuilder sb = new StringBuilder("SELECT count(*) FROM  touroplist WHERE ");
        String prefix = " ";
        for (String vaset : vasetSet) {
            sb.append(prefix).append("code=").append("$$" + vaset + "$$");
            prefix = " OR ";
        }
        return jdbcTemplate.queryForObject(sb.toString(), Integer.class);
    }

    public List<TourOperator> getTourOperatorsBySetcodeList(Set<String> codes) {
        List<TourOperator> tourOpList = new ArrayList<>();
        if (codes.isEmpty()) {
            return tourOpList;
        }

        StringBuilder sb = new StringBuilder();
        sb.append("SELECT DISTINCT op.* FROM touroperator op, valist va WHERE va.vacode=op.tourop AND (");
        String prefix = " ";
        for (String code : codes) {
            sb.append(prefix).append("va.code=").append("$$" + code + "$$");
            prefix = " OR ";
        }
        sb.append(") ORDER BY op.tourop");
        String sqlStr = sb.toString();
        SqlRowSet rowSet = jdbcTemplate.queryForRowSet(sqlStr);
        while (rowSet.next()) {
            TourOperator op = new TourOperator();
            op.setTourop(rowSet.getString("tourop"));
            op.setTouropName(rowSet.getString("touropname"));
            op.setActive(rowSet.getBoolean("active"));
            op.setServiceCharge(rowSet.getInt("servicecharge"));
            tourOpList.add(op);
        }

        return tourOpList;
    }

    public List<Range> getRangesBySetcodeList(Set<String> codes) {
        List<Range> rangeList = new ArrayList<>();
        if (codes.isEmpty()) {
            return rangeList;
        }

        StringBuilder sb = new StringBuilder();
        sb.append("SELECT DISTINCT op.* FROM touroperator op, valist va WHERE va.vacode=op.tourop AND (");
        String prefix = " ";
        for (String code : codes) {
            sb.append(prefix).append("va.code=").append("$$" + code + "$$");
            prefix = " OR ";
        }
        sb.append(") ORDER BY op.tourop");
        String sqlStr = sb.toString();
        SqlRowSet rowSet = jdbcTemplate.queryForRowSet(sqlStr);
        while (rowSet.next()) {
            Range range = new Range();
            range.setCode(rowSet.getString("tourop"));
            range.setName(rowSet.getString("touropname"));
            range.setServiceCharge(rowSet.getInt("servicecharge"));
            range.setHub(rowSet.getBoolean("source_hub"));
            range.setCache(rowSet.getBoolean("source_cache"));
            range.setLf_short(20);
            range.setLf_middle(30);
            range.setLf_long(40);
            range.setOnline(false);
            rangeList.add(range);
        }

        return rangeList;
    }

    public List<Range> getRangesBySetcodeList(String cfgId, List<String> codes) {
        List<Range> rangeList = new ArrayList<>();
        StringBuilder valistCfgSql = new StringBuilder("SELECT DISTINCT op.tourop, op.touropname, vaac.active, op.source_cache, op.source_hub, vaac.bookonline, op.servicecharge , lf_short, lf_middle, lf_long ");
        valistCfgSql.append(" FROM valist_cfg vc JOIN valist v ON (");
        String delimiter = " ";
        for (String vacode : codes) {
            valistCfgSql.append(delimiter).append("v.code=").append("$$" + vacode + "$$");
            delimiter = " OR ";
        }
        valistCfgSql.append(") AND vc.cfg=").append(cfgId).append(" JOIN touroperator op ON v.vacode=op.tourop ")
                    .append("LEFT JOIN lineflight_cfg lf ON lf.tourop = op.tourop AND lf.cfg=vc.cfg ")
                    .append("LEFT JOIN va_aktiv_cfgs vaac ON vc.cfg = vaac.cfg and v.vacode=vaac.tourop ORDER BY op.tourop");

        SqlRowSet rowSet = jdbcTemplate.queryForRowSet(valistCfgSql.toString());
        while (rowSet.next()) {
            Range range = new Range();
            range.setCode(rowSet.getString("tourop"));
            range.setName(rowSet.getString("touropname"));
            range.setActive(rowSet.getBoolean("active"));
            range.setHub(rowSet.getBoolean("source_hub"));
            range.setCache(rowSet.getBoolean("source_cache"));
            range.setOnline(rowSet.getBoolean("bookonline"));
            range.setServiceCharge(rowSet.getInt("servicecharge"));
            range.setLf_short(rowSet.getObject("lf_short") == null ? 30 : rowSet.getInt("lf_short"));
            range.setLf_middle(rowSet.getObject("lf_middle") == null ? 40 : rowSet.getInt("lf_middle"));
            range.setLf_long(rowSet.getObject("lf_long") == null ? 50 : rowSet.getInt("lf_long"));
            rangeList.add(range);
        }

        return rangeList;
    }

    public void removeAllOperatorsBySet(String code) {
        String sqlStr = "DELETE FROM valist WHERE code= '" + code + "'";
        jdbcTemplate.update(sqlStr);
    }

    public void removeOperator(String vacode) {
        String sqlStr = "DELETE FROM valist WHERE vacode= '" + vacode + "'";
        jdbcTemplate.update(sqlStr);
    }

    public void removeOperatorsFor(String code, List<String> list) {
        //Delete FROM valist WHERE code='AT' and vacode ='TUIA' or code='AT' and vacode='OGO' ...
        StringBuilder sb = new StringBuilder("Delete FROM valist WHERE ");
        String delimiter = " ";
        for (String s : list) {
            sb.append(delimiter).append("code=").append("$$" + code + "$$").append(" AND ").append("vacode=").append("$$" + s + "$$");
            delimiter = " OR ";
        }
        jdbcTemplate.update(sb.toString());
    }

    public List<String> getVacodeListByCode(String code) {
        String sqlStr = "SELECT vacode FROM valist WHERE code= '" + code + "'";
        return jdbcTemplate.queryForList(sqlStr, String.class);
    }

    public List<String> getCodeListByVacode(String vacode) {
        String sqlStr = "SELECT code FROM valist WHERE vacode= '" + vacode + "'";
        return jdbcTemplate.queryForList(sqlStr, String.class);
    }

    public List<String> getVaCodeList(List<String> vasetList) {
        if (vasetList.isEmpty()) {
            LOGGER.error("Cound not get Veranstalter-Set!");
            return new ArrayList<String>();
        }

        String delimiter = " ";
        StringBuilder valistSql = new StringBuilder("SELECT vacode FROM valist WHERE ");
        for (String vasetCode : vasetList) {
            valistSql.append(delimiter).append("code=$$").append(vasetCode).append("$$ ");
            delimiter = " OR ";
        }
        valistSql.append("ORDER BY code, vacode");

        return (List<String>) jdbcTemplate.queryForList(valistSql.toString(), String.class);
    }

    public void insertValist(final String shortname, String name) {
        String sql = "INSERT INTO touroplist (code, name) VALUES (?, ?)";
        jdbcTemplate.update(sql, new Object[] { shortname, name });
    }

    /**
     * Get tourop list by given cfg number.
     * @return
     */
    public List<String> getTouropByCfgNumber(String cfgNumber) {
        String sqlStr = "SELECT tourop FROM va_aktiv_cfgs WHERE cfg =$$" + cfgNumber + "$$";
        return jdbcTemplate.queryForList(sqlStr, String.class);
    }

    public void deleteTourop(SetMultimap<String, String> cfgVacodesMap) {
        if (cfgVacodesMap.size() == 0) {
            return;
        }

        //Delete FROM va_aktiv_cfgs WHERE cfg=500 and (tourop ='TUIA' or tourop="4U") or cfg=500 and (tourop='OGO' or tourop='5VF')
        StringBuilder sb = new StringBuilder("Delete FROM va_aktiv_cfgs WHERE ");
        String delimiter = " ";
        for (Entry<String, Collection<String>> entry : cfgVacodesMap.asMap().entrySet()) {
            String cfg = entry.getKey();
            Collection<String> touropCollection = entry.getValue();
            sb.append(delimiter).append("cfg=").append(cfg).append(" AND (");
            String delimter2 = " ";
            for (String op : touropCollection) {
                sb.append(delimter2).append("tourop=$$").append(op).append("$$ ");
                delimter2 = " OR ";
            }
            sb.append(") ");
            delimiter = " OR ";
        }
        jdbcTemplate.update(sb.toString());
    }

    public void insertTourop(SetMultimap<String, TourOperator> cfgVacodesMap) {
        if (cfgVacodesMap.size() == 0) {
            return;
        }

        StringBuilder sb = new StringBuilder("INSERT INTO va_aktiv_cfgs (cfg,tourop,bookonline,active) VALUES ");
        String delimiter = " ";
        // Prepare batch insert
        for (Entry<String, Collection<TourOperator>> entry : cfgVacodesMap.asMap().entrySet()) {
            String cfg = entry.getKey();
            Collection<TourOperator> touropCollection = entry.getValue();
            for (TourOperator op : touropCollection) {
                sb.append(delimiter).append("(").append(cfg).append(", $$").append(op.getTourop()).append("$$,FALSE,FALSE)");
                delimiter = Constants.COMMA;
            }
        }
        jdbcTemplate.update(sb.toString());
    }

    public void changeName(final String user, final String code, String name) {
        String sql = "UPDATE  touroplist SET name=?, update_by=? where code=?";
        jdbcTemplate.update(sql, new Object[] { name, user, code });
    }

    public void removeFromValist(final String code) {
        String sqlStr = "DELETE FROM touroplist WHERE code= '" + code + "'";
        jdbcTemplate.update(sqlStr);
    }

    public void insertValistWith(String code, final List<String> vacodeList) {
        StringBuilder sb = new StringBuilder("INSERT INTO valist (code, vacode) VALUES ");
        String delimiter = " ";
        // Prepare batch insert
        for (String s : vacodeList) {
            sb.append(delimiter).append("($$").append(code).append("$$, $$").append(s).append("$$)");
            delimiter = Constants.COMMA;
        }
        jdbcTemplate.update(sb.toString());
    }
}
