package de.travelit.profileadmin.service;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.io.FileUtils;
import org.apache.commons.mail.Email;
import org.apache.commons.mail.EmailException;
import org.apache.commons.mail.SimpleEmail;
import org.apache.log4j.Logger;
import org.ini4j.Wini;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.google.common.base.Joiner;
import com.google.common.base.Strings;
import com.google.common.collect.ListMultimap;

import de.travelit.profileadmin.Constants;
import de.travelit.profileadmin.dao.ProfileIniDao;
import de.travelit.profileadmin.model.profile.PrfCfg;
import de.travelit.profileadmin.model.profile.PrfHoteloDest;
import de.travelit.profileadmin.model.profile.PrfLineFlight;
import de.travelit.profileadmin.model.profile.PrfServiceCharge;
import de.travelit.profileadmin.model.profile.PrfVaaktiv;

@Service
public class ProfileIniService {

    private static final Logger LOGGER = Logger.getLogger(ProfileIniService.class);

    @Autowired
    private ProfileIniDao profileDao;

    public void writeProfile(String profile) {
        boolean profileChange = profileDao.getStatus();
        if (!profileChange) {
            return;
        }

        File profileFile = new File(profile);
        Wini iniFile = null;
        try {
            //Clean old content or create file if not exist.
            FileOutputStream outputStream = FileUtils.openOutputStream(profileFile, false);
            outputStream.close();
            iniFile = new Wini(profileFile);
            iniFile.getConfig().setStrictOperator(true); //without spaces
            iniFile.getConfig().setFileEncoding(Charset.forName("ISO-8859-1"));
        } catch (IOException e) {
            String msg = "Init Profile.ini writer failed!";
            LOGGER.error(msg, e);
            sendEmail(msg, e);
            return;
        }

        profileDao.setStatus(false);

        Map<String, Object> all = profileDao.getAllActiveProfile();
        List<PrfCfg> prfcfgList = (List<PrfCfg>) all.get("cfg");
        ListMultimap<Integer, PrfHoteloDest> prfHoteloDestMap = (ListMultimap<Integer, PrfHoteloDest>) all.get("hoteloDest");
        ListMultimap<Integer, PrfServiceCharge> prfServiceChargeMap = (ListMultimap<Integer, PrfServiceCharge>) all.get("serviceCharge");
        ListMultimap<Integer, PrfLineFlight> prfLineFlightMap = (ListMultimap<Integer, PrfLineFlight>) all.get("lineFlight");
        ListMultimap<Integer, PrfVaaktiv> prfVaaktivMap = (ListMultimap<Integer, PrfVaaktiv>) all.get("vaaktiv");

        LOGGER.info("Begin to write Profile.ini");
        Map<String, String> prfMap = new LinkedHashMap<>();
        prfMap.put("MAX", "1200");
        prfMap.put("MAXDAYS", "56");
        writeSection(iniFile, "PRF", prfMap);

        List<String> allActiveCacheOps = profileDao.getAllactiveCacheVeranstalterCode();

        for (PrfCfg cfg : prfcfgList) {
            int cfgNr = cfg.getCfg();
            Map<String, String> cfgMap = new LinkedHashMap<>();

            List<PrfVaaktiv> prfVaaktivList = prfVaaktivMap.removeAll(cfgNr);
            StringBuilder caches = new StringBuilder();
            StringBuilder hubs = new StringBuilder();
            StringBuilder bookonlines = new StringBuilder();

            //https://redmine.travel-it.com/redmine/issues/7658#note-4
            // There are also 2 kinds of VAs which should be write in VA negative list:
            // 1. Active Cache-VAs which are not in VA-SETs of this CFG, or Cache-VAs is inactive in VA-Sortiement TAB.
            // 2. Inactive VAs
            // Type 1 should write in all CFGs, Additionally type 2 should write in CFG 0.

            if (cfgNr == 0) {
                writeCachesHubsBookonlines(prfVaaktivList, allActiveCacheOps, caches, hubs, bookonlines);
                cfgMap.put("NAME", cfg.getName());
                cfgMap.put("ACTIVE", cfg.isStatus() ? "1" : "0");
                cfgMap.put("PASSWD", cfg.getPassword());
                cfgMap.put("TERMINAL", cfg.getTerminal());

                List<String> allInactiveOps = profileDao.getAllInactiveVeranstalterCode();
                String inactive = Joiner.on(Constants.BACK_SLASH).join(allInactiveOps);
                caches.append(inactive).append(Constants.BACK_SLASH);
                cfgMap.put("VA", caches.toString());
                cfgMap.put("VA_HUB", hubs.toString());

                String sectionName = "PRF_" + cfgNr;
                writeSection(iniFile, sectionName, cfgMap);
                continue;
            }

            cfgMap.put("NAME", cfg.getName());
            cfgMap.put("EMAIL", cfg.getEmail());
            cfgMap.put("GIATA_UID", cfg.getGiataIhgUid());
            cfgMap.put("AGENTUR", cfg.getBumaAgency());
            cfgMap.put("TERMINAL", cfg.getTerminal());
            cfgMap.put("PASSWD", cfg.getPassword());
            cfgMap.put("TERMINALWEBMODE", cfg.getTerminalweb());
            cfgMap.put("PASSWDWEBMODE", cfg.getPasswordweb());
            cfgMap.put("CONFIGMODE", cfg.getConfigmode() + "");
            cfgMap.put("ERV", cfg.getErv() + "");
            cfgMap.put("SUNNY", "5"); //sunny 3 or 5?
            cfgMap.put("MAILFMT", "1"); //MAILFMT=1
            int layoutId = cfg.getLayoutId();
            cfgMap.put("LAYOUTID", layoutId + "");
            cfgMap.put("AGENTS", cfg.isAffiliates() ? "1" : "0");
            if (layoutId == 2) {
                cfgMap.put("XPWP", cfg.getXpwp());
                cfgMap.put("XML", "1"); //XML=1
            }
            //cfgMap.put("INKASSO", cfg.getInkasso());
            cfgMap.put("ONREQUEST", cfg.isOnrequest() ? "1" : "0");

            Integer primaryCfg = cfg.getPrimaryCfg();
            if (primaryCfg == null) {
                cfgMap.put("VONMIN", cfg.getFromMin() + "");
                cfgMap.put("VONPLUS1", cfg.getFromMin1());
                cfgMap.put("ONLINE", cfg.getOnline() + "");
                cfgMap.put("ONLINE_TILL", cfg.getOnlineTill());
                cfgMap.put("BOOKBIS", cfg.getBookto() + "");
            }

            cfgMap.put("RB_AGB", cfg.getOtagtc());
            cfgMap.put("HOTELINFOBOX", cfg.isHotelInfoCenter() ? "1" : "0");
            cfgMap.put("VASTEUERUNG", cfg.isOpControl() ? "1" : "0");
            cfgMap.put("GROUPANG", "1"); //GROUPANG=1
            cfgMap.put("ORTFILTER", "1"); //ORTFILTER=1
            cfgMap.put("MAX_PREISDIFF", cfg.getMaxPricediff() + "");
            cfgMap.put("MAXDAYS", cfg.getMaxdays() + "");

            StringBuilder hoteloBuilder = new StringBuilder();
            hoteloBuilder.append("G/").append(cfg.getMainPercentage()).append(Constants.COMMA).append("M/").append(cfg.getMainFix());
            List<PrfHoteloDest> prfHoteloList = prfHoteloDestMap.removeAll(cfgNr);
            for (PrfHoteloDest hotelo : prfHoteloList) {
                String dest3lc = hotelo.getDest3lc();
                if (null == dest3lc) {
                    LOGGER.error("Hotelo info not found with CFG " + cfgNr);
                    continue;
                }
                hoteloBuilder.append(Constants.COMMA).append(dest3lc).append(Constants.BACK_SLASH).append(hotelo.getPercentageLow()).append(Constants.BACK_SLASH)
                             .append(hotelo.getPercentageMiddle()).append(Constants.BACK_SLASH).append(hotelo.getPercentageHigh());
            }
            cfgMap.put("HOT_CALC", hoteloBuilder.toString());

            //If a CFG has a primary CFG, don't need to write VA, VA_HUB, ONLINE_VA and Charterflug-Provisionen of the CFG into Profile.ini
            if (primaryCfg != null) {
                cfgMap.put("HAUPTCFG", primaryCfg.toString());
            } else {
                List<PrfServiceCharge> prfServiceChargeList = prfServiceChargeMap.removeAll(cfgNr);
                for (PrfServiceCharge srv : prfServiceChargeList) {
                    String tourop = srv.getTourop();
                    if (null == tourop) {
                        LOGGER.error("Charterflug-Provsionen not found with CFG " + cfgNr);
                        continue;
                    }
                    //Ticket 9050
                    if (tourop.equals("BCH")) {
                        cfgMap.put("SG_" + tourop, Constants.BCH_SERVICE_CHARGE.get(srv.getScshort()) + ";" + Constants.BCH_SERVICE_CHARGE.get(srv.getScmiddle()) + ";" + Constants.BCH_SERVICE_CHARGE.get(srv.getSclong()));
                        continue;
                    }

                    cfgMap.put("SG_" + tourop, srv.getScshort() + ";" + srv.getScmiddle() + ";" + srv.getSclong());
                }

                List<PrfLineFlight> prfLineFlightList = prfLineFlightMap.removeAll(cfgNr);
                for (PrfLineFlight srv : prfLineFlightList) {
                    String tourop = srv.getTourop();
                    if (null == tourop) {
                        LOGGER.error("Linienflug-Provsionen not found with CFG " + cfgNr);
                        continue;
                    }
                    cfgMap.put("SG_" + tourop, srv.getLfshort() + ";" + srv.getLfmiddle() + ";" + srv.getLflong());
                }

                writeCachesHubsBookonlines(prfVaaktivList, allActiveCacheOps, caches, hubs, bookonlines);
                cfgMap.put("VA", caches.toString());
                cfgMap.put("VA_HUB", hubs.toString());
                cfgMap.put("ONLINE_VA", bookonlines.toString());
            }

            cfgMap.put("CMDSET", "1"); //CMDSET=1
            cfgMap.put("ACTIVE", cfg.isStatus() ? "1" : "0");
            cfgMap.put("TUI_AGENCYNUMBER", cfg.getTuiAgencyNumber());
            cfgMap.put("AGENCYNUMBER", cfg.getAgencyNumber());

            String sectionName = "PRF_" + cfgNr;
            writeSection(iniFile, sectionName, cfgMap);
        }
    }

    private void writeCachesHubsBookonlines(List<PrfVaaktiv> prfVaaktivList, List<String> allActiveOpList,
                                            StringBuilder caches, StringBuilder hubs, StringBuilder bookonlines) {
        List<String> tempOpList = new ArrayList<>();
        for (PrfVaaktiv va : prfVaaktivList) {
            String op = va.getTourop();
            tempOpList.add(op);
            if (Strings.isNullOrEmpty(op)) {
                continue;
            }

            //Cache is negative list
            // VA for this cfg is inactive and VA has cache
            if (!va.isActive() && va.getCache()) {
                caches.append(op).append(Constants.BACK_SLASH);
            }

            //Hub is positive list, see Ticket 7658#4
            if (va.isActive() && va.getHub()) {
                hubs.append(op).append(Constants.BACK_SLASH);
            }

            //bookonline is positive list
            if (va.getBookOnline()) {
                bookonlines.append(op).append(Constants.BACK_SLASH);
            }
        }

        // Active Cache-VAs which are not in VA-SETs of this CFG, or Cache-VAs is inactive in VA-Sortiement TAB,
        // they should be write in VA negative list.
        List<String> appendNegativeList = (List<String>) CollectionUtils.subtract(allActiveOpList, tempOpList);
        String negative = Joiner.on(Constants.BACK_SLASH).join(appendNegativeList);
        caches.append(negative).append(Constants.BACK_SLASH);
    }

    private void writeSection(Wini iniFile, String sectionName, Map<String, String> contentMap) {
        for (Map.Entry<String, String> entry : contentMap.entrySet()) {
            iniFile.put(sectionName, entry.getKey(), entry.getValue());
        }
        try {
            iniFile.store();
        } catch (IOException e) {
            String msg = "Write Profile.ini failed";
            LOGGER.error(msg, e);
            sendEmail(msg, e);
        }
    }

    private void sendEmail(String subject, IOException e) {
        Email email = new SimpleEmail();
        email.setHostName(Constants.HOST);
        email.setCharset("ISO8859_1");
        email.setSmtpPort(Integer.parseInt(Constants.SMTP_PORT));
        //email.setAuthenticator(new DefaultAuthenticator("username", "password"));
        //email.setSSLOnConnect(true);
        try {
            email.setFrom("profileadmin@travel-it.de");
            email.setSubject(subject);

            StringBuilder msg = new StringBuilder(e.getClass().getCanonicalName());
            msg.append(": ");
            msg.append(e.getMessage());
            msg.append("\n\t");
            for (StackTraceElement stackTraceElement : e.getStackTrace()) {
                msg.append(stackTraceElement.toString());
                msg.append("\n\t");
            }
            email.setMsg(msg.toString());

            Iterable<String> recievers = Constants.ON_COMMA_OMITEMPTY.split(Constants.RECIEVER);
            for(String mail: recievers){
                email.addTo(mail);
            }
            email.send();
        } catch (EmailException ex) {
            LOGGER.error("Send mail error.", ex);
        }

    }

}
