
package de.travelit.profileadmin.webservice.client;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java-Klasse f�r getCfgsResponse complex type.
 * 
 * <p>Das folgende Schemafragment gibt den erwarteten Content an, der in dieser Klasse enthalten ist.
 * 
 * <pre>
 * &lt;complexType name="getCfgsResponse">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="cfgs" type="{http://webservice.profileadmin.travelit.de/}cfgMixerList" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "getCfgsResponse", propOrder = {
    "cfgs"
})
public class GetCfgsResponse {

    protected CfgMixerList cfgs;

    /**
     * Ruft den Wert der cfgs-Eigenschaft ab.
     * 
     * @return
     *     possible object is
     *     {@link CfgMixerList }
     *     
     */
    public CfgMixerList getCfgs() {
        return cfgs;
    }

    /**
     * Legt den Wert der cfgs-Eigenschaft fest.
     * 
     * @param value
     *     allowed object is
     *     {@link CfgMixerList }
     *     
     */
    public void setCfgs(CfgMixerList value) {
        this.cfgs = value;
    }

}
