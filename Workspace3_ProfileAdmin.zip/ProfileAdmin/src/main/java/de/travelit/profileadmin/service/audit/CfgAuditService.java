package de.travelit.profileadmin.service.audit;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.google.common.base.Joiner;
import com.google.common.collect.ListMultimap;

import de.travelit.profileadmin.dao.ProtokollDao;
import de.travelit.profileadmin.model.Protokoll;
import de.travelit.profileadmin.model.Range;
import de.travelit.profileadmin.service.CfgService;

@Service
@Transactional
public class CfgAuditService {

    private static final Logger LOGGER = Logger.getLogger(CfgAuditService.class);

    @Autowired
    private ProtokollDao protokollDao;

    @Autowired
    private CfgService cfgService;

    public void logRemoveVasetFromCfg(String username, int cfgId, String tableName, List<String> vasetList) {
        String vaset = Joiner.on("|").join(vasetList);

        Protokoll protokoll = new Protokoll();
        protokoll.setOperation("DELETE");
        protokoll.setTabelle(tableName);
        protokoll.setField("code");
        protokoll.setPk1(cfgId + "");
        protokoll.setOldValue(vaset);
        protokoll.setUpdateBy(username);

        protokollDao.writeProtokoll(protokoll);
    }

    public void logInsertValistCfg(String username, int cfgId, List<String> vasetList) {
        String vaset = Joiner.on("|").join(vasetList);

        Protokoll protokoll = new Protokoll();
        protokoll.setOperation("INSERT");
        protokoll.setTabelle("valist_cfg");
        protokoll.setField("code");
        protokoll.setPk1(cfgId + "");
        protokoll.setNewValue(vaset);
        protokoll.setUpdateBy(username);

        protokollDao.writeProtokoll(protokoll);
    }

    @Transactional
    public void logInsertVaaktivCfgs(String username, int cfgId, final List<String> vasetList) {
        if (vasetList.isEmpty()) {
            LOGGER.error("Cound not get Veranstalter-Set by logging insert va_aktiv_cfgs!");
            return;
        }

        List<Protokoll> protokolls = new ArrayList<>();
        List<Range> vaaktivCfgsList = cfgService.getVaaktivCfgs(cfgId, vasetList);
        if (vaaktivCfgsList.isEmpty()) {
            return;
        }

        for (Range r : vaaktivCfgsList) {
            Protokoll p = new Protokoll();
            p.setOperation("INSERT");
            p.setTabelle("va_aktiv_cfgs");
            p.setPk1(cfgId + "");
            p.setPk2(r.getCode());
            p.setNewValue(r.isActive() + "|" + r.getOnline());
            p.setUpdateBy(username);
            // protokolls.add(p);
        }

        protokollDao.writeProtokolls(protokolls);
    }

    @Transactional
    public void logInsertLinienflugProvisionen(String username, List<Integer> cfgKeys, final ListMultimap<String, String> insertMap) {

        List<Protokoll> protokolls = new ArrayList<>();

        for (int cfgKey : cfgKeys) {
            for (String op : insertMap.keySet()) {
                String kurz = insertMap.get(op).get(0);
                String mittel = insertMap.get(op).get(1);
                String fern = insertMap.get(op).get(2);

                Protokoll p = new Protokoll();
                p.setOperation("INSERT");
                p.setTabelle("lineflight_cfg");
                p.setPk1(cfgKey + "");
                p.setPk2(op);
                p.setField("lf_short, lf_middle, lf_long");
                p.setNewValue(kurz + ", " + mittel + ", " + fern);
                p.setUpdateBy(username);
                protokolls.add(p);
            }
        }
        protokollDao.writeProtokolls(protokolls);
    }

    @Transactional
    public void logRemoveLinienflugProvisionen(String username, List<Integer> cfgKeys, List<String> opList) {

        List<Protokoll> protokolls = new ArrayList<>();

        for (int cfgKey : cfgKeys) {
            Protokoll p = new Protokoll();
            p.setOperation("DELETE");
            p.setTabelle("lineflight_cfg");
            p.setPk1(cfgKey + "");
            p.setField("tourop");
            p.setOldValue(StringUtils.join(opList, ", "));
            p.setUpdateBy(username);
            protokolls.add(p);
        }

        protokollDao.writeProtokolls(protokolls);
    }

}
