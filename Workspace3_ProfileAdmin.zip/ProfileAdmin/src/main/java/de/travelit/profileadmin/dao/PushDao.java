package de.travelit.profileadmin.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class PushDao {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    public void setStatus(String key, boolean status) {
        String sqlStr = "UPDATE profile_update SET lastupdate=" + status + " WHERE id='" + key + "'";
        jdbcTemplate.update(sqlStr);
    }

    public boolean getStatus(String key) {
        String sqlStr = "SELECT lastupdate FROM profile_update WHERE id='" + key + "'";
        return jdbcTemplate.queryForObject(sqlStr, Boolean.class);
    }

}
