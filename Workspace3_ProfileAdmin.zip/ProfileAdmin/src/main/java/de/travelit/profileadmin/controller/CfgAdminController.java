package de.travelit.profileadmin.controller;

import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import org.springframework.web.servlet.support.RequestContext;

import com.google.common.base.Strings;
import com.google.common.collect.ListMultimap;
import com.google.common.collect.Lists;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import de.travelit.profileadmin.Constants;
import de.travelit.profileadmin.model.Authenticity;
import de.travelit.profileadmin.model.CfgAdminKunde;
import de.travelit.profileadmin.model.CfgBuchungsModus;
import de.travelit.profileadmin.model.CfgMain;
import de.travelit.profileadmin.model.HicContent;
import de.travelit.profileadmin.model.HoteloAufschlag;
import de.travelit.profileadmin.model.Range;
import de.travelit.profileadmin.model.mixer.CfgMixer;
import de.travelit.profileadmin.service.CfgService;
import de.travelit.profileadmin.service.VeranstalterListService;

@Controller
public class CfgAdminController {

    private static final Logger LOGGER = Logger.getLogger(CfgAdminController.class);

    @Autowired
    private VeranstalterListService vaListService;

    @Autowired
    private CfgService cfgService;

    /**
     * Trim String of input field.
     *
     * @param binder
     */
    @InitBinder
    public void initBinder(WebDataBinder binder) {
        binder.registerCustomEditor(String.class, new ProfileAdminStringTrimmerEditor());
    }

    @RequestMapping("begin_cfg_anlegen")
    public String cfgAnlegen() {
        return "cfg_anlegen";
    }

    @RequestMapping("begin_cfg_copy")
    public String cfgInputId(HttpServletRequest request) {
        request.getSession().removeAttribute("cfg_get_copynr");
        return "cfg_copy_id";
    }

    @RequestMapping(value = "cfg_get_cfg_to_copy", method = RequestMethod.POST)
    public String cfgGetCopy(@RequestParam(value = "cfgnumber") String pcfg, HttpServletRequest request, Model model) {
        String cfg = pcfg.trim();
        request.getSession().setAttribute("cfg_get_copynr", cfg);

        List<CfgMain> cfgMainList = cfgService.getCfgList(cfg, "");
        if (cfgMainList.isEmpty()) {
            RequestContext requestContext = new RequestContext(request);
            String errorMessage = requestContext.getMessage("no_cfg");
            model.addAttribute("cfg_get_error", errorMessage);
            return "cfg_copy_id";
        }

        // Here should always return one CFG.
        CfgMain cfgMain = cfgMainList.get(0);
        getCfgData(cfgMain.getCfgNumber() + "", model);
        return "cfg_copy";
    }

    @RequestMapping(value = "cfg_copy_back", method = RequestMethod.POST)
    public String cfgCopyBack() {
        return "cfg_copy_id";
    }

    @RequestMapping("cfg_get_from_menu")
    public String cfgGet(HttpServletRequest request, Model model) {
        request.getSession().removeAttribute("cfg_get_cfgnr");
        request.getSession().removeAttribute("cfg_get_kunde");

        Authenticity auth = (Authenticity) request.getSession().getAttribute(Constants.SESSION_KEY_AUTHENTICITY);
        if (1 == auth.getRoleId() || 32 == auth.getRoleId()) {
            return "cfg_get";
        } else {
            List<String> cfgList = auth.getCfgList();
            List<CfgMain> cfgMainList = cfgService.getCfgList(cfgList);
            request.getSession().setAttribute("cfgList", cfgMainList);

            //If there is only one cfg, don't need to show cfg list, directly show cfg see.
            if (cfgMainList.size() == 1) {
                CfgMain cfgMain = cfgMainList.get(0);
                return gotoCfgSee(cfgMain.getCfgNumber() + "", model);
            }

            return "cfg_show_list";
        }
    }

    @RequestMapping(value = "cfg_get_next", method = RequestMethod.POST)
    public String cfgGetNext(@RequestParam(value = "cfgnumber") String pcfg, @RequestParam(value = "kunde") String pkunde, HttpServletRequest request, Model model) {

        String cfg = pcfg.trim();
        String kunde = pkunde.trim();

        request.getSession().setAttribute("cfg_get_cfgnr", cfg);
        request.getSession().setAttribute("cfg_get_kunde", kunde);

        List<CfgMain> cfgMainList = cfgService.getCfgList(cfg, kunde);
        if (cfgMainList.isEmpty()) {
            RequestContext requestContext = new RequestContext(request);
            String errorMessage = requestContext.getMessage("no_cfg");
            model.addAttribute("cfg_get_error", errorMessage);
            return "cfg_get";
        }

        //If there is only one cfg, don't need to show cfg list, directly show cfg see.
        if (cfgMainList.size() == 1) {
            CfgMain cfgMain = cfgMainList.get(0);
            return gotoCfgSee(cfgMain.getCfgNumber() + "", model);
        }

        request.getSession().setAttribute("cfgList", cfgMainList);
        return "cfg_show_list";
    }

    @RequestMapping(value = "cfg_list_back", method = RequestMethod.POST)
    public String cfgListBack() {
        return "cfg_get";
    }

    @RequestMapping(value = "cfg_see_back", method = RequestMethod.POST)
    public String cfgSeeBack(HttpServletRequest request) {
        List<CfgMain> cfgMainList = (List<CfgMain>) request.getSession().getAttribute("cfgList");
        //If there is only one cfg, don't need to show cfg list, directly go to cfg_get page.
        if (cfgMainList == null || cfgMainList.size() == 1) {
            return "cfg_get";
        }

        return "cfg_show_list";

    }

    @RequestMapping(value = { "cfg_see", "cfg_change_back", "cfg_rbadmin_change_back" }, method = RequestMethod.POST)
    public String cfgSee(@RequestParam(value = "cfgNumber") String cfg, Model model) {
        return gotoCfgSee(cfg, model);
    }

    private String gotoCfgSee(String cfg, Model model) {
        getCfgData(cfg, model);
        return "cfg_see";
    }

    @RequestMapping(value = "cfg_change", method = RequestMethod.POST)
    public String cfgChange(CfgMain cfgmain, Model model, HttpServletRequest request) {
        getCfgData(Integer.toString(cfgmain.getCfgNumber()), model);
        Authenticity auth = (Authenticity) request.getSession().getAttribute(Constants.SESSION_KEY_AUTHENTICITY);
        int roleId = auth.getRoleId();
        if (roleId == 1) {
            return "cfg_change";
        } else if (roleId == 8) {
            return "cfg_change_rb";
        } else {
            return "cfg_see";
        }
    }

    /**
     *
     * @param cfg
     * @param model
     * @return false - can not get cfg data.
     */
    private boolean getCfgData(String cfg, Model model) {
        Map<String, Object> cfgDataMap = cfgService.getCfgData(cfg);
        model.addAttribute("cfgdata", cfgDataMap);
        List<Range> rangeList = (List<Range>) cfgDataMap.get("rangeList");
        pickRangeList(rangeList, model);
        return !cfgDataMap.isEmpty();
    }

    private void pickRangeList(List<Range> rangeList, Model model) {
        List<Range> vaList = new ArrayList<>();
        List<Range> lineflightList = new ArrayList<>();
        for (Range range : rangeList) {
            int sc = range.getServiceCharge();
            if (sc == 2) {
                lineflightList.add(range);
            } else {
                vaList.add(range);
            }
        }
        model.addAttribute("range_va", vaList);
        model.addAttribute("range_lf", lineflightList);
    }

    @RequestMapping(value = "cfg_anlegen_load_vaset", method = RequestMethod.POST)
    public String anlegenLoadVaset(@RequestParam(value = "vasets") String vasets, @RequestParam(value = "vasetOrHaupt") String vasetOrHaupt, Model model,
            HttpServletRequest request) {
        if (Integer.parseInt(vasetOrHaupt) == 0) {
            //VA-SET
            return loadVaset(vasets, model, request);
        } else {
            //Haupt-CFG
            return loadInfoFromPrimaryCfg(vasets, model, request);
        }
    }

    private String loadVaset(String vasets, Model model, HttpServletRequest request) {
        Iterable<String> iterable = Constants.ON_COMMA_OMITEMPTY.split(vasets);
        List<String> vasetList = Lists.newArrayList(iterable);
        Set<String> vasetSet = new HashSet<String>(vasetList);
        boolean valid = vaListService.allVasetsValid(vasetSet);
        if (!valid) {
            return vasetInvalid(model, request);
        }

        //List<TourOperator> touropList = vaListService.getTourOperatorsBySetcodeList(vasetSet);
        List<Range> rangeList = vaListService.getRangesBySetcodeList(vasetSet);
        if (rangeList.isEmpty()) {
            return vasetNotFound(model, request);
        } else {
            List<Range> vaList = new ArrayList<>();
            List<Range> lineflightList = new ArrayList<>();
            for (Range range : rangeList) {
                int sc = range.getServiceCharge();
                if (sc == 2) {
                    lineflightList.add(range);
                } else {
                    vaList.add(range);
                }
            }
            model.addAttribute("cfg_vaset_va", vaList);
            model.addAttribute("cfg_vaset_lf", lineflightList);
            return "cfg_vaset";
        }
    }

    private String vasetInvalid(Model model, HttpServletRequest request) {
        RequestContext requestContext = new RequestContext(request);
        String errorMessage = requestContext.getMessage("vaset_invalid");
        model.addAttribute("cfg_vaset_error", errorMessage);
        return "cfg_vaset";
    }

    private String vasetNotFound(Model model, HttpServletRequest request) {
        RequestContext requestContext = new RequestContext(request);
        String errorMessage = requestContext.getMessage("no_vas");
        model.addAttribute("cfg_vaset_error", errorMessage);
        return "cfg_vaset";
    }

    private String primaryCfgNotFound(Model model, HttpServletRequest request) {
        RequestContext requestContext = new RequestContext(request);
        String errorMessage = requestContext.getMessage("no_primarycfg");
        model.addAttribute("cfg_vaset_error", errorMessage);
        return "cfg_vaset";
    }

    // Inactive CFG can not be haupt CFG
    private String inactiveCfg(Model model, HttpServletRequest request) {
        RequestContext requestContext = new RequestContext(request);
        String errorMessage = requestContext.getMessage("inactive_cfg");
        model.addAttribute("cfg_vaset_error", errorMessage);
        return "cfg_vaset";
    }

    private String loadInfoFromPrimaryCfg(String primaryCfg, Model model, HttpServletRequest request) {
        boolean isInt = Constants.isInteger(primaryCfg);
        if (!isInt) {
            return primaryCfgNotFound(model, request);
        }

        Map<String, Object> cfgMainMap = cfgService.getCfgMain(primaryCfg);
        CfgMain cfgMain = (CfgMain) cfgMainMap.get("cfgmain");
        if (cfgMain == null) {
            return primaryCfgNotFound(model, request);
        } else if (!cfgMain.isCfgStatus()) {
            // Inactive cfg can not be hauptcfg
            return inactiveCfg(model, request);
        }

        //Load vaset
        List<Range> rangeList = cfgService.getVaaktivCfgsBycfgid(Integer.parseInt(primaryCfg));
        if (rangeList.isEmpty()) {
            return primaryCfgNotFound(model, request);
        } else {
            pickRangeList(rangeList, model);

            //Load agentur, insurance, charterflug-Provisionen
            String agentur = cfgMain.getBumaAgency();
            CfgAdminKunde kunde = (CfgAdminKunde) cfgMainMap.get("adminkunde");
            int insurance = kunde.getVersicherung();
            String tui = kunde.getTuiAgencyNummer();
            model.addAttribute("agenturPrimaryCfg", agentur);
            model.addAttribute("insurancePrimaryCfg", insurance);
            model.addAttribute("angenturNrTuiCfg", tui);

            ListMultimap<String, Integer> charterflugMap = cfgService.getCharterflugProvisionen(primaryCfg);

            Gson gson = new GsonBuilder().create();
            String json = gson.toJson(charterflugMap.asMap());
            //Json key can not start with number
            json = json.replace("5VF", "_5VF");
            model.addAttribute("serviceChargePrimaryCfg", json);

            CfgBuchungsModus buchungsModus = cfgService.getBuchungsModus(primaryCfg);
            json = gson.toJson(buchungsModus);
            model.addAttribute("buchungsmodus", json);

            return "cfg_see_vaset";
        }
    }

    @RequestMapping(value = "cfg_change_load_vaset", method = RequestMethod.POST)
    public String changeLoadVaset(@RequestParam(value = "vasets") String vasets, @RequestParam(value = "cfgNr") String cfgNr,
            @RequestParam(value = "vasetOrHaupt") String vasetOrHaupt, @RequestParam(value = "hadPrimaryCfg") String hadPrimaryCfg, Model model, HttpServletRequest request) {
        if (Integer.parseInt(vasetOrHaupt) == 1) {
            //Haupt-CFG
            return loadInfoFromPrimaryCfg(vasets, model, request);
        }

        //VA-SET
        Iterable<String> iterable = Constants.ON_COMMA_OMITEMPTY.split(vasets);
        List<String> vasetList = Lists.newArrayList(iterable);

        Set<String> vasetSet = new HashSet<String>(vasetList);
        boolean valid = vaListService.allVasetsValid(vasetSet);
        if (!valid) {
            RequestContext requestContext = new RequestContext(request);
            String errorMessage = requestContext.getMessage("vaset_invalid");
            model.addAttribute("cfg_vaset_error", errorMessage);
            return "cfg_change_vaset";
        }

        Boolean hadPrimary = Boolean.valueOf(hadPrimaryCfg);
        List<Range> rangeList = new ArrayList<>();
        // If cfg had primary cfg, we can not find vaset in valist_cfg and va_aktiv_cfgs table.
        // We should find vas in valist table.
        if (hadPrimary) {
            rangeList = vaListService.getRangesBySetcodeList(vasetList);
        } else {
            rangeList = vaListService.getRangesBySetcodeList(cfgNr, vasetList);
        }
        if (rangeList.isEmpty()) {
            RequestContext requestContext = new RequestContext(request);
            String errorMessage = requestContext.getMessage("no_vas");
            model.addAttribute("cfg_vaset_error", errorMessage);
        } else {
            pickRangeList(rangeList, model);
        }
        return "cfg_change_vaset";
    }

    @RequestMapping(value = "cfg_anlegen_check_cfgnr", method = RequestMethod.POST)
    @ResponseBody
    public String createCfgCheckCfgnr(@RequestParam(value = "cfgNr") String cfgNr, HttpServletRequest request) {
        if (Strings.isNullOrEmpty(cfgNr)) {
            RequestContext requestContext = new RequestContext(request);
            return requestContext.getMessage("cfg_empty");
        }

        if (!Constants.isInteger(cfgNr)) {
            RequestContext requestContext = new RequestContext(request);
            return requestContext.getMessage("error_cfg_not_number");
        }

        if (cfgService.getCfgMain(cfgNr).size() != 0) {
            RequestContext requestContext = new RequestContext(request);
            return requestContext.getMessage("cfg_exist");
        }
        return "";
    }

    /**
     * If indeactive a CFG, must check whether this CFG is a Haupt-CFG or not.
     * @param cfgNr
     * @param request
     * @return
     */
    @RequestMapping(value = "cfg_change_whether_haupt", method = RequestMethod.POST)
    @ResponseBody
    public boolean changeCfgWhetherHaupt(@RequestParam(value = "cfgNr") String cfgNr, HttpServletRequest request) {
        return cfgService.isCfgHaupt(cfgNr);
    }

    // @formatter:off
    @RequestMapping(value = "create_cfg_commit", method = RequestMethod.POST)
    public String creatCfg(CfgMain cfgmain, CfgAdminKunde adminKunde, CfgBuchungsModus buchungsModus,
                            @RequestParam(value = "vaset_active") String vasetActive,
                            @RequestParam(value = "vaset_online") String vasetOnline,
                            @RequestParam(value = "sg_collection") String sgcollection,
                            @RequestParam(value = "lf_collection") String lfcollection,
                            HoteloAufschlag aufschlag,
                            @RequestParam(value = "hotelocalc") String hoteloCalc,
                            HicContent hicContent,
                            CfgMixer mixer,
                            Model model, HttpServletRequest request) {
     // @formatter:on
        Authenticity auth = (Authenticity) request.getSession().getAttribute(Constants.SESSION_KEY_AUTHENTICITY);
        String user = auth.getName();

        int cfgNr = cfgService.createCfg(user, cfgmain, adminKunde, buchungsModus, vasetActive, vasetOnline, sgcollection, lfcollection, aufschlag, hoteloCalc, hicContent, mixer);

        RequestContext requestContext = new RequestContext(request);
        String titleCreate = requestContext.getMessage("create");
        String ok = requestContext.getMessage("create_cfg_ok");
        ok = MessageFormat.format(ok, cfgNr + "");

        model.addAttribute("dialog_title", "CFG " + titleCreate);
        model.addAttribute("dialog_message", ok);
        model.addAttribute("cfgNr", cfgNr);

        return "cfg_anlegen_success_dialog";
    }

    // @formatter:off
    @RequestMapping(value = "change_cfg_commit", method = RequestMethod.POST)
    public String commitCfgChange(CfgMain cfgmain, CfgAdminKunde adminKunde, CfgBuchungsModus buchungsModus,
                            @RequestParam(value = "vaset_active") String vasetActive,
                            @RequestParam(value = "vaset_online") String vasetOnline,
                            @RequestParam(value = "sg_collection") String sgcollection,
                            @RequestParam(value = "lf_collection") String lfcollection,
                            HoteloAufschlag aufschlag,
                            @RequestParam(value = "hotelocalc") String hoteloCalc,
                            HicContent hicContent,
                            CfgMixer mixer,
                            Model model, HttpServletRequest request) {
     // @formatter:on
        Authenticity auth = (Authenticity) request.getSession().getAttribute(Constants.SESSION_KEY_AUTHENTICITY);
        String user = auth.getName();

        cfgService.commitCfgChange(user, cfgmain, adminKunde, buchungsModus, vasetActive, vasetOnline, sgcollection, lfcollection, aufschlag, hoteloCalc, hicContent, mixer);
        refreshCfgList();

        int cfgNr = cfgmain.getCfgNumber();
        return cfgChangeSuccessDialog(cfgNr, model, request);
    }

    private void refreshCfgList() {
        HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.currentRequestAttributes()).getRequest();
        String cfgNr = (String) request.getSession().getAttribute("cfg_get_cfgnr");
        String name = (String) request.getSession().getAttribute("cfg_get_kunde");
        List<CfgMain> cfgMainList = cfgService.getCfgList(cfgNr, name);
        request.getSession().setAttribute("cfgList", cfgMainList);
    }

    private String cfgChangeSuccessDialog(int cfgNr, Model model, HttpServletRequest request) {
        RequestContext requestContext = new RequestContext(request);
        String titleModify = requestContext.getMessage("modify");
        String ok = requestContext.getMessage("modify_cfg_ok");
        ok = MessageFormat.format(ok, cfgNr + "");

        model.addAttribute("dialog_title", "CFG " + titleModify);
        model.addAttribute("dialog_message", ok);
        model.addAttribute("cfgNr", cfgNr);

        return "cfg_change_success_dialog";
    }

    // @formatter:off
    @RequestMapping(value = "rbadmin_change_cfg_commit", method = RequestMethod.POST)
    public String rbadminCommitCfgChange(CfgMain cfgmain, CfgAdminKunde adminKunde, CfgBuchungsModus buchungsModus,
        @RequestParam(value = "vaset_active") String vasetActive,
        @RequestParam(value = "vaset_online") String vasetOnline,
        @RequestParam(value = "sg_collection") String sgcollection,
        @RequestParam(value = "lf_collection") String lfcollection,
        HoteloAufschlag aufschlag,
        @RequestParam(value = "hotelocalc") String hoteloCalc,
        HicContent hicContent,
        Model model, HttpServletRequest request) {
      // @formatter:on
        Authenticity auth = (Authenticity) request.getSession().getAttribute(Constants.SESSION_KEY_AUTHENTICITY);
        String user = auth.getName();

        cfgService.rbadminCommitCfgChange(user, cfgmain, adminKunde, buchungsModus, vasetActive, vasetOnline, sgcollection, lfcollection, aufschlag, hoteloCalc, hicContent);

        int cfgNr = cfgmain.getCfgNumber();
        return cfgChangeSuccessDialog(cfgNr, model, request);
    }
}
