package de.travelit.profileadmin.service;

import java.util.Iterator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import de.travelit.profileadmin.dao.MixerDao;
import de.travelit.profileadmin.model.mixer.CfgMixer;

@Service
@Transactional
public class MixerService {

    @Autowired
    private MixerDao mixerDao;

    @Transactional(propagation = Propagation.NOT_SUPPORTED, readOnly = true)
    public List<CfgMixer> getActiveCfgs() {
        return mixerDao.getActiveCfgs();
    }

    @Transactional(propagation = Propagation.NOT_SUPPORTED, readOnly = true)
    public List<CfgMixer> getCfgsWithMixerType(String mixerType) {
        int mask = Integer.parseInt(mixerType, 2);
        List<CfgMixer> cfgMixers = mixerDao.getActiveCfgsWithMixerType();
        Iterator<CfgMixer> iter = cfgMixers.iterator();
        while (iter.hasNext()) {
            CfgMixer mixer = iter.next();
            int i = mixer.getMixer();
            if ((i & mask) != mask) {
                iter.remove();
            }
        }
        return cfgMixers;
    }

}
