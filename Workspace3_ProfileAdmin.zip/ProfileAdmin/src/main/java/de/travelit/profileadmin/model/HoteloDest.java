package de.travelit.profileadmin.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "hotelodest")
public class HoteloDest implements Serializable {

    private static final long serialVersionUID = 4312108044248580021L;

    @EmbeddedId
    private HoteloDestPK hoteloDestPK;

    @Column(name = "percentagelow")
    private Integer percentageLow;

    @Column(name = "percentagemiddle")
    private Integer percentageMiddle;

    @Column(name = "percentagehigh")
    private Integer percentageHigh;

    @Column(name = "update_by")
    private String updateBy;

    public HoteloDestPK getHoteloDestPK() {
        return hoteloDestPK;
    }

    public void setHoteloDestPK(HoteloDestPK hoteloDestPK) {
        this.hoteloDestPK = hoteloDestPK;
    }

    public Integer getPercentageLow() {
        return percentageLow;
    }

    public void setPercentageLow(Integer percentageLow) {
        this.percentageLow = percentageLow;
    }

    public Integer getPercentageMiddle() {
        return percentageMiddle;
    }

    public void setPercentageMiddle(Integer percentageMiddle) {
        this.percentageMiddle = percentageMiddle;
    }

    public Integer getPercentageHigh() {
        return percentageHigh;
    }

    public void setPercentageHigh(Integer percentageHigh) {
        this.percentageHigh = percentageHigh;
    }

    public String getUpdateBy() {
        return updateBy;
    }

    public void setUpdateBy(String updateBy) {
        this.updateBy = updateBy;
    }

    @Embeddable
    public static class HoteloDestPK implements Serializable {

        private static final long serialVersionUID = -938246295094024564L;

        private Integer cfg;
        private String dest3lc;

        public HoteloDestPK() {
        }

        public HoteloDestPK(Integer cfg, String dest3lc) {
            this.cfg = cfg;
            this.dest3lc = dest3lc;
        }

        public Integer getCfg() {
            return cfg;
        }

        public void setCfg(Integer cfg) {
            this.cfg = cfg;
        }

        public String getDest3lc() {
            return dest3lc;
        }

        public void setDest3lc(String dest3lc) {
            this.dest3lc = dest3lc;
        }

        @Override
        public int hashCode() {
            final int prime = 31;
            int result = 1;
            result = prime * result + ((cfg == null) ? 0 : cfg.hashCode());
            result = prime * result + ((dest3lc == null) ? 0 : dest3lc.hashCode());
            return result;
        }

        @Override
        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }

            if (obj == null) {
                return false;
            }

            if (getClass() != obj.getClass()) {
                return false;
            }

            HoteloDestPK other = (HoteloDestPK) obj;
            if (cfg == null) {
                if (other.cfg != null) {
                    return false;
                }
            } else if (!cfg.equals(other.cfg)) {
                return false;
            }

            if (dest3lc == null) {
                if (other.dest3lc != null) {
                    return false;
                }
            } else if (!dest3lc.equals(other.dest3lc)) {
                return false;
            }
            return true;
        }
    }

}
