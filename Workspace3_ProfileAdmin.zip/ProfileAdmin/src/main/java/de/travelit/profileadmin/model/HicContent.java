package de.travelit.profileadmin.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlTransient;

@XmlAccessorType(XmlAccessType.FIELD)
@Entity
@Table(name = "hiccontent")
public class HicContent {
    @XmlTransient
    @Id
    private Integer cfg;

    @Column(name = "hotelcontent", columnDefinition = "boolean default true")
    private boolean hotelContent;

    private boolean catalog;

    private boolean climate;

    private boolean video;

    private boolean contact;

    private boolean facts;

    private boolean geo;

    @XmlElement(name = "Bewertung")
    @Column(name = "reviews")
    private boolean hicReviews;

    private String color1 = "";

    private String color2 = "";

    private String color3 = "";

    @Column(name = "fontfamily")
    private String fontFamily = "";

    @Column(name = "fontsize")
    private String fontSize = "";

    @XmlTransient
    @Column(name = "update_by")
    private String updateBy;

    public Integer getCfg() {
        return cfg;
    }

    public void setCfg(Integer cfg) {
        this.cfg = cfg;
    }

    public boolean isHotelContent() {
        return hotelContent;
    }

    public void setHotelContent(boolean hotelContent) {
        this.hotelContent = hotelContent;
    }

    public boolean isCatalog() {
        return catalog;
    }

    public void setCatalog(boolean catalog) {
        this.catalog = catalog;
    }

    public boolean isClimate() {
        return climate;
    }

    public void setClimate(boolean climate) {
        this.climate = climate;
    }

    public boolean isVideo() {
        return video;
    }

    public void setVideo(boolean video) {
        this.video = video;
    }

    public boolean isContact() {
        return contact;
    }

    public void setContact(boolean contact) {
        this.contact = contact;
    }

    public boolean isFacts() {
        return facts;
    }

    public void setFacts(boolean facts) {
        this.facts = facts;
    }

    public boolean isGeo() {
        return geo;
    }

    public void setGeo(boolean geo) {
        this.geo = geo;
    }

    public boolean isHicReviews() {
        return hicReviews;
    }

    public void setHicReviews(boolean hicReviews) {
        this.hicReviews = hicReviews;
    }

    public String getColor1() {
        return color1;
    }

    public void setColor1(String color1) {
        this.color1 = color1;
    }

    public String getColor2() {
        return color2;
    }

    public void setColor2(String color2) {
        this.color2 = color2;
    }

    public String getColor3() {
        return color3;
    }

    public void setColor3(String color3) {
        this.color3 = color3;
    }

    public String getFontFamily() {
        return fontFamily;
    }

    public void setFontFamily(String fontFamily) {
        this.fontFamily = fontFamily;
    }

    public String getFontSize() {
        return fontSize;
    }

    public void setFontSize(String fontSize) {
        this.fontSize = fontSize;
    }

    public String getUpdateBy() {
        return updateBy;
    }

    public void setUpdateBy(String updateBy) {
        this.updateBy = updateBy;
    }
}
