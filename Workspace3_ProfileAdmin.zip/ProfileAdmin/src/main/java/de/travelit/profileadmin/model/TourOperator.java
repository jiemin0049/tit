package de.travelit.profileadmin.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

import org.springframework.format.annotation.DateTimeFormat;

import de.travelit.profileadmin.DateAdapter;

@Entity
@XmlRootElement(name = "veranstalter")
@XmlAccessorType(XmlAccessType.NONE)
public class TourOperator implements Serializable {

    private static final long serialVersionUID = -987868008916166680L;

    @XmlAttribute
    @Id
    private String tourop;

    @XmlElement
    @Column(name = "touropname")
    private String touropName;

    @XmlElement
    @Column(name = "gtc_su")
    private String gtcSommer;

    @XmlElement
    @Column(name = "gtc_wi")
    private String gtcWinter;

    @XmlElement
    @XmlJavaTypeAdapter(DateAdapter.class)
    // Spring MVC need this
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    // Without this hibernate return 2016-01-20 00:00:00.0, but I want 2016-01-20
    @Temporal(TemporalType.DATE)
    @Column(name = "date_gtc_su")
    private Date gtcSommerDate;

    @XmlElement
    @XmlJavaTypeAdapter(DateAdapter.class)
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    @Temporal(TemporalType.DATE)
    @Column(name = "date_gtc_wi")
    private Date gtcWinterDate;

    @XmlElement
    @Column(name = "tourop_giata")
    private String touropGiata;

    @XmlElement
    @Column(name = "fallback_giata")
    private String fallbackGiata;

    @XmlElement
    @Column(name = "active_giata")
    private Boolean activeGiata = false;

    @Column(name = "source_cache")
    private Boolean cache = false;

    @Column(name = "source_hub")
    private Boolean hub = false;

    @Column(name = "servicecharge")
    private int serviceCharge;

    @XmlElement
    @XmlJavaTypeAdapter(DateAdapter.class)
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    @Temporal(TemporalType.DATE)
    @Column(name = "active_since")
    private Date activeDate;

    @XmlElement
    private Boolean active = false;

    private String payment;

    @Column(name = "update_by")
    private String updateBy;

    public String getTourop() {
        return tourop;
    }

    public void setTourop(String tourop) {
        this.tourop = tourop;
    }

    public String getTouropName() {
        return touropName;
    }

    public void setTouropName(String touropName) {
        this.touropName = touropName;
    }

    public String getPayment() {
        return payment;
    }

    public void setPayment(String payment) {
        this.payment = payment;
    }

    public String getGtcSommer() {
        return gtcSommer;
    }

    public void setGtcSommer(String gtcSommer) {
        this.gtcSommer = gtcSommer;
    }

    public String getGtcWinter() {
        return gtcWinter;
    }

    public void setGtcWinter(String gtcWinter) {
        this.gtcWinter = gtcWinter;
    }

    public Date getGtcSommerDate() {
        return gtcSommerDate;
    }

    public void setGtcSommerDate(Date gtcSommerDate) {
        this.gtcSommerDate = gtcSommerDate;
    }

    public Date getGtcWinterDate() {
        return gtcWinterDate;
    }

    public void setGtcWinterDate(Date gtcWinterDate) {
        this.gtcWinterDate = gtcWinterDate;
    }

    public String getTouropGiata() {
        return touropGiata;
    }

    public void setTouropGiata(String touropGiata) {
        this.touropGiata = touropGiata;
    }

    public String getFallbackGiata() {
        return fallbackGiata;
    }

    public void setFallbackGiata(String fallbackGiata) {
        this.fallbackGiata = fallbackGiata;
    }

    public Boolean getCache() {
        return cache;
    }

    public void setCache(Boolean cache) {
        this.cache = cache;
    }

    public Boolean getHub() {
        return hub;
    }

    public void setHub(Boolean hub) {
        this.hub = hub;
    }

    public int getServiceCharge() {
    	return serviceCharge;
    }

    public void setServiceCharge(int serviceCharge) {
    	this.serviceCharge = serviceCharge;
    }

    public Date getActiveDate() {
        return activeDate;
    }

    public void setActiveDate(Date activeDate) {
        this.activeDate = activeDate;
    }

    public Boolean getActive() {
        return active;
    }

    public void setActive(Boolean active) {
        this.active = active;
    }

    public Boolean getActiveGiata() {
        return activeGiata;
    }

    public void setActiveGiata(Boolean activeGiata) {
        this.activeGiata = activeGiata;
    }

    public String getUpdateBy() {
        return updateBy;
    }

    public void setUpdateBy(String updateBy) {
        this.updateBy = updateBy;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((tourop == null) ? 0 : tourop.hashCode());
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        TourOperator other = (TourOperator) obj;
        if (tourop == null) {
            if (other.tourop != null)
                return false;
        } else if (!tourop.equals(other.tourop))
            return false;
        return true;
    }

}
