package de.travelit.profileadmin.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import de.travelit.profileadmin.model.CfgHic;
import de.travelit.profileadmin.model.TourOperator;
import de.travelit.profileadmin.model.TourOperatorList;
import de.travelit.profileadmin.service.CfgService;
import de.travelit.profileadmin.service.VeranstalterService;

@Controller
public class HotelInfoCenterController {

    @Autowired
    private VeranstalterService vaService;

    @Autowired
    private CfgService cfgService;

    @RequestMapping(value = "/hic/veranstalter/{tourop}")
    public ResponseEntity<TourOperator> getVeranstalterById(@PathVariable("tourop") String tourop) {
        TourOperator veranstalter = vaService.getVeranstalterByCode(tourop);
        if (null != veranstalter) {
            return new ResponseEntity<TourOperator>(veranstalter, HttpStatus.OK);
        }
        return new ResponseEntity<TourOperator>(HttpStatus.NOT_FOUND);
    }

    @RequestMapping(value = "/hic/veranstalters")
    public @ResponseBody TourOperatorList getVeranstalters() {
        TourOperatorList list = new TourOperatorList();
        list.setVeranstalters(vaService.getActiveVeranstalterList());
        return list;
    }

    @RequestMapping(value = "/hic/cfg/{cfg}")
    public ResponseEntity<CfgHic> getCfgHic(@PathVariable("cfg") int cfg) {
        CfgHic cfgHic = cfgService.getCfgHic(cfg);
        if (null != cfgHic) {
            return new ResponseEntity<CfgHic>(cfgHic, HttpStatus.OK);
        }
        return new ResponseEntity<CfgHic>(HttpStatus.NOT_FOUND);
    }
}
