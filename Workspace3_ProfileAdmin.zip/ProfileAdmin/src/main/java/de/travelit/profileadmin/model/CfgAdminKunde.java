package de.travelit.profileadmin.model;

public class CfgAdminKunde {
    private String rbagb;
    private boolean onrequest;
    //1: ERV, 4: ELVIA, 8: HANSE
    private int versicherung;
    private String agencyNumber;
    private String tuiAgencyNummer;
    private String email;
    private String giataIhgUid;
    private int maxPriceDiff;

    public String getRbagb() {
        return rbagb;
    }

    public void setRbagb(String rbagb) {
        this.rbagb = rbagb;
    }

    public boolean isOnrequest() {
        return onrequest;
    }

    public void setOnrequest(boolean onrequest) {
        this.onrequest = onrequest;
    }

    public int getVersicherung() {
        return versicherung;
    }

    public void setVersicherung(int versicherung) {
        this.versicherung = versicherung;
    }

    public String getAgencyNumber() {
        return agencyNumber;
    }

    public void setAgencyNumber(String agencyNumber) {
        this.agencyNumber = agencyNumber;
    }

    public String getTuiAgencyNummer() {
        return tuiAgencyNummer;
    }

    public void setTuiAgencyNummer(String tuiAgencyNummer) {
        this.tuiAgencyNummer = tuiAgencyNummer;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getGiataIhgUid() {
        return giataIhgUid;
    }

    public void setGiataIhgUid(String giataIhgUid) {
        this.giataIhgUid = giataIhgUid;
    }

    public int getMaxPriceDiff() {
        return maxPriceDiff;
    }

    public void setMaxPriceDiff(int maxPriceDiff) {
        this.maxPriceDiff = maxPriceDiff;
    }

}
