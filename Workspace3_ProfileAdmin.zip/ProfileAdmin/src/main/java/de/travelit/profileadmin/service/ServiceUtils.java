package de.travelit.profileadmin.service;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.log4j.Logger;

import com.google.common.collect.Lists;

import de.travelit.profileadmin.model.TourOperator;

public final class ServiceUtils {

    private static final Logger LOGGER = Logger.getLogger(ServiceUtils.class);

    public static String sendRequest(String request) {
        StringBuffer response = new StringBuffer();
        HttpURLConnection con = null;
        try {
            URL url = new URL(request);
            con = (HttpURLConnection) url.openConnection();

            // optional default is GET
            con.setRequestMethod("GET");
        } catch (IOException e) {
            LOGGER.error("Open connection of url failed!", e);
        }

        try (BufferedReader reader = new BufferedReader(new InputStreamReader(con.getInputStream()))) {
            String inputLine;
            while ((inputLine = reader.readLine()) != null) {
                response.append(inputLine);
            }
        } catch (IOException ee) {
            LOGGER.error("Get response failed!", ee);
        }
        return response.toString();
    }

    /**
     * Get tourop list from TourOperator list.
     *
     * @param opList
     * @return
     */
    static List<String> getTourOpList(List<TourOperator> opList) {
        List<String> l = new ArrayList<>();
        for (TourOperator t : opList) {
            l.add(t.getTourop());
        }
        return l;
    }

    /**
     * Internal use, don't public!
     *
     * return 3 list to update/insert/remove va_aktiv_cfg table.
     * list 0: to be removed tourops.
     * list 1: to stay/update tourops.
     * list 2: to be insert torops.
     *
     * @param oldOpList
     * @param newOpList
     * @return
     */
    static List<List<TourOperator>> getThreeToUpdateVaaktivCfgs(List<TourOperator> oldOpList, List<TourOperator> newOpList) {
        List<TourOperator> deleteList = (List<TourOperator>) CollectionUtils.removeAll(oldOpList, newOpList);
        List<TourOperator> stayList = (List<TourOperator>) CollectionUtils.retainAll(newOpList, oldOpList);
        List<TourOperator> insertList = (List<TourOperator>) CollectionUtils.removeAll(newOpList, oldOpList);
        List<List<TourOperator>> lists = Lists.newArrayList(deleteList, stayList, insertList);
        return lists;
    }

    /**
     * TEST
     *
     * @param args
     */
    public static void main(String[] args) {
        List<String> l1 = Lists.newArrayList("a", "b", "c");
        List<String> l2 = Lists.newArrayList("a", "b", "e");
        List<String> l3 = Lists.newArrayList("a", "b", "c", "d");
        List<String> l4 = Lists.newArrayList("x", "y", "z", "z");
        CollectionUtils.retainAll(l2, l1); // stay
        CollectionUtils.removeAll(l2, l1); // remove
        CollectionUtils.removeAll(l1, l2); // insert
        CollectionUtils.subtract(l1, l2);
    }

}
