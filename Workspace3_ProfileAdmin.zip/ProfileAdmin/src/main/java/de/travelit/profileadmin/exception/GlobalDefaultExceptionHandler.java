package de.travelit.profileadmin.exception;

import java.net.ConnectException;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.core.annotation.AnnotationUtils;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.support.RequestContext;

import com.google.common.base.Strings;

import de.travelit.profileadmin.Constants;

@ControllerAdvice
public class GlobalDefaultExceptionHandler {
    private static final Logger LOGGER = Logger.getLogger(GlobalDefaultExceptionHandler.class);

    public static final String AJAX_ERROR_DIALOG = "global_error_ajax_dialog";
    public static final String ERROR_DIALOG = "global_error_dialog";
    public static final String ERROR_HTTP_DIALOG = "global_http_dialog";

    @ExceptionHandler(value = {HttpRequestMethodNotSupportedException.class, ConnectException.class})
    public ModelAndView httpErrorHandler(HttpServletRequest request, HttpRequestMethodNotSupportedException ex) throws Exception {
        RequestContext requestContext = new RequestContext(request);
        ModelAndView mav = new ModelAndView();
        mav.addObject("title", requestContext.getMessage("error"));
        mav.addObject("message", requestContext.getMessage("HttpRequestMethodNotSupportedException"));
        LOGGER.error(request.getRequestURI(), ex);
        mav.setViewName(ERROR_HTTP_DIALOG);
        return mav;
    }

    @ExceptionHandler(value = Exception.class)
    public ModelAndView defaultErrorHandler(HttpServletRequest request, Exception ex) throws Exception {
        // If the exception is annotated with @ResponseStatus retrun, throw it and let
        // the framework handle it - like the OrderNotFoundException example at the start of this post.
        // AnnotationUtils is a Spring Framework utility class.
        if (AnnotationUtils.findAnnotation(ex.getClass(), ResponseStatus.class) != null) {
            LOGGER.error(request.getRequestURI(), ex);
            throw ex;
        }
        RequestContext requestContext = new RequestContext(request);
        ModelAndView mav = new ModelAndView();
        mav.addObject("title", requestContext.getMessage("error"));
        mav.addObject("message", requestContext.getMessage("error_msg"));
        LOGGER.error(request.getRequestURI(), ex);

        // I use ajax and form post to send request to controller.
        // Using ajax I can directly draw a finish dialog on jsp page without switching page.
        // Using post must goto next page.
        // If there is exception in controller, I want to show a error dialog on jsp page.
        // With ajax the error dialog directly shows on page, but by post the dialog will show anther page.
        // I add a custom header by ajax to distinguish how did I post request, and use different dialogs.
        String fromAjax = request.getHeader(Constants.REQUEST_FROM_AJAX);
        if (Strings.isNullOrEmpty(fromAjax)) {
            mav.setViewName(ERROR_DIALOG);
        } else {
            mav.setViewName(AJAX_ERROR_DIALOG);
        }
        return mav;
    }

}
