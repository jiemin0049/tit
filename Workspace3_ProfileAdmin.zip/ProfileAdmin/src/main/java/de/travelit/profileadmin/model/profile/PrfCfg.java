package de.travelit.profileadmin.model.profile;

import java.sql.Date;

public class PrfCfg {
    private int cfg;
    private boolean status;
    private Date licenceValidto;
    private Integer primaryCfg;
    private String name;
    private boolean affiliates;
    private int maxdays;
    private String xpwp;
    private String debitoreNumber;
    private String bumaAgency;
    private String terminal;
    private String password;
    private String terminalweb;
    private String passwordweb;
    private String email;
    private boolean onrequest;
    private boolean opControl;
    private int erv;
    private int configmode;
    private String tuiAgencyNumber;
    private int online;
    private String onlineTill;
    private String agencyNumber;
    private String inkasso;
    private int fromMin;
    private String fromMin1;
    private int bookto;
    private String otagtc;
    private int maxPricediff;
    private boolean hotelInfoCenter;
    private String giataIhgUid;
    private String giataXmluser;
    private String giataXmlpwd;
    private int layoutId;
    private String comment;
    private int mainPercentage;
    private int mainFix;

    public int getCfg() {
        return cfg;
    }

    public void setCfg(int cfg) {
        this.cfg = cfg;
    }

    public boolean isStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }

    public Date getLicenceValidto() {
        return licenceValidto;
    }

    public void setLicenceValidto(Date licenceValidto) {
        this.licenceValidto = licenceValidto;
    }

    public Integer getPrimaryCfg() {
        return primaryCfg;
    }

    public void setPrimaryCfg(Integer primaryCfg) {
        this.primaryCfg = primaryCfg;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public boolean isAffiliates() {
        return affiliates;
    }

    public void setAffiliates(boolean affiliates) {
        this.affiliates = affiliates;
    }

    public int getMaxdays() {
        return maxdays;
    }

    public void setMaxdays(int maxdays) {
        this.maxdays = maxdays;
    }

    public String getXpwp() {
        return xpwp;
    }

    public void setXpwp(String xpwp) {
        this.xpwp = xpwp;
    }

    public String getDebitoreNumber() {
        return debitoreNumber;
    }

    public void setDebitoreNumber(String debitoreNumber) {
        this.debitoreNumber = debitoreNumber;
    }

    public String getBumaAgency() {
        return bumaAgency;
    }

    public void setBumaAgency(String bumaAgency) {
        this.bumaAgency = bumaAgency;
    }

    public String getTerminal() {
        return terminal;
    }

    public void setTerminal(String terminal) {
        this.terminal = terminal;
    }

    public boolean isHotelInfoCenter() {
        return hotelInfoCenter;
    }

    public void setHotelInfoCenter(boolean hotelInfoCenter) {
        this.hotelInfoCenter = hotelInfoCenter;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getTerminalweb() {
        return terminalweb;
    }

    public void setTerminalweb(String terminalweb) {
        this.terminalweb = terminalweb;
    }

    public String getPasswordweb() {
        return passwordweb;
    }

    public void setPasswordweb(String passwordweb) {
        this.passwordweb = passwordweb;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public boolean isOnrequest() {
        return onrequest;
    }

    public void setOnrequest(boolean onrequest) {
        this.onrequest = onrequest;
    }

    public boolean isOpControl() {
        return opControl;
    }

    public void setOpControl(boolean opControl) {
        this.opControl = opControl;
    }

    public int getConfigmode() {
        return configmode;
    }

    public void setConfigmode(int configmode) {
        this.configmode = configmode;
    }

    public int getErv() {
        return erv;
    }

    public void setErv(int erv) {
        this.erv = erv;
    }

    public String getTuiAgencyNumber() {
        return tuiAgencyNumber;
    }

    public void setTuiAgencyNumber(String tuiAgencyNumber) {
        this.tuiAgencyNumber = tuiAgencyNumber;
    }

    public int getOnline() {
        return online;
    }

    public void setOnline(int online) {
        this.online = online;
    }

    public String getOnlineTill() {
        return onlineTill;
    }

    public void setOnlineTill(String onlineTill) {
        this.onlineTill = onlineTill;
    }

    public String getAgencyNumber() {
        return agencyNumber;
    }

    public void setAgencyNumber(String agencyNumber) {
        this.agencyNumber = agencyNumber;
    }

    public String getInkasso() {
        return inkasso;
    }

    public void setInkasso(String inkasso) {
        this.inkasso = inkasso;
    }

    public int getFromMin() {
        return fromMin;
    }

    public void setFromMin(int fromMin) {
        this.fromMin = fromMin;
    }

    public String getFromMin1() {
        return fromMin1;
    }

    public void setFromMin1(String fromMin1) {
        this.fromMin1 = fromMin1;
    }

    public int getBookto() {
        return bookto;
    }

    public void setBookto(int bookto) {
        this.bookto = bookto;
    }

    public String getOtagtc() {
        return otagtc;
    }

    public void setOtagtc(String otagtc) {
        this.otagtc = otagtc;
    }

    public int getMaxPricediff() {
        return maxPricediff;
    }

    public void setMaxPricediff(int maxPricediff) {
        this.maxPricediff = maxPricediff;
    }

    public String getGiataIhgUid() {
        return giataIhgUid;
    }

    public void setGiataIhgUid(String giataIhgUid) {
        this.giataIhgUid = giataIhgUid;
    }

    public String getGiataXmluser() {
        return giataXmluser;
    }

    public void setGiataXmluser(String giataXmluser) {
        this.giataXmluser = giataXmluser;
    }

    public String getGiataXmlpwd() {
        return giataXmlpwd;
    }

    public void setGiataXmlpwd(String giataXmlpwd) {
        this.giataXmlpwd = giataXmlpwd;
    }

    public int getLayoutId() {
        return layoutId;
    }

    public void setLayoutId(int layoutId) {
        this.layoutId = layoutId;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public int getMainPercentage() {
        return mainPercentage;
    }

    public void setMainPercentage(int mainPercentage) {
        this.mainPercentage = mainPercentage;
    }

    public int getMainFix() {
        return mainFix;
    }

    public void setMainFix(int mainFix) {
        this.mainFix = mainFix;
    }

}
