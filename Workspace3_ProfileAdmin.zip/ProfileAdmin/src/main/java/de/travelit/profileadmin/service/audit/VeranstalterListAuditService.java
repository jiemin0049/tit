package de.travelit.profileadmin.service.audit;

import java.util.Collection;
import java.util.List;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.google.common.base.Joiner;

import de.travelit.profileadmin.dao.ProtokollDao;
import de.travelit.profileadmin.model.Protokoll;

@Service
public class VeranstalterListAuditService {
    private static final Logger LOGGER = Logger.getLogger(VeranstalterListAuditService.class);

    @Autowired
    private ProtokollDao protokollDao;

    public void logRemoveValist(String username, String valistId) {
        Protokoll protokoll = new Protokoll();
        protokoll.setOperation("DELETE");
        protokoll.setTabelle("touroplist");
        protokoll.setField("code");
        protokoll.setPk1(valistId);
        protokoll.setUpdateBy(username);

        protokollDao.writeProtokoll(protokoll);
        LOGGER.info("Write Protokoll, " + username + " removes a VA-SET: " + valistId);

    }

    public void logCreateValist(String username, String valistId, String[] vacodeArray) {
        String vacodes = "";
        if (vacodeArray != null) {
            vacodes = Joiner.on("|").join(vacodeArray);
        }

        Protokoll protokoll = new Protokoll();
        protokoll.setOperation("INSERT");
        protokoll.setTabelle("touroplist");
        protokoll.setField("code");
        protokoll.setPk1(valistId);
        protokoll.setNewValue(vacodes);
        protokoll.setUpdateBy(username);

        protokollDao.writeProtokoll(protokoll);
        LOGGER.info("Write Protokoll, " + username + " creates a VA-SET: " + valistId);
    }

    public void logUpdateOperatorsFromValist(String username, String code, List<String> oldVacodes, List<String> newVacodes) {
        Collection<String> removeList = CollectionUtils.subtract(oldVacodes, newVacodes); // remove
        Collection<String> addList = CollectionUtils.subtract(newVacodes, oldVacodes); // add

        if (!removeList.isEmpty()) {
            String r = Joiner.on("|").join(removeList);
            Protokoll protokoll = new Protokoll();
            protokoll.setOperation("UPDATE");
            protokoll.setTabelle("touroplist");
            protokoll.setField("code");
            protokoll.setPk1(code);
            protokoll.setPk2("remove");
            protokoll.setOldValue(r);
            protokoll.setUpdateBy(username);
            protokollDao.writeProtokoll(protokoll);
            LOGGER.info("Write Protokoll, " + username + " removes veranstalters of VA-SET: " + code);
        }

        if (!addList.isEmpty()) {
            String a = Joiner.on("|").join(addList);

            Protokoll protokoll = new Protokoll();
            protokoll.setOperation("UPDATE");
            protokoll.setTabelle("touroplist");
            protokoll.setField("code");
            protokoll.setPk1(code);
            protokoll.setPk2("insert");
            protokoll.setNewValue(a);
            protokoll.setUpdateBy(username);
            protokollDao.writeProtokoll(protokoll);
            LOGGER.info("Write Protokoll, " + username + " adds veranstalters of VA-SET: " + code);
        }
    }

}
