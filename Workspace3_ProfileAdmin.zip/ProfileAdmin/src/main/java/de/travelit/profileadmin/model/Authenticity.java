package de.travelit.profileadmin.model;

import java.util.ArrayList;
import java.util.List;

public class Authenticity {
    private String name;
    private String fullname;
    private String password;
    private List<String> cfgList = new ArrayList<>();

    /**
    * <table border=1>
    *   <tr><th>Rolle</th><th>RolleId</th><th>Veranstalter</th><th>VA-Listen</th><th>CFG</th></tr>
    *   <tr><td>travel-IT Admin</td><td>1</td><td>anlegen, lesen, �ndern, sperren</td><td>anlegen, lesen,�ndern, sperren</td><td>anlegen, lesen,�ndern, sperren</td></tr>
    *   <tr><td>RB-Admin</td><td>8</td><td>keine</td><td>keine</td><td>lesen, �ndern</td></tr>
    *   <tr><td>Expedient</td><td>16</td><td>keine</td><td>keine</td><td>keine</td></tr>
    *   <tr><td>Applikation(neu)</td><td>32</td><td>lesen</td><td>lesen</td><td>lesen</td></tr>
    * </table>
    *
    * When an user has more than one roles (e.g. 17), this roleId saves the top role (e.g. 1).
    */
    private int roleId = 16;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getFullname() {
        return fullname;
    }

    public void setFullName(String fullname) {
        this.fullname = fullname;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public List<String> getCfgList() {
        return cfgList;
    }

    public void setCfgList(List<String> cfgList) {
        this.cfgList = cfgList;
    }

    public int getRoleId() {
        return roleId;
    }

    public void setRoleId(int roleId) {
        this.roleId = roleId;
    }

}
