package de.travelit.profileadmin.controller;

import java.util.Locale;
import java.util.ResourceBundle;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.ArrayUtils;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.LocaleResolver;
import org.springframework.web.servlet.support.RequestContextUtils;

import com.google.common.base.Strings;

import de.travelit.profileadmin.Constants;
import de.travelit.profileadmin.model.Authenticity;
import de.travelit.profileadmin.service.AuthenticityService;

@Controller
public class LoginController {

    private static final Logger LOGGER = Logger.getLogger(LoginController.class);

    // roles can use this application.
    private int[] roles = new int[] { 1, 8, 32 };

    @Autowired
    private AuthenticityService authenticityService;

    @RequestMapping("logincheck")
    public String loginCheck(final Authenticity authenticity, Model model, HttpServletRequest request, HttpServletResponse response) {
        String lang = request.getParameter("lang");
        if (lang == null) {
            lang = "de";
        }
        LocaleResolver localeResolver = RequestContextUtils.getLocaleResolver(request);
        Locale locale = StringUtils.parseLocaleString(lang);
        localeResolver.setLocale(request, response, locale);
        ResourceBundle resourceBundle = ResourceBundle.getBundle("messages", locale);
        Authenticity foundAuth = authenticityService.getAuthenticity(authenticity.getName(), authenticity.getPassword());
        if (Strings.isNullOrEmpty(foundAuth.getName()) || Strings.isNullOrEmpty(foundAuth.getRoleId() + "")) {
            String errorMessage = resourceBundle.getString("id_pwd_wrong");
            LOGGER.error(errorMessage);
            model.addAttribute("error", errorMessage);
            return "login";
        } else if (ArrayUtils.contains(roles, foundAuth.getRoleId())) {
            request.getSession().setAttribute(Constants.SESSION_KEY_AUTHENTICITY, foundAuth);
            return "mainpage";
        } else {
            String errorMessage = resourceBundle.getString("access_denied");
            LOGGER.error(errorMessage);
            model.addAttribute("error", errorMessage);
            return "login";
        }
    }

    @RequestMapping("/logout")
    public String logout(HttpServletRequest request) {
        //request.getSession().removeAttribute(Constants.SESSION_KEY_AUTHENTICITY);
        HttpSession session = request.getSession(false);
        if (session != null) {
            session.invalidate();
        }
        return "login";
    }
}
