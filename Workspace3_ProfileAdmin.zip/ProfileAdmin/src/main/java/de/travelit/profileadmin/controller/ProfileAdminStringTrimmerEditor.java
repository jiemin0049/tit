package de.travelit.profileadmin.controller;

import java.beans.PropertyEditorSupport;

/**
 *  Trim String of input field.
 *
 * @see org.springframework.beans.propertyeditors.StringTrimmerEditor
 */
public class ProfileAdminStringTrimmerEditor extends PropertyEditorSupport {

    public ProfileAdminStringTrimmerEditor() {
    }

    @Override
    public void setAsText(String text) {
        setValue(text == null ? null : text.trim());
    }

    @Override
    public String getAsText() {
        Object value = getValue();
        return (value != null ? value.toString() : "");
    }

}


