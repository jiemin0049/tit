package de.travelit.profileadmin.webservice;

import java.util.List;

import javax.jws.HandlerChain;
import javax.jws.WebService;

import org.springframework.beans.factory.annotation.Autowired;

import com.google.common.base.Strings;

import de.travelit.profileadmin.model.mixer.CfgMixer;
import de.travelit.profileadmin.model.mixer.CfgMixerList;
import de.travelit.profileadmin.service.MixerService;

@WebService(endpointInterface = "de.travelit.profileadmin.webservice.MixerWebService")
@HandlerChain(file = "handler_chains.xml")
public class MixerWebServiceImpl implements MixerWebService {

    @Autowired
    private MixerService mixerService;

    @Override
    public String sayHi(String name) {
        return "Hello " + name;
    }

    @Override
    public CfgMixerList getCfgs() {
        CfgMixerList list = new CfgMixerList();
        list.setCfgs(mixerService.getActiveCfgs());
        formatList(list.getCfgs());
        return list;
    }

    @Override
    public CfgMixerList getCfgsWithMixerType(String mixerType) {
        CfgMixerList list = new CfgMixerList();
        // Mixer Stage, Mixer Produktiv, Mixer LMplus
        // Valid Strings are: "001", "010", "100"
        if (mixerType.equals("001") || mixerType.equals("010") || mixerType.equals("100")) {
            list.setCfgs(mixerService.getCfgsWithMixerType(mixerType));
        }
        formatList(list.getCfgs());
        return list;
    }

    /**
     * Rule about xmlcfg and xmlxpwp for CfgMixer:
     *
     * If xsl is empty, set xmlcfg and xmlxpwp to empty.
     * If xsl is not empty, set xmlxpwp = xpwp, xmlcfg = cfg and xpwp = "free".
     *
     * e.g.
     * CFG;XPWP;XSL;XMLCFG;XMLXPWP;MAIL;NAME;VCHUBLIST;F1;CacheSource;F2;F3;F4
     * 26;H6T99M8W;;;;thoepfner@web.de;...
     * 25;free;<?xml version=1.0 encoding=ISO-8859-1 standalone=yes?><?xml-stylesheet href=/xsl/LMWEB-V40.XSL type=text/xsl?>;25;HGD7777;info@travel-it.de;...

     * @param list
     */
    private void formatList(List<CfgMixer> list) {
        for (CfgMixer mixer : list) {
            String xsl = mixer.getXsl();
            xsl = Strings.nullToEmpty(xsl);
            if (xsl.trim().isEmpty()) {
                mixer.setXmlcfg("");
                mixer.setXmlxpwp("");
            } else {
                mixer.setXmlcfg(Integer.toString(mixer.getCfgNumber()));
                mixer.setXmlxpwp(mixer.getXpwp());
                mixer.setXpwp("free");
            }
        }
    }

}
