package de.travelit.profileadmin.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "veranstalters")
public class TourOperatorList implements Serializable {

    private static final long serialVersionUID = -5815711195216442280L;

    private List<TourOperator> veranstalters = new ArrayList<TourOperator>();

    @XmlElement(name = "veranstalter")
    public List<TourOperator> getVeranstalters() {
        return veranstalters;
    }

    public void setVeranstalters(List<TourOperator> veranstalters) {
        this.veranstalters = veranstalters;
    }
}