package de.travelit.profileadmin.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.apache.commons.collections4.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.google.common.base.Strings;
import com.google.common.collect.HashMultimap;
import com.google.common.collect.SetMultimap;

import de.travelit.profileadmin.dao.CfgDao;
import de.travelit.profileadmin.dao.VeranstalterDao;
import de.travelit.profileadmin.dao.VeranstalterListDao;
import de.travelit.profileadmin.model.Range;
import de.travelit.profileadmin.model.TourOperator;
import de.travelit.profileadmin.model.TourOperatorChange;
import de.travelit.profileadmin.model.TouropList;
import de.travelit.profileadmin.model.ValistCfg;

@Service
@Transactional
public class VeranstalterListService {

    @Autowired
    private VeranstalterListDao vaListDao;

    @Autowired
    private VeranstalterDao vaDao;

    @Autowired
    private CfgDao cfgDao;

    @Transactional(propagation = Propagation.NOT_SUPPORTED, readOnly = true)
    public boolean hasVeranstalterSetBy(String shortname) {
        int i = vaListDao.getVeranstalterSetCountBy(shortname);
        return i > 0;

    }

    @Transactional(propagation = Propagation.NOT_SUPPORTED, readOnly = true)
    public List<TouropList> getVeranstalterSetList(String shortname, String name) {
        return vaListDao.getVeranstalterSetList(shortname, name);
    }

    @Transactional(propagation = Propagation.NOT_SUPPORTED, readOnly = true)
    public List<Range> getRangesBySetcodeList(String cfgNr, List<String> shortnames) {
        if (shortnames.isEmpty()) {
            return new ArrayList<Range>();
        }

        List<Range> rangeList = vaListDao.getRangesBySetcodeList(cfgNr, shortnames);
        return rangeList;
    }

    @Transactional(propagation = Propagation.NOT_SUPPORTED, readOnly = true)
    public List<Range> getRangesBySetcodeList(List<String> shortnames) {
        if (shortnames.isEmpty()) {
            return new ArrayList<Range>();
        }

        return getRangesBySetcodeList(new HashSet<String>(shortnames));
    }

    @Transactional(propagation = Propagation.NOT_SUPPORTED, readOnly = true)
    public List<TourOperator> getActiveTourOperators() {
        return vaDao.getActiveVeranstalterList();
    }

    @Transactional(propagation = Propagation.NOT_SUPPORTED, readOnly = true)
    public List<TourOperatorChange> getTourOperatorChangeList(String code) {
        List<TourOperator> alltouropList = getActiveTourOperators();
        List<TourOperator> touropList = getTourOperatorsBySetcode(code);

        List<TourOperatorChange> opChangeList = new ArrayList<>();
        for (TourOperator operator : alltouropList) {
            TourOperatorChange toc = new TourOperatorChange();
            toc.setTourop(operator.getTourop());
            toc.setTouropName(operator.getTouropName());
            toc.setActive(operator.getActive());
            toc.setServiceCharge(operator.getServiceCharge());

            if (contains(touropList, operator)) {
                toc.setSelected(true);
            }

            opChangeList.add(toc);
        }
        return opChangeList;
    }

    private boolean contains(List<TourOperator> list, TourOperator operator) {
        for (TourOperator op : list) {
            if (op.getTouropName().equals(operator.getTouropName()) && op.getTourop().equals(operator.getTourop())) {
                return true;
            }
        }
        return false;
    }

    @Transactional(propagation = Propagation.NOT_SUPPORTED, readOnly = true)
    public List<TourOperator> getTourOperatorsBySetcode(String code) {
         if (Strings.isNullOrEmpty(code)) {
             return new ArrayList<TourOperator>();
         }
        return getTourOperatorsBySetcodeList(new HashSet<String>(Arrays.asList(code)));
    }

    @Transactional(propagation = Propagation.NOT_SUPPORTED, readOnly = true)
    public List<TourOperator> getTourOperatorsBySetcodeList(Set<String> shortnames) {
        if (shortnames.isEmpty()) {
            return new ArrayList<TourOperator>();
        }
        return vaListDao.getTourOperatorsBySetcodeList(shortnames);
    }

    @Transactional(propagation = Propagation.NOT_SUPPORTED, readOnly = true)
    public List<Range> getRangesBySetcodeList(Set<String> shortnames) {
        if (shortnames.isEmpty()) {
            return new ArrayList<Range>();
        }
        return vaListDao.getRangesBySetcodeList(shortnames);
    }

    @Transactional(propagation = Propagation.NOT_SUPPORTED, readOnly = true)
    public boolean allVasetsValid(Set<String> shortnames) {
        if (shortnames.isEmpty()) {
            return false;
        }
        int count = vaListDao.vasetsCount(shortnames);
        return count == shortnames.size();
    }

    public void insertValist(String shortname, String name, String[] vacodeArray) {
        List<String> vacodeList = new ArrayList<>();
        if (null != vacodeArray) {
            vacodeList = Arrays.asList(vacodeArray);
        }

        vaListDao.insertValist(shortname, name);
        if (!vacodeList.isEmpty()) {
            vaListDao.insertValistWith(shortname, vacodeList);
        }

    }

    @Transactional(propagation = Propagation.NOT_SUPPORTED, readOnly = true)
    public List<String> getOperatorsFor(String code) {
        return vaListDao.getVacodeListByCode(code);
    }

    /**
     * Whether vaset is used by a CFG.
     * @param code vaset id.
     * @return Cfg list which are using given vaset.
     */
    @Transactional(propagation = Propagation.NOT_SUPPORTED, readOnly = true)
    public List<String> isVasetUsedByCfg(String code) {
        return vaListDao.getCfgListBy(code);
    }

    public void removeVaset(String code) {
        vaListDao.removeAllOperatorsBySet(code);
        vaListDao.removeFromValist(code);
    }

    public void updateValist(String code, String[] vacodeArray) {
        List<String> vacodeList = new ArrayList<String>(Arrays.asList(vacodeArray));

        List<String> oldTouropList = getOperatorsFor(code);
        List<String> cfgList = vaListDao.getCfgListBy(code);

        // Update all cfgs that use this valist (code)
        updateVaaktivCfgs(cfgList, code, oldTouropList, vacodeList);

        //update valist
        internUpdateValist(code, oldTouropList, vacodeList);

        // Delete lineflight
        List<String> deleteList = (List<String>) CollectionUtils.removeAll(oldTouropList, vacodeList);
        if (!deleteList.isEmpty()) {
            cfgDao.removeLinienFlugProvisionenByOperators(deleteList);
        }
    }

    private void internUpdateValist(String code, List<String> oldTouropList, List<String> vacodeList) {
        List<String> insertList = (List<String>) CollectionUtils.removeAll(vacodeList, oldTouropList);
        List<String> deleteList = (List<String>) CollectionUtils.removeAll(oldTouropList, vacodeList);

        if (!insertList.isEmpty()) {
            vaListDao.insertValistWith(code, insertList);
        }
        if (!deleteList.isEmpty()) {
            vaListDao.removeOperatorsFor(code, deleteList);
        }
    }

    private void updateVaaktivCfgs(List<String> cfgList, String code, List<String> oldTouropList, List<String> vacodeList) {
        if (cfgList.isEmpty()) {
            return;
        }

        //Only insert TourOperators in va_activ_cfg for CFG,
        //when TourOperators are not contained in CFG. If a TourOperator was in va_activ_cfg for CFG,
        //don't need to insert it.
        SetMultimap<String, TourOperator> insertMap = getInsertMapForCfgs(cfgList, vacodeList);
        if (!insertMap.isEmpty()) {
            vaListDao.insertTourop(insertMap);
        }


        List<String> deleteList = (List<String>) CollectionUtils.removeAll(oldTouropList, vacodeList);
        if (!deleteList.isEmpty()) {
            //VAs in deleteList can not be removed from va_aktiv_cfgs table simply,
            //because other VA-SETs maybe contain those VAs also, and Cfgs have those VA-SETs.
            //e.g. a CFG 1234 has 2 VA-SETs AB and BC, AB has VAs (4U, 4UD), BC has VAs (4U, 5VF).
            //When remove 4U from AB, 4U should not be remove from table va_aktiv_cfgs for CFG 1234,
            //because BC has 4U also.
            SetMultimap<String, String> valistCodeMap = valistCodeMap(deleteList);
            SetMultimap<String, String> cfgVasetMap = getCfgVasetMap(cfgList);
            removeTouropForCfgs(cfgVasetMap, valistCodeMap);
        }
    }

    private SetMultimap<String, TourOperator> getInsertMapForCfgs(List<String> cfgList, List<String> vacodeList) {
        List<TourOperator> oplist = vaDao.getVeranstalterList(vacodeList);
        Map<String, TourOperator> opMap = new HashMap<>();
        for (TourOperator op : oplist) {
            opMap.put(op.getTourop(), op);
        }

        SetMultimap<String, TourOperator> setMultimap = HashMultimap.create();
        for (String cfgId : cfgList) {
            List<String> touropList = cfgDao.getTouropFromVaaktivCfgs(Integer.parseInt(cfgId));
            Collection<String> notContains = CollectionUtils.subtract(vacodeList, touropList);
            for (String c : notContains) {
                setMultimap.put(cfgId, opMap.get(c));
            }
        }
        return setMultimap;
    }

    private SetMultimap<String, String> valistCodeMap(List<String> deleteList) {
        //Key: tourop
        //value (Set): VA-SETs which contains tourop (key).
        SetMultimap<String, String> setMultimap = HashMultimap.create();
        for (String d : deleteList) {
            List<String> codeList = vaListDao.getCodeListByVacode(d);
            setMultimap.putAll(d, codeList);
        }
        return setMultimap;
    }

    private SetMultimap<String, String> getCfgVasetMap(List<String> cfgList) {
        SetMultimap<String, String> setMultimap = HashMultimap.create();
        for (String cfg : cfgList) {
            List<ValistCfg> valistCfg = cfgDao.getValistCfgByCfg(Integer.parseInt(cfg));
            for (ValistCfg vc : valistCfg) {
                setMultimap.put(cfg, vc.getValistCfgPK().getCode());
            }
        }
        return setMultimap;
    }

    private void removeTouropForCfgs(SetMultimap<String, String> cfgVasetMap, SetMultimap<String, String> valistCodeMap) {
        SetMultimap<String, String> setMultimap = HashMultimap.create();
        for (Entry<String, Collection<String>> entry : cfgVasetMap.asMap().entrySet()) {
            String cfg = entry.getKey();
            Collection<String> vaset = entry.getValue();
            for (Entry<String, Collection<String>> valistCodeEntry : valistCodeMap.asMap().entrySet()) {
                Collection<String> valistCode = valistCodeEntry.getValue();
                if (CollectionUtils.retainAll(vaset, valistCode).size() < 2) {
                    String va = valistCodeEntry.getKey();
                    setMultimap.put(cfg, va);
                }
            }
        }
        vaListDao.deleteTourop(setMultimap);
    }

    /**
     *
     * @param user who does the change.
     * @param code
     * @param name
     */
    public void changeName(String user, String code, String name) {
        vaListDao.changeName(user, code, name);
    }
}