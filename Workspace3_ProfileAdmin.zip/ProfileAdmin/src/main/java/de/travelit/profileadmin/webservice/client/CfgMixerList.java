
package de.travelit.profileadmin.webservice.client;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java-Klasse f�r cfgMixerList complex type.
 *
 * <p>Das folgende Schemafragment gibt den erwarteten Content an, der in dieser Klasse enthalten ist.
 *
 * <pre>
 * &lt;complexType name="cfgMixerList">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="cfg" type="{http://webservice.profileadmin.travelit.de/}cfgMixer" maxOccurs="unbounded" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 *
 *
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "cfgMixerList", propOrder = {
    "cfg"
})
public class CfgMixerList {

    protected List<CfgMixer> cfg;

    /**
     * Gets the value of the cfg property.
     *
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the cfg property.
     *
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getCfg().add(newItem);
     * </pre>
     *
     *
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link CfgMixer }
     *
     *
     */
    public List<CfgMixer> getCfg() {
        if (cfg == null) {
            cfg = new ArrayList<CfgMixer>();
        }
        return this.cfg;
    }

}
