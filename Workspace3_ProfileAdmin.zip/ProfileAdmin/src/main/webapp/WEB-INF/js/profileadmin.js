/**
 * hotelo input test.
 *
 * @param type
 * @param input
 */
function validate1(input, errorMsgs) {
  var id='#'+input;
  var valu = $(id).val();
  if (isNaN(valu) || valu.trim()=='') { showErrorDialog(errorMsgs[0]); $(id).val('0');  return;}
  if(valu==0) { }
  else {
      if(valu<=7) { showErrorDialog(errorMsgs[1]); $(id).val('8'); }
      if(valu>=16) { showErrorDialog(errorMsgs[2]); $(id).val('15'); }
  }
};

function validate2(input, errorMsgs) {
  var id='#'+input;
  var valu = $(id).val();
    if ( isNaN(valu) ) { showErrorDialog(errorMsgs[0]); $(id).val('1');  return;}
    if(valu<=0) { showErrorDialog(errorMsgs[1]);$(id).val('1'); }
    if(valu>=100) { showErrorDialog(errorMsgs[2]);$(id).val('99'); }
};

function setServiceCharterValue(jsonObject) {
    var value = jsonObject._5VF + '';
    var myArray = value.split(',');
    $('#SG_5VFKURZ').val(myArray[0].trim());
    $('#SG_5VFMITTEL').val(myArray[1].trim());
    $('#SG_5VFFERN').val(myArray[2].trim());

    value = jsonObject.AB + '';
    myArray = value.split(',');
    $('#SG_ABKURZ').val(myArray[0].trim());
    $('#SG_ABMITTEL').val(myArray[1].trim());
    $('#SG_ABFERN').val(myArray[2].trim());

    value = jsonObject.ALL + '';
    myArray = value.split(',');
    $('#SG_ALLKURZ').val(myArray[0].trim());
    $('#SG_ALLMITTEL').val(myArray[1].trim());
    $('#SG_ALLFERN').val(myArray[2].trim());

    value = jsonObject.CFI + '';
    myArray = value.split(',');
    $('#SG_CFIKURZ').val(myArray[0].trim());
    $('#SG_CFIMITTEL').val(myArray[1].trim());
    $('#SG_CFIFERN').val(myArray[2].trim());

    value = jsonObject.FTI + '';
    myArray = value.split(',');
    $('#SG_FTIKURZ').val(myArray[0].trim());
    $('#SG_FTIMITTEL').val(myArray[1].trim());
    $('#SG_FTIFERN').val(myArray[2].trim());

    value = jsonObject.ICC + '';
    myArray = value.split(',');
    $('#SG_ICCKURZ').val(myArray[0].trim());
    $('#SG_ICCMITTEL').val(myArray[1].trim());
    $('#SG_ICCFERN').val(myArray[2].trim());

    value = jsonObject.ITS + '';
    myArray = value.split(',');
    $('#SG_ITSKURZ').val(myArray[0].trim());
    $('#SG_ITSMITTEL').val(myArray[1].trim());
    $('#SG_ITSFERN').val(myArray[2].trim());

    value = jsonObject.JAHN + '';
    myArray = value.split(',');
    $('#SG_JAHNKURZ').val(myArray[0].trim());
    $('#SG_JAHNMITTEL').val(myArray[1].trim());
    $('#SG_JAHNFERN').val(myArray[2].trim());

    value = jsonObject.OGE + '';
    myArray = value.split(',');
    $('#SG_OGEKURZ').val(myArray[0].trim());
    $('#SG_OGEMITTEL').val(myArray[1].trim());
    $('#SG_OGEFERN').val(myArray[2].trim());

    value = jsonObject.TIP + '';
    myArray = value.split(',');
    $('#SG_TIPKURZ').val(myArray[0].trim());
    $('#SG_TIPMITTEL').val(myArray[1].trim());
    $('#SG_TIPFERN').val(myArray[2].trim());

    value = jsonObject.NEC + '';
    myArray = value.split(',');
    $('#SG_NECKURZ').val(myArray[0].trim());
    $('#SG_NECMITTEL').val(myArray[1].trim());
    $('#SG_NECFERN').val(myArray[2].trim());
};

function setBuchungsmodusValue(jsonObject) {
    $('[name=fromMin]').val(jsonObject.fromMin);
    $('[name=fromMin1]').val(jsonObject.fromMin1);
    $('[name=online]').val(jsonObject.online);
    $('[name=bookto]').val(jsonObject.bookto);

    var till = jsonObject.onlineTill + '';
    var myArray = till.split('/');
    $('#TIME1').val(myArray[0].trim());
    $('#TIME2').val(myArray[1].trim());
    $('#TIME3').val(myArray[2].trim());
};

function saveCSV(csv) {
  if (csv == '') {
      alert("Can not save CSV, invalid data");
      return;
  }

  //Generate a file name
  var fileName = "protokoll_LMweb_profil.csv";
  //Initialize file format you want csv or xls
  var uri = 'data:text/csv;charset=utf-8,' + escape(csv);

  if(!detectIE()) {
      // Use HTML5 'download', this works with firefox and chrome
      $('#link_id').prop("href", uri);
      $('#link_id').prop("download", fileName);
      $('#link_id')[0].click();
  } else {
      //IE
      var version = detectIE();
      if(version >= 10) {
         var textFileAsBlob = new Blob([csv], {type: 'text/plain'});
         window.navigator.msSaveBlob(textFileAsBlob, fileName);
      } else {
        var frame = document.createElement('iframe');
        frame.style.cssText='display:none';
        document.body.appendChild(frame);

        frame.contentWindow.document.open("text/html", "replace");
        frame.contentWindow.document.write(csv);
        frame.contentWindow.document.close();
        frame.contentWindow.focus();
        frame.contentWindow.document.execCommand('SaveAs', true, fileName);

        document.body.removeChild(frame);
      }
  }
}

function JSON2CSV(JSONData, writeHeader) {
  //If JSONData is not an object then JSON.parse will parse the JSON string in an Object
  var arrData = typeof JSONData != 'object' ? JSON.parse(JSONData) : JSONData;

  var CSV = '';

  //This condition will generate the Header in csv file
  if (writeHeader) {
    var row = "";
    //This loop will extract the label from 1st index of on array
    for (var index in arrData[0]) {
        //Now convert each value to string and comma-seprated
        row += index + ',';
    }
    row = row.slice(0, -1);
    //append Label row with line break
    CSV += row + '\r\n';
  }

  //1st loop is to extract each row
  for (var i = 0; i < arrData.length; i++) {
    var row = "";
    var comma ="";
    //2nd loop will extract each column and convert it in string comma-seprated
    for (var index in arrData[i]) {
        var o = arrData[i][index];
        if($.isEmptyObject(o)) {
            o = "";
        }
        row += comma + '"' + o + '"';
        comma=",";
    }
    row.slice(0, row.length - 1);
    //add a line break after each row
    CSV += row + '\r\n';
  }

  if (CSV == '') {
    alert("Invalid data");
  }

  return CSV;
}

function detectIE() {
   var ua = window.navigator.userAgent;

    var msie = ua.indexOf('MSIE ');
    if (msie > 0) {
        // IE 10 or older => return version number
        return parseInt(ua.substring(msie + 5, ua.indexOf('.', msie)), 10);
    }

    var trident = ua.indexOf('Trident/');
    if (trident > 0) {
        // IE 11 => return version number
        var rv = ua.indexOf('rv:');
        return parseInt(ua.substring(rv + 3, ua.indexOf('.', rv)), 10);
    }

    var edge = ua.indexOf('Edge/');
    if (edge > 0) {
       // Edge (IE 12+) => return version number
       return parseInt(ua.substring(edge + 5, ua.indexOf('.', edge)), 10);
    }

    // other browser
    return false;
}