CREATE OR REPLACE FUNCTION table_update_func_pk1_pk2() RETURNS trigger AS $$
DECLARE
    ri RECORD;
    old_value TEXT;
    new_value TEXT;
BEGIN
    FOR ri IN
        SELECT column_name FROM information_schema.columns
        WHERE
            table_schema = quote_ident('public')
        AND table_name = quote_ident(TG_TABLE_NAME)
        ORDER BY ordinal_position
    LOOP
        EXECUTE 'SELECT ($1).' || ri.column_name || '::text' INTO new_value USING NEW;
        EXECUTE 'SELECT ($1).' || ri.column_name || '::text' INTO old_value USING OLD;

        IF new_value IS DISTINCT FROM old_value AND ri.column_name != 'update_by' THEN
            INSERT INTO protokoll(datetime, operation, tabelle, field, pk1, pk2, old_value, new_value, update_by)
                   VALUES(now(), TG_OP, TG_TABLE_NAME, ri.column_name, NEW.cfg, NEW.tourop, old_value, new_value, NEW.update_by);
       END IF;
    END LOOP;
    RETURN NEW;
END;
$$  LANGUAGE plpgsql;


CREATE TRIGGER va_aktiv_cfgs_update_tg
  AFTER UPDATE ON va_aktiv_cfgs
  FOR EACH ROW
  EXECUTE PROCEDURE table_update_func_pk1_pk2();

CREATE TRIGGER servicecharges_cfg_update_tg
  AFTER UPDATE ON servicecharges_cfg
  FOR EACH ROW
  EXECUTE PROCEDURE table_update_func_pk1_pk2();

CREATE TRIGGER lineflight_cfg_update_tg
  AFTER UPDATE ON lineflight_cfg
  FOR EACH ROW
  EXECUTE PROCEDURE table_update_func_pk1_pk2();