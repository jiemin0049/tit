CREATE TABLE hotelocalc (
   cfg int references cfglist(cfg) NOT NULL PRIMARY KEY,
   mainpercentage   int default 0,
   main_fix         int default 0,
   update_by varchar(255)
);
