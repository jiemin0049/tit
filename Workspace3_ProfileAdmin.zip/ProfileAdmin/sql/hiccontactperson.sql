CREATE TABLE hiccontactperson (
   tourop varchar(4) references touroperator(tourop) NOT NULL,
   anrede varchar(5),
   surname varchar(25),
   name varchar(35),
   email varchar(50),
   telephone varchar(20),
   department varchar(25),
   update_by varchar(255),
   PRIMARY KEY(tourop)
);

CREATE OR REPLACE FUNCTION hiccontactperson_update_func() RETURNS trigger AS $$
DECLARE
    ri RECORD;
    old_value TEXT;
    new_value TEXT;
BEGIN
    FOR ri IN
        SELECT column_name FROM information_schema.columns
        WHERE
            table_schema = quote_ident('public')
        AND table_name = quote_ident(TG_TABLE_NAME)
        ORDER BY ordinal_position
    LOOP
        EXECUTE 'SELECT ($1).' || ri.column_name || '::text' INTO new_value USING NEW;
        EXECUTE 'SELECT ($1).' || ri.column_name || '::text' INTO old_value USING OLD;

        IF new_value IS DISTINCT FROM old_value AND ri.column_name != 'update_by' THEN
            INSERT INTO protokoll(datetime, operation, tabelle, field, pk1, old_value, new_value, update_by)
                   VALUES(now(), TG_OP, TG_TABLE_NAME, ri.column_name, NEW.tourop, old_value, new_value, NEW.update_by);
       END IF;
    END LOOP;
    RETURN NEW;
END;
$$  LANGUAGE plpgsql;

CREATE TRIGGER hiccontactperson_update_tg
  AFTER UPDATE
  ON hiccontactperson
  FOR EACH ROW
  EXECUTE PROCEDURE hiccontactperson_update_func();