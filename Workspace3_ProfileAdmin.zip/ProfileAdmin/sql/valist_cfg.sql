CREATE TABLE valist_cfg (

  cfg int references cfglist(cfg) NOT NULL,

  code varchar(2) references touroplist(code) NOT NULL,

  update_by varchar(255),

  PRIMARY KEY (cfg, code)

);