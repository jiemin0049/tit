CREATE TABLE touroperator (
   tourop    varchar(4) NOT NULL PRIMARY KEY,
   touropname varchar(30) NOT NULL,
   payment varchar(20) NOT NULL,
   gtc_su TEXT NOT NULL,
   gtc_wi TEXT NOT NULL,
   date_gtc_su date,
   date_gtc_wi date,
   tourop_giata varchar(5) NOT NULL,
   fallback_giata varchar(5),
   source_cache boolean NOT NULL default false,
   source_hub boolean  NOT NULL default false,
   servicecharge integer default 0, -- 0 - without, 1- charterflug, 2-Linienflug
   active_since date,
   active boolean NOT NULL default false,
   active_giata boolean NOT NULL default false,
   update_by varchar(255) NOT NULL
   --CONSTRAINT u_constraint UNIQUE (tourop_giata)
);

CREATE OR REPLACE FUNCTION touroperator_update_func() RETURNS TRIGGER AS $$
DECLARE
    ri RECORD;
    old_value TEXT;
    new_value TEXT;
    update_user TEXT;
    pk TEXT;
BEGIN
    RAISE NOTICE E'\n    Operation: %\n    Schema: %\n    Table: %',
        TG_OP,
        TG_TABLE_SCHEMA,
        TG_TABLE_NAME;

    update_user := NEW.update_by;
    pk := NEW.tourop;

    FOR ri IN
        SELECT ordinal_position, column_name, data_type
        FROM information_schema.columns
        WHERE
            table_schema = quote_ident('public')
        AND table_name = quote_ident('touroperator')
        ORDER BY ordinal_position
    LOOP
        EXECUTE 'SELECT ($1).' || ri.column_name || '::text' INTO new_value USING NEW;
        EXECUTE 'SELECT ($1).' || ri.column_name || '::text' INTO old_value USING OLD;

        IF new_value IS DISTINCT FROM old_value AND ri.column_name != 'update_by' THEN

            INSERT INTO protokoll(datetime, operation, tabelle, field, pk1, old_value, new_value, update_by)
                   VALUES(now(), TG_OP, TG_TABLE_NAME, ri.column_name, pk, old_value, new_value, update_user);

        -- print log
        RAISE NOTICE E'Column\n    number: %\n    name: %\n    type: %\n    old: %\n    new: %\n    update_by: %.',
            ri.ordinal_position,
            ri.column_name,
            ri.data_type,
            old_value,
            new_value,
            update_user;
       END IF;
    END LOOP;
    RETURN NEW;
END;
$$  LANGUAGE plpgsql;

CREATE TRIGGER touroperator_update_tg
  AFTER UPDATE
  ON touroperator
  FOR EACH ROW
  EXECUTE PROCEDURE touroperator_update_func();



CREATE OR REPLACE FUNCTION touroperator_insert_func() RETURNS TRIGGER AS $$
BEGIN
    INSERT INTO protokoll(datetime, operation, tabelle, field, pk1, new_value, update_by)
           VALUES(now(), TG_OP, TG_TABLE_NAME, 'tourop',NEW.tourop, NEW.touropname, NEW.update_by);
    RETURN NEW;
END;
$$  LANGUAGE plpgsql;

CREATE TRIGGER touroperator_insert_tg
  AFTER INSERT
  ON touroperator
  FOR EACH ROW
  EXECUTE PROCEDURE touroperator_insert_func();




