CREATE TABLE hiccontent (
   cfg int references cfglist(cfg) NOT NULL,
   hotelcontent boolean  default true,
   catalog boolean  default true,
   climate boolean  default true,
   video boolean  default true,
   contact boolean  default true,
   facts boolean  default true,
   geo boolean  default true,
   reviews boolean default false,
   color1 varchar(8),
   color2 varchar(8),
   color3 varchar(8),
   fontfamily varchar(80),
   fontsize varchar(10),
   update_by varchar(255),
   PRIMARY KEY(cfg)
);