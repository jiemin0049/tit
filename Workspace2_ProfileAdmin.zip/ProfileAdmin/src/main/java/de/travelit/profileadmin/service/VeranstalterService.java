package de.travelit.profileadmin.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import de.travelit.profileadmin.dao.CfgDao;
import de.travelit.profileadmin.dao.VeranstalterDao;
import de.travelit.profileadmin.dao.VeranstalterListDao;
import de.travelit.profileadmin.model.HicContactPerson;
import de.travelit.profileadmin.model.TourOperator;

@Service
@Transactional
public class VeranstalterService {

    @Autowired
    private VeranstalterDao veranstalterDao;

    @Autowired
    private VeranstalterListDao vaListDao;

    @Autowired
    private CfgDao cfgDao;

    @Transactional(propagation = Propagation.NOT_SUPPORTED, readOnly = true)
    public List<TourOperator> getVeranstalterList(String code, String name) {
        return veranstalterDao.getVeranstalterList(code, name);
    }

    @Transactional(propagation = Propagation.NOT_SUPPORTED, readOnly = true)
    public List<TourOperator> getActiveVeranstalterList() {
        return veranstalterDao.getActiveVeranstalterList();
    }

    @Transactional(propagation = Propagation.NOT_SUPPORTED, readOnly = true)
    public TourOperator getVeranstalterByCode(String code) {
        return veranstalterDao.getVeranstalterByCode(code);
    }

    @Transactional(propagation = Propagation.NOT_SUPPORTED, readOnly = true)
    public HicContactPerson getHicContactPersonByCode(String code) {
        return veranstalterDao.getHicContactPersonByCode(code);
    }

    /**
     *
     * @param user who does this saving operation.
     * @param tourOperator
     */
    public void save(String user, TourOperator tourOperator, HicContactPerson contactPerson) {
        tourOperator.setUpdateBy(user);
        veranstalterDao.save(tourOperator);
        contactPerson.setUpdateBy(user);
        veranstalterDao.save(contactPerson);
    }

    public void update(String user, final TourOperator tourOperator, final HicContactPerson contactPerson) {
        tourOperator.setUpdateBy(user);
        veranstalterDao.update(tourOperator);
        if (!tourOperator.getActive()) {
            // If a touroperator is deactive, delete it from vaset, cfg...
            String tourop = tourOperator.getTourop();
            cfgDao.removeVaaktivCfgs(tourop);
            vaListDao.removeOperator(tourop);
        }

        // update hic contact person
        contactPerson.setUpdateBy(user);
        veranstalterDao.update(contactPerson);
    }

}
