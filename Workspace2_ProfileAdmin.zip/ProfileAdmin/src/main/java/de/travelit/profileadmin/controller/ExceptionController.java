package de.travelit.profileadmin.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.support.RequestContext;

@Controller
public class ExceptionController {

    @RequestMapping("/sessiontimeout")
    public ModelAndView sessionTimeout(HttpServletRequest request) {
        RequestContext requestContext = new RequestContext(request);
        ModelAndView mav = new ModelAndView();
        mav.addObject("title", requestContext.getMessage("error"));
        mav.addObject("message", requestContext.getMessage("SessionTimeout"));
        mav.setViewName("global_http_dialog");
        return mav;
    }
}
