package de.travelit.profileadmin.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "hotelocalc")
public class HoteloAufschlag {
    @Id
    private Integer cfg;

    @Column(name = "mainpercentage")
    private int hoteloAufschlag;

    @Column(name = "main_fix")
    private int minAufschlag;

    @Column(name = "update_by")
    private String updateBy;

    public Integer getCfg() {
        return cfg;
    }

    public void setCfg(Integer cfg) {
        this.cfg = cfg;
    }

    public int getHoteloAufschlag() {
        return hoteloAufschlag;
    }

    public void setHoteloAufschlag(int hoteloAufschlag) {
        this.hoteloAufschlag = hoteloAufschlag;
    }

    public int getMinAufschlag() {
        return minAufschlag;
    }

    public void setMinAufschlag(int minAufschlag) {
        this.minAufschlag = minAufschlag;
    }

    public String getUpdateBy() {
        return updateBy;
    }

    public void setUpdateBy(String updateBy) {
        this.updateBy = updateBy;
    }
}