1. wsimport -keep -verbose -d . -p de.travelit.profileadmin.webservice.client http://localhost:8081/ProfileAdmin/webservice/Mixer?wsdl
2. copy all java files in package "de.travelit.profileadmin.webservice.client"
3. run WebserviceTest.java