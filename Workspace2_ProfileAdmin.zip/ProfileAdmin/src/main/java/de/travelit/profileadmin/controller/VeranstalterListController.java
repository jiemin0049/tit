package de.travelit.profileadmin.controller;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.google.common.base.Joiner;
import com.google.common.base.Strings;

import de.travelit.profileadmin.Constants;
import de.travelit.profileadmin.model.Authenticity;
import de.travelit.profileadmin.model.TourOperator;
import de.travelit.profileadmin.model.TourOperatorChange;
import de.travelit.profileadmin.model.TouropList;
import de.travelit.profileadmin.service.VeranstalterListService;

@Controller
public class VeranstalterListController {

    private static final Logger LOGGER = Logger.getLogger(VeranstalterListController.class);

    @Autowired
    private VeranstalterListService vaListService;

    @RequestMapping("begin_valist_anlegen")
    public String valistAnlegenFirstPage(HttpServletRequest request) {
        request.getSession().removeAttribute("valist_shortname");
        request.getSession().removeAttribute("valist_name");
        return "valist_anlegen1";
    }

    @RequestMapping(value = "valist_anlegen1_request", method = RequestMethod.POST)
    public String veranstatlerAnlegen(@RequestParam(value = "code") String pshortname, @RequestParam(value = "name") String pname, HttpServletRequest request, Model model) {
        String shortname = pshortname.trim();
        String name = pname.trim();

        request.getSession().setAttribute("valist_shortname", shortname);
        request.getSession().setAttribute("valist_name", name);

        if (Strings.isNullOrEmpty(shortname) || Strings.isNullOrEmpty(name)) {
            String errorMessage = "Kurz- und Bezeichnung dürfen nicht leer sein!";
            LOGGER.error(errorMessage);
            model.addAttribute("valist_error", errorMessage);
            return "valist_anlegen1";
        }

        if (vaListService.hasVeranstalterSetBy(shortname)) {
            String errorMessage = "Kurzbezeichnung ist vorhanden!";
            LOGGER.error(errorMessage);

            model.addAttribute("valist_error", errorMessage);
            return "valist_anlegen1";
        }

        pickList(vaListService.getActiveTourOperators(), model);
        return "valist_anlegen2";
    }

    @RequestMapping(value = "valist_anlegen2_back", method = RequestMethod.POST)
    public String veranstatlerAnlegenBack() {
        return "valist_anlegen1";
    }

    @RequestMapping(value = "valist_anlegen2_save", method = RequestMethod.POST)
    public String saveValist(HttpServletRequest request, Model model) {
        String[] checkedVa = request.getParameterValues("valist_checked");
        String shortname = (String) request.getSession().getAttribute("valist_shortname");
        String name = (String) request.getParameter("valist_change_name");
        vaListService.insertValist(shortname, name, checkedVa);

        request.getSession().removeAttribute("valist_shortname");
        request.getSession().removeAttribute("valist_name");

        model.addAttribute("setcode", shortname);
        model.addAttribute("setname", name);
        List<TourOperator> touropList = vaListService.getTourOperatorsBySetcode(shortname);
        pickList(touropList, model);
        return "valist_anlegen3";
    }

    private void pickList(List<TourOperator> touropList, Model model) {
    	List<TourOperator> vaList = new ArrayList<>();
        List<TourOperator> lfList = new ArrayList<>();
        for (TourOperator t : touropList) {
        	if (t.getServiceCharge() == 2) {
        		lfList.add(t);
        	} else {
        		vaList.add(t);
        	}
        }
        model.addAttribute("vaList", vaList);
        model.addAttribute("lfList", lfList);
    }

    @RequestMapping("valist_get_from_menu")
    public String valistGetFirstPage(HttpServletRequest request) {
        request.getSession().removeAttribute("valist_get_shortname");
        request.getSession().removeAttribute("valist_get_name");
        request.getSession().removeAttribute("setcode");
        request.getSession().removeAttribute("setname");
        request.getSession().removeAttribute("allOpSet");
        return "valist_get";
    }

    @RequestMapping(value = "valist_get", method = RequestMethod.POST)
    public String getValist(@RequestParam(value = "code") String pshortname, @RequestParam(value = "name") String pname, HttpServletRequest request, Model model) {
        String shortname = pshortname.trim();
        String name = pname.trim();

        request.getSession().setAttribute("valist_get_shortname", shortname);
        request.getSession().setAttribute("valist_get_name", name);

        List<TouropList> touropList = vaListService.getVeranstalterSetList(shortname, name);
        if (touropList.isEmpty()) {
            String errorMessage = "Veranstalter-Set nicht gefunden!";
            LOGGER.error(errorMessage);

            model.addAttribute("valist_get_error", errorMessage);
            return "valist_get";
        }

        request.getSession().setAttribute("allOpSet", touropList);

        if (touropList.size() == 1) {
            TouropList vaset = touropList.get(0);
            return toValistSeeResult(vaset.getCode(), vaset.getName(), model);
        }

        return "valist_show_list";
    }

    @RequestMapping(value = "valist_show_back", method = RequestMethod.POST)
    public String valistGetBack() {
        return "valist_get";
    }

    @RequestMapping(value = { "valist_see", "vaList_change_back" }, method = RequestMethod.POST)
    public String valistSee(@RequestParam(value = "vaset") String vaset, HttpServletRequest request, Model model) {
        String name = request.getParameter(vaset);
        return toValistSeeResult(vaset, name, model);
    }

    private String toValistSeeResult(String vaset, String name, Model model) {
        model.addAttribute("setcode", vaset);
        model.addAttribute("setname", name);
        List<TourOperator> touropList = vaListService.getTourOperatorsBySetcode(vaset);
        pickList(touropList, model);
        return "valist_see_result";
    }

    @RequestMapping(value = { "vaList_see_result_back" }, method = RequestMethod.POST)
    public String valistSeeResultBack(HttpServletRequest request) {
        List<TouropList> touropList = (List<TouropList>) request.getSession().getAttribute("allOpSet");
        if (touropList.size() == 1) {
            return "valist_get";
        }

        return "valist_show_list";
    }

    @RequestMapping(value = "valist_remove", method = RequestMethod.POST)
    public String valistRemove(HttpServletRequest request, Model model) {
        String code = request.getParameter("valist_see_code");

        List<String> cfgList = vaListService.isVasetUsedByCfg(code);
        if (!cfgList.isEmpty()) {
            String cfgs = Joiner.on(", ").join(cfgList);
            model.addAttribute("delete_error", "Delete failed. '" + code + "' is used by CFG [" + cfgs + "]");
            return "valist_remove_error";
        }

        vaListService.removeFromValist(code);

        // refresh session contents, because a va-set is removed.
        List<TouropList> touropList = (List<TouropList>) request.getSession().getAttribute("allOpSet");
        Iterator<TouropList> iter = touropList.iterator();
        while (iter.hasNext()) {
            TouropList op = iter.next();
            if (op.getCode().equals(code)) {
                iter.remove();
                break;
            }
        }
        request.getSession().setAttribute("allOpSet", touropList);

        model.addAttribute("dialog_title", "Remove Veranstalter-Set");
        model.addAttribute("dialog_message", "Veranstalter-Set [<b>" + code + "</b>] is removed!");

        return "valist_remove_success_dialog";
    }

    @RequestMapping(value = "valist_after_remove", method = RequestMethod.POST)
    public String afterValistRemove() {
        return "valist_show_list";
    }

    @RequestMapping(value = "valist_change", method = RequestMethod.POST)
    public String valistChange(HttpServletRequest request, Model model) {
        String code = request.getParameter("valist_see_code");
        String name = request.getParameter("valist_see_name");

        request.getSession().setAttribute("setcode", code);
        request.getSession().setAttribute("setname", name);

        List<TourOperatorChange> opChangeList = vaListService.getTourOperatorChangeList(code);

        List<TourOperatorChange> vaList = new ArrayList<>();
        List<TourOperatorChange> lfList = new ArrayList<>();
        for (TourOperatorChange t : opChangeList) {
        	if (t.getServiceCharge() == 2) {
        		lfList.add(t);
        	} else {
        		vaList.add(t);
        	}
        }
        model.addAttribute("vaList", vaList);
        model.addAttribute("lfList", lfList);
        return "valist_change";
    }

    @RequestMapping(value = "valist_change_ok", method = RequestMethod.POST)
    public String valistChangeCommit(HttpServletRequest request, Model model) {
        String newName = request.getParameter("valist_change_name").trim();
        String name = request.getParameter("valist_old_name").trim();
        String[] chechedVa = request.getParameterValues("valist_change_checked");
        String code = (String) request.getSession().getAttribute("setcode");

        Authenticity auth = (Authenticity) request.getSession().getAttribute(Constants.SESSION_KEY_AUTHENTICITY);
        String user = auth.getName();

        if (!name.equals(newName)) {
            name = newName;
            vaListService.changeName(user, code, newName);

            //refresh session contents, because is name changed.
            List<TouropList> touropList = (List<TouropList>) request.getSession().getAttribute("allOpSet");
            Iterator<TouropList> iter = touropList.iterator();
            while (iter.hasNext()) {
                TouropList op = iter.next();
                if (op.getCode().equals(code)) {
                    op.setName(newName);
                    break;
                }
            }
            request.getSession().setAttribute("allOpSet", touropList);
        }

        vaListService.updateValist(code, chechedVa);

        model.addAttribute("newName", name);
        model.addAttribute("dialog_title", "Create Veranstalter-Set");
        model.addAttribute("dialog_message", "Veranstalter-Set [<b>" + code + "</b>] is changed!");

        return "valist_change_success_dialog";
    }

}
