package de.travelit.profileadmin.jstl;

/**
 * Class is for custom Function for JSTL titCheckbox.tld
 * @author zhang
 *
 */
public class CustomJstl {

    public static String getCheckBoxStyle(String styleNr) {
        switch (styleNr) {
        case "0":
        default:
            return "style='display: none'";

        case "2":
            return "checked";

        case "1":
            return "";
        }
    }
}
