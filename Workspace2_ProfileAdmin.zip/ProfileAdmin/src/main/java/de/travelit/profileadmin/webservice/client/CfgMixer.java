
package de.travelit.profileadmin.webservice.client;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java-Klasse f�r cfgMixer complex type.
 * 
 * <p>Das folgende Schemafragment gibt den erwarteten Content an, der in dieser Klasse enthalten ist.
 * 
 * <pre>
 * &lt;complexType name="cfgMixer">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="kunde" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="status" type="{http://www.w3.org/2001/XMLSchema}boolean"/>
 *         &lt;element name="xpwp" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="xsl" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="xmlcfg" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="xmlxpwp" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="emailAdmin" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="facetcount" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="rating" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="ratingName" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="enablesource" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="mixer" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="vchub" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *       &lt;attribute name="id" use="required" type="{http://www.w3.org/2001/XMLSchema}int" />
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "cfgMixer", propOrder = {
    "kunde",
    "status",
    "xpwp",
    "xsl",
    "xmlcfg",
    "xmlxpwp",
    "emailAdmin",
    "facetcount",
    "rating",
    "ratingName",
    "enablesource",
    "mixer",
    "vchub"
})
public class CfgMixer {

    protected String kunde;
    protected boolean status;
    protected String xpwp;
    protected String xsl;
    protected Integer xmlcfg;
    protected String xmlxpwp;
    protected String emailAdmin;
    protected Integer facetcount;
    protected int rating;
    protected String ratingName;
    protected String enablesource;
    protected int mixer;
    protected String vchub;
    @XmlAttribute(name = "id", required = true)
    protected int id;

    /**
     * Ruft den Wert der kunde-Eigenschaft ab.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getKunde() {
        return kunde;
    }

    /**
     * Legt den Wert der kunde-Eigenschaft fest.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setKunde(String value) {
        this.kunde = value;
    }

    /**
     * Ruft den Wert der status-Eigenschaft ab.
     * 
     */
    public boolean isStatus() {
        return status;
    }

    /**
     * Legt den Wert der status-Eigenschaft fest.
     * 
     */
    public void setStatus(boolean value) {
        this.status = value;
    }

    /**
     * Ruft den Wert der xpwp-Eigenschaft ab.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getXpwp() {
        return xpwp;
    }

    /**
     * Legt den Wert der xpwp-Eigenschaft fest.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setXpwp(String value) {
        this.xpwp = value;
    }

    /**
     * Ruft den Wert der xsl-Eigenschaft ab.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getXsl() {
        return xsl;
    }

    /**
     * Legt den Wert der xsl-Eigenschaft fest.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setXsl(String value) {
        this.xsl = value;
    }

    /**
     * Ruft den Wert der xmlcfg-Eigenschaft ab.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getXmlcfg() {
        return xmlcfg;
    }

    /**
     * Legt den Wert der xmlcfg-Eigenschaft fest.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setXmlcfg(Integer value) {
        this.xmlcfg = value;
    }

    /**
     * Ruft den Wert der xmlxpwp-Eigenschaft ab.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getXmlxpwp() {
        return xmlxpwp;
    }

    /**
     * Legt den Wert der xmlxpwp-Eigenschaft fest.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setXmlxpwp(String value) {
        this.xmlxpwp = value;
    }

    /**
     * Ruft den Wert der emailAdmin-Eigenschaft ab.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEmailAdmin() {
        return emailAdmin;
    }

    /**
     * Legt den Wert der emailAdmin-Eigenschaft fest.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEmailAdmin(String value) {
        this.emailAdmin = value;
    }

    /**
     * Ruft den Wert der facetcount-Eigenschaft ab.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getFacetcount() {
        return facetcount;
    }

    /**
     * Legt den Wert der facetcount-Eigenschaft fest.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setFacetcount(Integer value) {
        this.facetcount = value;
    }

    /**
     * Ruft den Wert der rating-Eigenschaft ab.
     * 
     */
    public int getRating() {
        return rating;
    }

    /**
     * Legt den Wert der rating-Eigenschaft fest.
     * 
     */
    public void setRating(int value) {
        this.rating = value;
    }

    /**
     * Ruft den Wert der ratingName-Eigenschaft ab.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRatingName() {
        return ratingName;
    }

    /**
     * Legt den Wert der ratingName-Eigenschaft fest.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRatingName(String value) {
        this.ratingName = value;
    }

    /**
     * Ruft den Wert der enablesource-Eigenschaft ab.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEnablesource() {
        return enablesource;
    }

    /**
     * Legt den Wert der enablesource-Eigenschaft fest.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEnablesource(String value) {
        this.enablesource = value;
    }

    /**
     * Ruft den Wert der mixer-Eigenschaft ab.
     * 
     */
    public int getMixer() {
        return mixer;
    }

    /**
     * Legt den Wert der mixer-Eigenschaft fest.
     * 
     */
    public void setMixer(int value) {
        this.mixer = value;
    }

    /**
     * Ruft den Wert der vchub-Eigenschaft ab.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getVchub() {
        return vchub;
    }

    /**
     * Legt den Wert der vchub-Eigenschaft fest.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setVchub(String value) {
        this.vchub = value;
    }

    /**
     * Ruft den Wert der id-Eigenschaft ab.
     * 
     */
    public int getId() {
        return id;
    }

    /**
     * Legt den Wert der id-Eigenschaft fest.
     * 
     */
    public void setId(int value) {
        this.id = value;
    }

}
