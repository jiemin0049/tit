package de.travelit.profileadmin.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.support.rowset.SqlRowSet;
import org.springframework.stereotype.Repository;

import com.google.common.base.Strings;

import de.travelit.profileadmin.model.mixer.CfgMixer;

@Repository
public class MixerDao extends AbstractDao {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    public List<CfgMixer> getActiveCfgs() {
        String sqlStr = "SELECT cfg, name, status, xpwp, email_admin, vc_hub, rating, ratingname, facetcount, mixer, xsl, cache_source, hubpriority FROM cfglist WHERE status=true ORDER BY cfg";
        List<CfgMixer> cfgMixerList = new ArrayList<>();
        SqlRowSet rowSet = jdbcTemplate.queryForRowSet(sqlStr);
        while (rowSet.next()) {
            CfgMixer mixer = new CfgMixer();
            mixer.setCfgNumber(rowSet.getInt("cfg"));
            mixer.setCfgName(rowSet.getString("name"));
            mixer.setCfgStatus(rowSet.getBoolean("status"));
            mixer.setXpwp(rowSet.getString("xpwp"));
            mixer.setEmailAdmin(Strings.nullToEmpty(rowSet.getString("email_admin")));
            mixer.setVchub(Strings.nullToEmpty(rowSet.getString("vc_hub")));
            mixer.setRating(rowSet.getInt("rating"));
            mixer.setRatingName(Strings.nullToEmpty(rowSet.getString("ratingname")));
            mixer.setFacetcount(rowSet.getInt("facetcount"));
            mixer.setMixer(rowSet.getInt("mixer"));
            mixer.setXsl(Strings.nullToEmpty(rowSet.getString("xsl")));
            mixer.setCachesource(Strings.nullToEmpty(rowSet.getString("cache_source")));
            mixer.setHubPriority(rowSet.getBoolean("hubpriority"));
            cfgMixerList.add(mixer);
        }
        return cfgMixerList;
    }

    /**
     * Cfgs are active and mixer != 0
     * @return
     */
    public List<CfgMixer> getActiveCfgsWithMixerType() {
        String sqlStr = "SELECT cfg, name, status, xpwp, email_admin, vc_hub, rating, ratingname, facetcount, mixer, xsl, cache_source, hubpriority FROM cfglist WHERE status=true AND mixer!=0 ORDER BY cfg";
        List<CfgMixer> cfgMixerList = new ArrayList<>();
        SqlRowSet rowSet = jdbcTemplate.queryForRowSet(sqlStr);
        while (rowSet.next()) {
            CfgMixer mixer = new CfgMixer();
            mixer.setCfgNumber(rowSet.getInt("cfg"));
            mixer.setCfgName(rowSet.getString("name"));
            mixer.setCfgStatus(rowSet.getBoolean("status"));
            mixer.setXpwp(rowSet.getString("xpwp"));
            mixer.setEmailAdmin(Strings.nullToEmpty(rowSet.getString("email_admin")));
            mixer.setVchub(Strings.nullToEmpty(rowSet.getString("vc_hub")));
            mixer.setRating(rowSet.getInt("rating"));
            mixer.setRatingName(Strings.nullToEmpty(rowSet.getString("ratingname")));
            mixer.setFacetcount(rowSet.getInt("facetcount"));
            mixer.setMixer(rowSet.getInt("mixer"));
            mixer.setXsl(Strings.nullToEmpty(rowSet.getString("xsl")));
            mixer.setCachesource(Strings.nullToEmpty(rowSet.getString("cache_source")));
            mixer.setHubPriority(rowSet.getBoolean("hubpriority"));
            cfgMixerList.add(mixer);
        }
        return cfgMixerList;
    }
}
