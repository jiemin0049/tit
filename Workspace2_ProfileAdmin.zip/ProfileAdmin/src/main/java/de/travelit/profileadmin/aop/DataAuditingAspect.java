package de.travelit.profileadmin.aop;

import javax.servlet.http.HttpServletRequest;

import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;
import org.springframework.web.context.support.SpringBeanAutowiringSupport;

import de.travelit.profileadmin.Constants;
import de.travelit.profileadmin.model.Authenticity;

abstract public class DataAuditingAspect {

    public DataAuditingAspect() {
        SpringBeanAutowiringSupport.processInjectionBasedOnCurrentContext(this);
    }

    protected String getAuthName() {
        return getAuthenticity().getName();
    }

    protected Authenticity getAuthenticity() {
        ServletRequestAttributes requestAttr = (ServletRequestAttributes) RequestContextHolder.currentRequestAttributes();
        HttpServletRequest request = requestAttr.getRequest();
        return (Authenticity) request.getSession().getAttribute(Constants.SESSION_KEY_AUTHENTICITY);
    }
}
