package de.travelit.profileadmin.model.mixer;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

@XmlAccessorType(XmlAccessType.FIELD)
public class CfgMixer {

    @XmlAttribute(name = "id")
    private int cfgNumber;
    @XmlElement(name = "kunde")
    private String cfgName;
    @XmlElement(name = "status")
    private boolean cfgStatus;
    private String xpwp;
    @XmlElement(name = "hubpriority")
    @XmlJavaTypeAdapter(type = boolean.class, value = HubpriorityAdapter.class)
    private boolean hubPriority;

    private String xsl;
    private String xmlcfg;
    private String xmlxpwp;
    private String emailAdmin;
    private Integer facetcount;
    private int rating;
    private String ratingName;
    private String cachesource;
    private int mixer;

    private String vchub;

    public int getCfgNumber() {
        return cfgNumber;
    }

    public void setCfgNumber(int cfgNumber) {
        this.cfgNumber = cfgNumber;
    }

    public String getCfgName() {
        return cfgName;
    }

    public void setCfgName(String cfgName) {
        this.cfgName = cfgName;
    }

    public boolean isCfgStatus() {
        return cfgStatus;
    }

    public void setCfgStatus(boolean cfgStatus) {
        this.cfgStatus = cfgStatus;
    }

    public String getXpwp() {
        return xpwp;
    }

    public void setXpwp(String xpwp) {
        this.xpwp = xpwp;
    }

    public String getXsl() {
        return xsl;
    }

    public void setXsl(String xsl) {
        this.xsl = xsl;
    }

    public String getXmlcfg() {
        return xmlcfg;
    }

    public void setXmlcfg(String xmlcfg) {
        this.xmlcfg = xmlcfg;
    }

    public String getXmlxpwp() {
        return xmlxpwp;
    }

    public void setXmlxpwp(String xmlxpwp) {
        this.xmlxpwp = xmlxpwp;
    }

    public String getEmailAdmin() {
        return emailAdmin;
    }

    public void setEmailAdmin(String emailAdmin) {
        this.emailAdmin = emailAdmin;
    }

    public Integer getFacetcount() {
        return facetcount;
    }

    public void setFacetcount(Integer facetcount) {
        this.facetcount = facetcount;
    }

    public int getRating() {
        return rating;
    }

    public void setRating(int rating) {
        this.rating = rating;
    }

    public String getRatingName() {
        return ratingName;
    }

    public void setRatingName(String ratingName) {
        this.ratingName = ratingName;
    }

    public String getCachesource() {
        return cachesource;
    }

    public void setCachesource(String cachesource) {
        this.cachesource = cachesource;
    }

    public int getMixer() {
        return mixer;
    }

    public void setMixer(int mixer) {
        this.mixer = mixer;
    }

    public String getVchub() {
        return vchub;
    }

    public void setVchub(String vchub) {
        this.vchub = vchub;
    }

    public boolean isHubPriority() {
        return hubPriority;
    }

    public void setHubPriority(boolean hubPriority) {
        this.hubPriority = hubPriority;
    }

}
