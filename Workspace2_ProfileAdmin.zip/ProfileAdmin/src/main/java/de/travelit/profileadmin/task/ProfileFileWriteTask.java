package de.travelit.profileadmin.task;

import java.util.TimerTask;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.context.support.SpringBeanAutowiringSupport;

import com.google.common.base.Strings;

import de.travelit.profileadmin.Constants;
import de.travelit.profileadmin.service.ProfileIniService;

public class ProfileFileWriteTask extends TimerTask {

    private static final Logger LOGGER = Logger.getLogger(ProfileFileWriteTask.class);
    private static ProfileFileWriteTask instance = new ProfileFileWriteTask();

    @Autowired
    private ProfileIniService profileService;

    private ProfileFileWriteTask() {
        // This can also generate profileService
        //vaListService = WebApplicationContextUtils.getRequiredWebApplicationContext(sce.getServletContext()).getBean(VeranstalterListService.class);
        SpringBeanAutowiringSupport.processInjectionBasedOnCurrentContext(this);
    }

    public static ProfileFileWriteTask getInstance() {
        return instance;
    }

    @Override
    public void run() {
        String profile = System.getProperty(Constants.PROFILE_INI);
        if (Strings.isNullOrEmpty(profile)) {
            LOGGER.fatal("Can not write Profile.ini, file not found in " + profile);
            return;
        }
        profileService.writeProfile(profile);
    }

}