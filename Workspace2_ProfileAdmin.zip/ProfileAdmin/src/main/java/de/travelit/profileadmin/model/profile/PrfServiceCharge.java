package de.travelit.profileadmin.model.profile;

public class PrfServiceCharge {
    private int cfg;
    private String tourop;
    private int scshort;
    private int scmiddle;
    private int sclong;

    public int getCfg() {
        return cfg;
    }

    public void setCfg(int cfg) {
        this.cfg = cfg;
    }

    public String getTourop() {
        return tourop;
    }

    public void setTourop(String tourop) {
        this.tourop = tourop;
    }

    public int getScshort() {
        return scshort;
    }

    public void setScshort(int scshort) {
        this.scshort = scshort;
    }

    public int getScmiddle() {
        return scmiddle;
    }

    public void setScmiddle(int scmiddle) {
        this.scmiddle = scmiddle;
    }

    public int getSclong() {
        return sclong;
    }

    public void setSclong(int sclong) {
        this.sclong = sclong;
    }

}
