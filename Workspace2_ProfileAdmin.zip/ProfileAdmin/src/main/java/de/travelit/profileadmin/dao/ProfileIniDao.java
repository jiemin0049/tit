package de.travelit.profileadmin.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.support.rowset.SqlRowSet;
import org.springframework.stereotype.Repository;

import com.google.common.collect.ArrayListMultimap;
import com.google.common.collect.ListMultimap;

import de.travelit.profileadmin.model.profile.PrfCfg;
import de.travelit.profileadmin.model.profile.PrfHoteloDest;
import de.travelit.profileadmin.model.profile.PrfLineFlight;
import de.travelit.profileadmin.model.profile.PrfServiceCharge;
import de.travelit.profileadmin.model.profile.PrfVaaktiv;

@Repository
public class ProfileIniDao {

    private static final Logger LOGGER = Logger.getLogger(ProfileIniDao.class);

    @Autowired
    private JdbcTemplate jdbcTemplate;

    public void setStatus(boolean status) {
        String sqlStr = "UPDATE profile_update SET lastupdate=" + status + " WHERE id='profile'";
        jdbcTemplate.update(sqlStr);
    }

    public boolean getStatus() {
        String sqlStr = "SELECT lastupdate FROM profile_update WHERE id='profile'";
        return jdbcTemplate.queryForObject(sqlStr, Boolean.class);
    }

    public Map<String, Object> getAllActiveProfile() {
        List<PrfCfg> cfgList = getActivePrfCfgList();
        ListMultimap<Integer, PrfHoteloDest> prfHoteloDestMap = getPrfHoteloDestMap();
        ListMultimap<Integer, PrfServiceCharge> prfServiceChargeMap = getPrfServiceChargeMap();
        ListMultimap<Integer, PrfLineFlight> prfLineFlightMap = getPrfLineFlightMap();
        ListMultimap<Integer, PrfVaaktiv> prfVaaktivMap = getPrfVaaktivMap();

        Map<String, Object> all = new HashMap<>();
        all.put("cfg", cfgList);
        all.put("hoteloDest", prfHoteloDestMap);
        all.put("serviceCharge", prfServiceChargeMap);
        all.put("lineFlight", prfLineFlightMap);
        all.put("vaaktiv", prfVaaktivMap);

        return all;
    }

    private List<PrfCfg> getActivePrfCfgList() {
        String cfgSql = "SELECT c.*, h.mainpercentage, h.main_fix FROM (select * from cfglist where status=true) as c LEFT JOIN hotelocalc h ON c.cfg=h.cfg ORDER BY c.cfg";
        List<PrfCfg> cfgList = new ArrayList<>();

        SqlRowSet rowSet = jdbcTemplate.queryForRowSet(cfgSql);
        while (rowSet.next()) {
            PrfCfg prfCfg = new PrfCfg();
            int cfg = rowSet.getInt("CFG");
            prfCfg.setCfg(cfg);
            prfCfg.setStatus(rowSet.getBoolean("status"));
            prfCfg.setPrimaryCfg((Integer) rowSet.getObject("primary_cfg"));
            prfCfg.setLicenceValidto(rowSet.getDate("licence_validto"));
            prfCfg.setName(rowSet.getString("name"));
            prfCfg.setAffiliates(rowSet.getBoolean("affiliates"));
            prfCfg.setMaxdays(rowSet.getInt("maxdays"));
            prfCfg.setXpwp(rowSet.getString("xpwp"));
            prfCfg.setDebitoreNumber(rowSet.getString("debitorennummer"));
            prfCfg.setBumaAgency(rowSet.getString("bumaagency"));
            prfCfg.setTerminal(rowSet.getString("terminal"));
            prfCfg.setPassword(rowSet.getString("password"));
            prfCfg.setTerminalweb(rowSet.getString("terminalweb"));
            prfCfg.setPasswordweb(rowSet.getString("passwortweb"));
            prfCfg.setEmail(rowSet.getString("email"));
            prfCfg.setOnrequest(false);
            prfCfg.setErv(rowSet.getInt("insurance"));
            prfCfg.setTuiAgencyNumber(rowSet.getString("tui_agencynumber"));
            prfCfg.setOnlineTill(rowSet.getString("online_till"));
            prfCfg.setOnline(rowSet.getInt("online"));
            prfCfg.setAgencyNumber("");
            prfCfg.setInkasso(rowSet.getString("inkasso"));
            prfCfg.setFromMin(rowSet.getInt("from_min"));
            prfCfg.setFromMin1(rowSet.getString("from_min1"));
            prfCfg.setBookto(rowSet.getInt("book_to"));
            prfCfg.setOtagtc(rowSet.getString("ota_gtc"));
            prfCfg.setMaxPricediff(rowSet.getInt("max_pricediff"));
            prfCfg.setHotelInfoCenter(rowSet.getBoolean("hotelinfocenter"));
            prfCfg.setOpControl(rowSet.getBoolean("opcontrol"));
            prfCfg.setGiataIhgUid(rowSet.getString("giata_ihg_uid"));
            prfCfg.setGiataXmluser(rowSet.getString("giata_xmluser"));
            prfCfg.setGiataXmlpwd(rowSet.getString("giata_xmlpwd"));
            prfCfg.setLayoutId(rowSet.getInt("layoutid"));
            prfCfg.setComment(rowSet.getString("comment"));
            prfCfg.setConfigmode(3);
            prfCfg.setMainPercentage(rowSet.getInt("mainpercentage"));
            prfCfg.setMainFix(rowSet.getInt("main_fix"));

            cfgList.add(prfCfg);

        }
        return cfgList;
    }

    private ListMultimap<Integer, PrfHoteloDest> getPrfHoteloDestMap() {
        String hotelodestSql = "SELECT c.cfg, t.dest3lc, t.percentagelow, t.percentagemiddle, t.percentagehigh FROM cfglist c LEFT JOIN hotelodest t ON c.cfg=t.cfg ORDER BY c.cfg";
        ListMultimap<Integer, PrfHoteloDest> prfHoteloDestMap = ArrayListMultimap.create();

        SqlRowSet rowSet = jdbcTemplate.queryForRowSet(hotelodestSql);
        while (rowSet.next()) {
            PrfHoteloDest hoteloDest = new PrfHoteloDest();
            int cfg = rowSet.getInt("cfg");
            hoteloDest.setCfg(cfg);
            hoteloDest.setDest3lc(rowSet.getString("dest3lc"));
            hoteloDest.setPercentageLow(rowSet.getInt("percentagelow"));
            hoteloDest.setPercentageMiddle(rowSet.getInt("percentagemiddle"));
            hoteloDest.setPercentageHigh(rowSet.getInt("percentagehigh"));

            prfHoteloDestMap.put(cfg, hoteloDest);
        }
        return prfHoteloDestMap;
    }

    private ListMultimap<Integer, PrfServiceCharge> getPrfServiceChargeMap() {
      //Get all service charges of CFGs, but CFGs which have primary CFG are exclude.
        String servicechargesSql = "SELECT c.cfg, s.tourop, s.sc_short, s.sc_middle, s.sc_long FROM cfglist c JOIN servicecharges_cfg s ON c.cfg=s.cfg AND c.primary_cfg IS NULL ORDER BY s.cfg, s.tourop";
        ListMultimap<Integer, PrfServiceCharge> prfServiceChargeMap = ArrayListMultimap.create();

        SqlRowSet rowSet = jdbcTemplate.queryForRowSet(servicechargesSql);
        while (rowSet.next()) {
            PrfServiceCharge serv = new PrfServiceCharge();
            int cfg = rowSet.getInt("cfg");
            serv.setCfg(cfg);
            serv.setTourop(rowSet.getString("tourop"));
            serv.setScshort(rowSet.getInt("sc_short"));
            serv.setScmiddle(rowSet.getInt("sc_middle"));
            serv.setSclong(rowSet.getInt("sc_long"));

            prfServiceChargeMap.put(cfg, serv);
        }
        return prfServiceChargeMap;
    }

    private ListMultimap<Integer, PrfLineFlight> getPrfLineFlightMap() {
        //Get all line fight of CFGs, but CFGs which have primary CFG are exclude.
          String lineflightSql = "SELECT c.cfg, s.tourop, s.lf_short, s.lf_middle, s.lf_long FROM cfglist c JOIN lineflight_cfg s ON c.cfg=s.cfg AND c.primary_cfg IS NULL ORDER BY s.cfg, s.tourop";
          ListMultimap<Integer, PrfLineFlight> prfLineFlightMap = ArrayListMultimap.create();

          SqlRowSet rowSet = jdbcTemplate.queryForRowSet(lineflightSql);
          while (rowSet.next()) {
              PrfLineFlight serv = new PrfLineFlight();
              int cfg = rowSet.getInt("cfg");
              serv.setCfg(cfg);
              serv.setTourop(rowSet.getString("tourop"));
              serv.setLfshort(rowSet.getInt("lf_short"));
              serv.setLfmiddle(rowSet.getInt("lf_middle"));
              serv.setLflong(rowSet.getInt("lf_long"));

              prfLineFlightMap.put(cfg, serv);
          }
          return prfLineFlightMap;
    }

    private ListMultimap<Integer, PrfVaaktiv> getPrfVaaktivMap() {
        String vaaktivSql = "SELECT c.cfg, va.tourop, va.active, op.source_cache, op.source_hub, va.bookonline FROM cfglist c LEFT JOIN va_aktiv_cfgs va ON c.cfg=va.cfg "
                             + " JOIN touroperator op ON op.tourop=va.tourop ORDER BY c.cfg, va.tourop";
        ListMultimap<Integer, PrfVaaktiv> prfVaaktivMap = ArrayListMultimap.create();

        SqlRowSet rowSet = jdbcTemplate.queryForRowSet(vaaktivSql);
        while (rowSet.next()) {
            PrfVaaktiv va = new PrfVaaktiv();
            int cfg = rowSet.getInt("cfg");
            va.setCfg(cfg);
            va.setTourop(rowSet.getString("tourop"));
            va.setActive(rowSet.getBoolean("active"));
            va.setHub(rowSet.getBoolean("source_hub"));
            va.setCache(rowSet.getBoolean("source_cache"));
            va.setBookOnline(rowSet.getBoolean("bookonline"));

            prfVaaktivMap.put(cfg, va);
        }

        return prfVaaktivMap;
    }


   public List<String> getAllActiveVeranstalterCode() {
       return getAllVeranstalterCode(true);
   }

   public List<String> getAllInactiveVeranstalterCode() {
       return getAllVeranstalterCode(false);
   }

   /**
    *
    * @param active All active veranstalters or all inactive veranstalters
    * @return
    */
   private List<String> getAllVeranstalterCode(boolean active) {
       return jdbcTemplate.queryForList("SELECT tourop FROM touroperator WHERE active=" + active + " ORDER BY tourop", String.class);
   }

   public List<String> getAllactiveCacheVeranstalterCode() {
       return jdbcTemplate.queryForList("SELECT tourop FROM touroperator WHERE active=true AND source_cache=true ORDER BY tourop", String.class);
   }
}
