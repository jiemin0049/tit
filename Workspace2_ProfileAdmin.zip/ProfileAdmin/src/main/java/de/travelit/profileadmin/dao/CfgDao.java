package de.travelit.profileadmin.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.lang3.math.NumberUtils;
import org.apache.log4j.Logger;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCreator;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.jdbc.support.rowset.SqlRowSet;
import org.springframework.stereotype.Repository;

import com.google.common.base.Joiner;
import com.google.common.collect.ArrayListMultimap;
import com.google.common.collect.ListMultimap;

import de.travelit.profileadmin.Constants;
import de.travelit.profileadmin.model.CfgAdminKunde;
import de.travelit.profileadmin.model.CfgBuchungsModus;
import de.travelit.profileadmin.model.CfgHic;
import de.travelit.profileadmin.model.CfgMain;
import de.travelit.profileadmin.model.HoteloAufschlag;
import de.travelit.profileadmin.model.HoteloDest;
import de.travelit.profileadmin.model.Range;
import de.travelit.profileadmin.model.TourOperator;
import de.travelit.profileadmin.model.ValistCfg;
import de.travelit.profileadmin.model.ValistCfg.ValistCfgPK;
import de.travelit.profileadmin.model.mixer.CfgMixer;

@Repository
public class CfgDao extends AbstractDao {

    private static final Logger LOGGER = Logger.getLogger(CfgDao.class);

    @Autowired
    private JdbcTemplate jdbcTemplate;

    public Map<String, Object> getCfgMain(String cfgId) {
        String sqlStr = "SELECT * FROM cfglist WHERE cfg=" + cfgId;

        @SuppressWarnings("unchecked")
        Map<String, Object> cfgMainMap = (Map<String, Object>) jdbcTemplate.query(sqlStr, new ResultSetExtractor<Object>() {
            @Override
            public Map<String, Object> extractData(ResultSet rs) throws SQLException, DataAccessException {
                Map<String, Object> m = new HashMap<>();
                if (rs.next()) {
                    CfgMain cm = new CfgMain();
                    cm.setCfgNumber(rs.getInt("CFG"));
                    cm.setCfgName(rs.getString("NAME"));
                    cm.setConfigMode(3);
                    cm.setCfgStatus(rs.getBoolean("status"));
                    cm.setLicenceValidDate(rs.getDate("licence_validto"));
                    cm.setDebitorenNr(rs.getString("debitorennummer"));
                    cm.setCfgComment(rs.getString("comment"));
                    cm.setLayoutId(rs.getInt("layoutid"));
                    cm.setInkasso(rs.getString("inkasso"));
                    cm.setAffiliates(rs.getBoolean("affiliates"));
                    cm.setMaxdays(rs.getInt("maxdays"));
                    cm.setXpwp(rs.getString("xpwp"));
                    cm.setTerminalweb(rs.getString("terminalweb"));
                    cm.setPasswordweb(rs.getString("passwortweb"));
                    cm.setBumaAgency(rs.getString("bumaagency"));
                    cm.setTerminal(rs.getString("terminal"));
                    cm.setBumaPassword(rs.getString("password"));
                    cm.setGiataXmlUser(rs.getString("giata_xmluser"));
                    cm.setGiataXmlpwd(rs.getString("giata_xmlpwd"));
                    cm.setHotelInfoCenter(rs.getBoolean("hotelinfocenter"));
                    cm.setOpControl(rs.getBoolean("opcontrol"));
                    cm.setReviews(rs.getBoolean("reviews"));
                    cm.setReviewProvider(rs.getInt("reviewProvider"));
                    cm.setLastUpdate(rs.getDate("lastupdate"));
                    cm.setCfgMainVasetOrHaupt(rs.getObject("primary_cfg") == null? 0:1);
                    cm.setCfgMainVaset(rs.getObject("primary_cfg") == null? null : rs.getInt("primary_cfg") + "");
                    m.put("cfgmain", cm);

                    CfgAdminKunde adminKunde = new CfgAdminKunde();
                    adminKunde.setRbagb(rs.getString("ota_gtc"));
                    adminKunde.setOnrequest(false);
                    adminKunde.setAgencyNumber("");
                    adminKunde.setTuiAgencyNummer(rs.getString("tui_agencynumber"));
                    adminKunde.setEmail(rs.getString("email"));
                    adminKunde.setGiataIhgUid(rs.getString("giata_ihg_uid"));
                    adminKunde.setMaxPriceDiff(rs.getInt("max_pricediff"));
                    adminKunde.setVersicherung(rs.getInt("insurance"));
                    m.put("adminkunde", adminKunde);

                    CfgBuchungsModus buchungsModus = new CfgBuchungsModus();
                    buchungsModus.setFromMin(rs.getInt("from_min"));
                    buchungsModus.setFromMin1(rs.getString("from_min1"));
                    buchungsModus.setOnline(rs.getInt("online"));
                    buchungsModus.setOnlineTill(rs.getString("online_till"));
                    buchungsModus.setBookto(rs.getInt("book_to"));
                    m.put("buchungsmodus", buchungsModus);

                    CfgMixer mixer = new CfgMixer();
                    mixer.setXsl(rs.getString("xsl"));
                    mixer.setEmailAdmin(rs.getString("email_admin"));
                    mixer.setCachesource(rs.getString("cache_source"));
                    mixer.setRating(rs.getInt("rating"));
                    mixer.setRatingName(rs.getString("ratingname"));
                    mixer.setFacetcount(rs.getInt("facetcount"));
                    mixer.setMixer(rs.getInt("mixer"));
                    mixer.setHubPriority(rs.getBoolean("hubpriority"));
                    m.put("mixer", mixer);
                }
                return m;
            }
        });
        return cfgMainMap;
    }

    public Map<String, Object> getCfgbyId(String cfgId) {
        final Map<String, Object> cfgDataMap = new HashMap<>();

        //main, admin kunde, buchungsmodus and mixer
        Map<String, Object> tempMap = getCfgMain(cfgId);
        if (tempMap.isEmpty()) {
            return tempMap;
        }
        cfgDataMap.putAll(tempMap);

        // va-set
        int vasetOrPrimaryCfg = ((CfgMain) tempMap.get("cfgmain")).getCfgMainVasetOrHaupt();
        List<Range> rangeList = new ArrayList<>();
        if (vasetOrPrimaryCfg == 0) {
            String valistCfgSql = "SELECT vc.code, op.tourop, op.touropname, op.servicecharge, vaac.active, vaac.bookonline "
                                + " FROM valist_cfg vc, valist va, touroperator op, va_aktiv_cfgs vaac "
                                + " WHERE vc.code=va.code AND va.vacode = op.tourop AND vc.cfg = vaac.cfg AND op.tourop=vaac.tourop AND vc.cfg=" + cfgId
                                + " ORDER BY op.tourop";
            SqlRowSet rowSet = jdbcTemplate.queryForRowSet(valistCfgSql);
            Set<String> valistCodes = new HashSet<>();
            while (rowSet.next()) {
                valistCodes.add(rowSet.getString("code"));
                Range range = new Range();
                range.setCode(rowSet.getString("tourop"));
                range.setName(rowSet.getString("touropname"));
                range.setActive(rowSet.getBoolean("active"));
                range.setOnline(rowSet.getBoolean("bookonline"));
                range.setServiceCharge(rowSet.getInt("servicecharge"));
                rangeList.add(range);
            }
            cfgDataMap.put("cfgmain_vaset", Joiner.on(",").join(valistCodes));


            // remove duplicate VAs,
            // if va-sets have same VA, only keep one VA, others must be removed.
            Set<Range> rangeSet = new LinkedHashSet<Range>(rangeList);
            rangeList.clear();
            rangeList.addAll(rangeSet);
        } else {
            //Has Primary CFG
            String primaryCfg = ((CfgMain) tempMap.get("cfgmain")).getCfgMainVaset();
            // vaset
            rangeList = getVaaktivCfgsBycfgid(Integer.parseInt(primaryCfg));
            cfgDataMap.put("cfgmain_vaset", primaryCfg);
        }
        cfgDataMap.put("rangeList", rangeList);

        //Charterflug-Provisionen
        cfgDataMap.put("chart_Prov", getCharterflugProvisionen(cfgId).asMap());

        //hotelo
        Session session = getSession();
        HoteloAufschlag aufschlag = (HoteloAufschlag) session.get(HoteloAufschlag.class, Integer.parseInt(cfgId));
        cfgDataMap.put("aufschlag", aufschlag);

        List<HoteloDest> hoteloDestList = session.createCriteria(HoteloDest.class).add(Restrictions.eq("hoteloDestPK.cfg", Integer.parseInt(cfgId))).list();
        Map<String, HoteloDest> hoteloDestMap = new HashMap<>();
        for (HoteloDest hd : hoteloDestList) {
            hoteloDestMap.put(hd.getHoteloDestPK().getDest3lc(), hd);
        }
        cfgDataMap.put("hotelodest", hoteloDestMap);
        return cfgDataMap;
    }

    public ListMultimap<String, Integer> getCharterflugProvisionen(String cfgId) {
        ListMultimap<String, Integer> charterflugProvisionenMap = ArrayListMultimap.create();

        String charterProvSql = "SELECT tourop, sc_short, sc_middle, sc_long FROM servicecharges_cfg WHERE cfg=" + cfgId + "ORDER BY tourop";
        SqlRowSet charterprovRowSet = jdbcTemplate.queryForRowSet(charterProvSql);
        while (charterprovRowSet.next()) {
            String op = charterprovRowSet.getString("tourop");
            charterflugProvisionenMap.put(op, charterprovRowSet.getInt("sc_short"));
            charterflugProvisionenMap.put(op, charterprovRowSet.getInt("sc_middle"));
            charterflugProvisionenMap.put(op, charterprovRowSet.getInt("sc_long"));

        }
        return charterflugProvisionenMap;
    }

    public CfgBuchungsModus getBuchungsModus(String cfgId) {
        String sql = "SELECT from_min, from_min1, online, online_till, book_to FROM cfglist WHERE cfg=" + cfgId;
        CfgBuchungsModus buchungsmodus = (CfgBuchungsModus) jdbcTemplate.query(sql,new ResultSetExtractor<Object>() {
            @Override
            public CfgBuchungsModus extractData(ResultSet rs) throws SQLException, DataAccessException {
                CfgBuchungsModus bm = new CfgBuchungsModus();
                if (rs.next()) {
                    bm.setFromMin(rs.getInt("from_min"));
                    bm.setFromMin1(rs.getString("from_min1"));
                    bm.setOnline(rs.getInt("online"));
                    bm.setOnlineTill(rs.getString("online_till"));
                    bm.setBookto(rs.getInt("book_to"));
                    return bm;
                } else {
                    return null;
                }
            }
        });
        return buchungsmodus;
    }

    public CfgHic getHicByCfgId(int cfgNr) {
        String sqlStr = "SELECT cfg, name, primary_cfg, status, reviewprovider, reviews, hotelinfocenter, giata_ihg_uid, giata_xmluser, giata_xmlpwd FROM cfglist WHERE cfg=" + cfgNr;
        CfgHic cfgHic = (CfgHic) jdbcTemplate.query(sqlStr, new ResultSetExtractor<Object>() {
            @Override
            public CfgHic extractData(ResultSet rs) throws SQLException, DataAccessException {
                CfgHic hic = new CfgHic();
                if (rs.next()) {
                    hic.setId(rs.getInt("CFG"));
                    hic.setKunde(rs.getString("name"));
                    hic.setPrimaryCfg((Integer)rs.getObject("primary_cfg"));
                    hic.setStatus(rs.getBoolean("status"));
                    hic.setHotelInfoCenter(rs.getBoolean("hotelinfocenter"));
                    hic.setGiataIhgUid(rs.getString("giata_ihg_uid"));
                    hic.setGiataIhgXmlUser(rs.getString("giata_xmluser"));
                    hic.setGiataIhgXmlPassword(rs.getString("giata_xmlpwd"));
                    hic.setReviews(rs.getBoolean("reviews"));
                    hic.setProvider(rs.getInt("reviewProvider"));
                    return hic;
                } else {
                    return null;
                }
            }
        });
        return cfgHic;
    }

    public boolean isCfgActive(String cfg) {
        if (!NumberUtils.isNumber(cfg)) {
            return false;
        }
        String sqlStr = "SELECT count(*) FROM cfglist WHERE status=true AND cfg=?";
        return jdbcTemplate.queryForObject(sqlStr, new Object[] { new Integer(cfg) }, Integer.class) > 0;
    }

    /**
     * Get cfg main info list by given cfg number and name.
     * @param cfgNumber cfg number.
     * @param kunde cfg name.
     *
     * @return
     */
    public List<CfgMain> getCfgList(String cfgNumber, String kunde) {
        List<CfgMain> cfgList = new ArrayList<>();
        String cfgStr = "";
        if (!cfgNumber.isEmpty()) {
            cfgStr = " AND cfg=" + cfgNumber;
        }
        String sqlStr = "SELECT cfg, name, status FROM cfglist WHERE name ~*'" + kunde + "'" + cfgStr + " ORDER BY cfg";
        SqlRowSet rowSet = jdbcTemplate.queryForRowSet(sqlStr);
        while (rowSet.next()) {
            CfgMain cfg = new CfgMain();
            cfg.setCfgNumber(rowSet.getInt("cfg"));
            cfg.setCfgName(rowSet.getString("name"));
            cfg.setCfgStatus(rowSet.getBoolean("status"));
            cfgList.add(cfg);
        }
        return cfgList;
    }

    public ListMultimap<Integer, String> getActiveHubvaList() {
        StringBuilder sql = new StringBuilder("SELECT c.cfg, c.primary_cfg, v.tourop, v.active, op.source_hub FROM (select * from cfglist where status=true) as c ");
        sql.append("LEFT JOIN va_aktiv_cfgs v ON v.active=true AND c.cfg=v.cfg ");
        sql.append("LEFT JOIN touroperator op ON op.source_hub=true and op.tourop=v.tourop ");
        sql.append("ORDER BY c.cfg, v.tourop ");
        return getHubvaList(sql.toString());
    }

    private ListMultimap<Integer, String> getHubvaList(String sql) {
        ListMultimap<Integer, String> hubvaMap = ArrayListMultimap.create();
        SqlRowSet rowSet = jdbcTemplate.queryForRowSet(sql);
        while (rowSet.next()) {
            if (rowSet.getBoolean("active")) {
                if (rowSet.getBoolean("source_hub")) {
                    hubvaMap.put(rowSet.getInt("cfg"), rowSet.getString("tourop"));
                }
            } else {
                Object primaryCfg = rowSet.getObject("primary_cfg");
                String op = primaryCfg == null ? "NONE" : "";
                hubvaMap.put(rowSet.getInt("cfg"), op);
            }
        }
        return hubvaMap;
    }


    public ListMultimap<Integer, TourOperator> getCfgTouroperator() {
        StringBuilder sql = new StringBuilder("SELECT c.cfg, c.primary_cfg, v.tourop, op.tourop, op.touropname, op.source_hub, op.source_cache FROM (select * from cfglist where status=true) as c ");
        sql.append("LEFT JOIN va_aktiv_cfgs v ON v.active=true AND c.cfg=v.cfg ");
        sql.append("LEFT JOIN touroperator op ON op.tourop=v.tourop ");
        sql.append("ORDER BY c.cfg, v.tourop ");
        SqlRowSet rowSet = jdbcTemplate.queryForRowSet(sql.toString());

        ListMultimap<Integer, TourOperator> cfgOpMap = ArrayListMultimap.create();
        Map<Integer, Integer> primaryCfgMap = new HashMap<>();

        while (rowSet.next()) {
            int cfg = rowSet.getInt("cfg");
            Object primaryCfg = rowSet.getObject("primary_cfg");
            if (primaryCfg != null) {
                primaryCfgMap.put(cfg, (int) primaryCfg);
            } else {
                TourOperator op = new TourOperator();
                op.setTourop(rowSet.getString("tourop"));
                op.setTouropName(rowSet.getString("touropname"));
                op.setHub(rowSet.getBoolean("source_hub"));
                op.setCache(rowSet.getBoolean("source_cache"));
                cfgOpMap.put(cfg, op);
            }
        }

        // Using tour operators of primary cfg to put in cfg
        for (Map.Entry<Integer, Integer> entry : primaryCfgMap.entrySet()) {
            int cfg = entry.getKey();
            int primaryCfg = entry.getValue();
            List<TourOperator> l = cfgOpMap.get(primaryCfg);
            cfgOpMap.putAll(cfg, l);
        }

        return cfgOpMap;

    }

    public Set<TourOperator> getCfgTouroperator(int cfgNr) {
        Set<TourOperator> operatorSet = new LinkedHashSet<>();
        StringBuilder sql = new StringBuilder("SELECT op.tourop, op.touropname, op.source_hub, op.source_cache FROM cfglist c JOIN va_aktiv_cfgs v ON v.active=true AND c.cfg=v.cfg AND c.cfg=");
        sql.append(cfgNr).append(" JOIN touroperator op ON op.tourop = v.tourop ORDER BY op.tourop");

        SqlRowSet rowSet = jdbcTemplate.queryForRowSet(sql.toString());
        while (rowSet.next()) {
            TourOperator op = new TourOperator();
            op.setTourop(rowSet.getString("tourop"));
            op.setTouropName(rowSet.getString("touropname"));
            op.setHub(rowSet.getBoolean("source_hub"));
            op.setCache(rowSet.getBoolean("source_cache"));
            operatorSet.add(op);
        }
        return operatorSet;
    }


    public Map<Integer, Integer> getCfgPrimaryCfgMap() {
        String sql = "SELECT cfg, primary_cfg from cfglist WHERE primary_cfg IS NOT NULL ORDER BY cfg";
        Map<Integer, Integer> map = new HashMap<>();
        SqlRowSet rowSet = jdbcTemplate.queryForRowSet(sql);
        while (rowSet.next()) {
            map.put(rowSet.getInt("cfg"), rowSet.getInt("primary_cfg"));
        }
        return map;
    }

    /**
     * Get cfg main info list by given cfg number list.
     *
     * @param cfgList cfg number list.
     * @return
     */
    public List<CfgMain> getCfgList(List<String> cfgList) {
        List<CfgMain> cfgMainList = new ArrayList<>();
        StringBuffer stringBuilderSql = new StringBuffer("SELECT cfg, name, status FROM cfglist WHERE ");
        String delimiter = " ";
        delimiter = " ";
        for (String cfg : cfgList) {
            stringBuilderSql.append(delimiter).append("cfg=").append(cfg);
            delimiter = " OR ";
        }
        stringBuilderSql.append(" ORDER BY cfg");
        SqlRowSet rowSet = jdbcTemplate.queryForRowSet(stringBuilderSql.toString());
        while (rowSet.next()) {
            CfgMain cfg = new CfgMain();
            cfg.setCfgNumber(rowSet.getInt("cfg"));
            cfg.setCfgName(rowSet.getString("name"));
            cfg.setCfgStatus(rowSet.getBoolean("status"));
            cfgMainList.add(cfg);
        }
        return cfgMainList;
    }

    public List<Integer> getCfgsWithPrimaryCfg(int cfg) {
        return jdbcTemplate.queryForList("SELECT cfg FROM cfglist WHERE primary_cfg=" + cfg, Integer.class);
    }

    public void insertCfgList(final String user, final CfgMain cfgmain, final CfgAdminKunde adminKunde, final CfgBuchungsModus buchungsModus, final CfgMixer mixer) {
        final int vasetOrPrimaryCfg = cfgmain.getCfgMainVasetOrHaupt();
        final String cfgSqlStr = "INSERT INTO cfglist (cfg, name,status,licence_validto,debitorennummer,configmode,comment,layoutid,inkasso,affiliates,maxdays,xpwp,"
                + "terminalweb,passwortweb,bumaagency,terminal,password,giata_xmluser,giata_xmlpwd,hotelinfocenter,reviews,reviewprovider,primary_cfg,opcontrol,"
                + "ota_gtc,onrequest,agencynumber,tui_agencynumber,email,giata_ihg_uid,max_pricediff,insurance,"
                + "from_min,from_min1,online,online_till,book_to,"
                + "xsl,email_admin,cache_source,rating,ratingname,facetcount,mixer,hubpriority,update_by) "
                + "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
        KeyHolder keyHolder = new GeneratedKeyHolder();
        jdbcTemplate.update(new PreparedStatementCreator() {

            @Override
            public PreparedStatement createPreparedStatement(final Connection conn) throws SQLException {
                final PreparedStatement ps = conn.prepareStatement(cfgSqlStr, Statement.RETURN_GENERATED_KEYS);
                ps.setInt(1, cfgmain.getCfgNumber());
                ps.setString(2, cfgmain.getCfgName());
                ps.setBoolean(3, cfgmain.isCfgStatus());
                ps.setDate(4, cfgmain.getLicenceValidDate());
                ps.setString(5, cfgmain.getDebitorenNr());
                ps.setInt(6, 3);
                ps.setString(7, cfgmain.getCfgComment());
                ps.setInt(8, cfgmain.getLayoutId());
                ps.setString(9, cfgmain.getInkasso());
                ps.setBoolean(10, cfgmain.isAffiliates());
                ps.setInt(11, cfgmain.getMaxdays());
                ps.setString(12, cfgmain.getXpwp());
                ps.setString(13, cfgmain.getTerminalweb());
                ps.setString(14, cfgmain.getPasswordweb());
                ps.setString(15, cfgmain.getBumaAgency());
                ps.setString(16, cfgmain.getTerminal());
                ps.setString(17, cfgmain.getBumaPassword());
                ps.setString(18, cfgmain.getGiataXmlUser());
                ps.setString(19, cfgmain.getGiataXmlpwd());
                ps.setBoolean(20, cfgmain.isHotelInfoCenter());
                ps.setBoolean(21, cfgmain.isReviews());
                ps.setInt(22, cfgmain.getReviewProvider());
                ps.setObject(23, (vasetOrPrimaryCfg==1?  Integer.parseInt(cfgmain.getCfgMainVaset()): null));
                ps.setBoolean(24, cfgmain.isOpControl());

                ps.setString(25, adminKunde.getRbagb());
                ps.setBoolean(26, false);
                ps.setString(27, "");
                ps.setString(28, adminKunde.getTuiAgencyNummer());
                ps.setString(29, adminKunde.getEmail());
                ps.setString(30, adminKunde.getGiataIhgUid());
                ps.setInt(31, adminKunde.getMaxPriceDiff());
                ps.setInt(32, adminKunde.getVersicherung());

                ps.setInt(33, buchungsModus.getFromMin());
                ps.setString(34, buchungsModus.getFromMin1());
                ps.setInt(35, buchungsModus.getOnline());
                ps.setString(36, buchungsModus.getOnlineTill());
                ps.setInt(37, buchungsModus.getBookto());

                ps.setString(38, mixer.getXsl());
                ps.setString(39, mixer.getEmailAdmin());
                ps.setString(40, mixer.getCachesource());
                ps.setInt(41, mixer.getRating());
                ps.setString(42, mixer.getRatingName());
                ps.setInt(43, mixer.getFacetcount());
                ps.setInt(44, mixer.getMixer());
                ps.setBoolean(45, mixer.isHubPriority());

                ps.setString(46, user);
                return ps;
            }
        }, keyHolder);

        //return (int) keyHolder.getKeys().get("cfg");
    }

    public void insertValistCfg(int cfgKey, final List<String> vasetList) {
        if (vasetList.isEmpty()) {
            LOGGER.error("Cound not get Veranstalter-Set!");
            return;
        }

        Session session = getSession();
        for (String vasetCode : vasetList) {
            ValistCfg valistCfg = new ValistCfg();
            ValistCfgPK pk = new ValistCfgPK(cfgKey, vasetCode);
            valistCfg.setValistCfgPK(pk);
            session.save(valistCfg);
        }
        session.flush();
        session.clear();
    }

    public void removeVaaktivCfgs(String vacode) {
        List<String> vaCodeList = Arrays.asList(vacode);
        removeVaaktivCfgs(vaCodeList);
    }

    public void removeVaaktivCfgs(List<String> vaCodeList) {
        removeVaaktivCfgs(-1, vaCodeList);
    }

    public void removeVaaktivCfgs(int cfgId, List<String> vaCodeList) {
        boolean hasCfg = false;
        StringBuilder sql = new StringBuilder("DELETE FROM va_aktiv_cfgs WHERE ");
        if (cfgId >= 0) {
            sql.append(" cfg=").append(cfgId);
            hasCfg = true;
        }

        if (!vaCodeList.isEmpty()) {
            sql.append(hasCfg ? " AND " : "").append("(");
            String delimiter = " ";
            for (String tourop : vaCodeList) {
                sql.append(delimiter).append("tourop=").append("$$" + tourop + "$$");
                delimiter = " OR ";
            }
            sql.append(")");
        }

        jdbcTemplate.update(sql.toString());
    }

    public void insertVaaktivCfgs(int cfgKey, final List<TourOperator> opList, List<String> activeList, List<String> onlineList) {
        if (opList.isEmpty()) {
            LOGGER.error("Could not get Veranstalters!");
            return;
        }

        StringBuilder vaAktivCfgSql = new StringBuilder("INSERT INTO va_aktiv_cfgs (cfg, tourop, active, bookonline) VALUES ");
        String delimiter = " ";
        for (TourOperator tourop : opList) {
            String opCode = tourop.getTourop();
            boolean active = activeList.contains(opCode);
            boolean online = false;
            if (onlineList.contains(opCode)) {
                online = true;
            }
            vaAktivCfgSql.append(delimiter).append("(").append(cfgKey).append(",$$").append(opCode).append("$$,")
            .append(active).append(",").append(online).append(")");
            delimiter = Constants.COMMA;
        }
        jdbcTemplate.update(vaAktivCfgSql.toString());
    }

    public void insertCharterflugProvisionen(int cfgKey, ListMultimap<String, String> sgcollectionMap) {
        //sgcollectionMap: {5VF=[10,10,10] , AB=[12,30,30], ....}
        StringBuilder charterProvSql = new StringBuilder("INSERT INTO servicecharges_cfg (cfg, tourop, sc_short, sc_middle, sc_long) VALUES ");
        String delimiter = " ";
        for (String key : sgcollectionMap.keySet()) {
            String kurz = sgcollectionMap.get(key).get(0);
            String mittel = sgcollectionMap.get(key).get(1);
            String fern = sgcollectionMap.get(key).get(2);
            charterProvSql.append(delimiter).append("(").append(cfgKey).append(",$$").append(key).append("$$,").append(kurz).append(",").append(mittel).append(",").append(fern).append(")");
            delimiter = Constants.COMMA;
        }
        jdbcTemplate.update(charterProvSql.toString());
    }

    public void updateBumaAgencyAndInsuranceAndTui(String user, List<Integer> cfgList, String bumaAgency, int insurance, String tui) {
        if (cfgList.isEmpty()) {
            return;
        }
        StringBuilder cfgSql = new StringBuilder("UPDATE cfglist AS h SET ");
        cfgSql.append("bumaagency=s.bumaagency, insurance=s.insurance, tui_agencynumber=s.tui_agencynumber, update_by=s.update_by FROM(VALUES ");
        String delimiter = " ";
        for (Integer cfg : cfgList) {
            cfgSql.append(delimiter).append("(" + cfg).append(",$$" + bumaAgency + "$$,").append(insurance).append(",$$" + tui + "$$").append(",$$" + user + "$$)");
            delimiter = Constants.COMMA;
        }
        cfgSql.append(") AS s(cfg, bumaagency, insurance, tui_agencynumber, update_by) WHERE h.cfg=s.cfg");
        jdbcTemplate.update(cfgSql.toString());
    }

    public void updateBuchungsmodus(String user,  List<Integer> cfgKeys, CfgBuchungsModus buchungsModus ) {
        if (cfgKeys.isEmpty()) {
            return;
        }
        StringBuilder cfgSql = new StringBuilder("UPDATE cfglist AS h SET ");
        cfgSql.append("from_min=s.from_min, from_min1=s.from_min1, online=s.online, online_till=s.online_till, book_to=s.book_to, update_by=s.update_by FROM(VALUES ");
        String delimiter = " ";
        for (Integer cfg : cfgKeys) {
            cfgSql.append(delimiter).append("(" + cfg).append("," + buchungsModus.getFromMin()).append(",$$" + buchungsModus.getFromMin1() + "$$,")
                  .append(buchungsModus.getOnline()).append(",$$" + buchungsModus.getOnlineTill() + "$$,").append(buchungsModus.getBookto()).append(",$$" + user + "$$)");
            delimiter = Constants.COMMA;
        }
        cfgSql.append(") AS s(cfg, from_min, from_min1, online, online_till, book_to, update_by) WHERE h.cfg=s.cfg");
        jdbcTemplate.update(cfgSql.toString());
    }

    public void updateCharterflugProvisionen(String user, int cfgKey, ListMultimap<String, String> sgcollectionMap) {
        updateCharterflugProvisionen(user, Arrays.asList(cfgKey), sgcollectionMap);
    }

    public void updateCharterflugProvisionen(String user, List<Integer> cfgKeys, ListMultimap<String, String> sgcollectionMap) {
        StringBuilder charterProvSql = new StringBuilder("UPDATE servicecharges_cfg AS h SET ");
        charterProvSql.append("sc_short=s.sc_short, sc_middle=s.sc_middle, sc_long=s.sc_long , update_by=s.update_by FROM (VALUES ");
        String delimiter = "";
        for (Integer cfgKey : cfgKeys) {
            for (String key : sgcollectionMap.keySet()) {
                String kurz = sgcollectionMap.get(key).get(0);
                String mittel = sgcollectionMap.get(key).get(1);
                String fern = sgcollectionMap.get(key).get(2);
                charterProvSql.append(delimiter).append("(").append(cfgKey).append(",$$").append(key).append("$$,")
                .append(kurz).append(",").append(mittel).append(",").append(fern).append(",").append("$$" + user + "$$)");
                delimiter = Constants.COMMA;
            }
        }
        charterProvSql.append(") AS s(cfg, tourop, sc_short, sc_middle, sc_long, update_by) ");
        charterProvSql.append("WHERE h.cfg = s.cfg AND h.tourop = s.tourop");
        jdbcTemplate.update(charterProvSql.toString());
        /*
        UPDATE servicecharges_cfg AS h SET sc_short=s.sc_short, sc_middle=s.sc_middle, sc_long=s.sc_long
        FROM (
            VALUES(0, '5VF', 15, 0, 0, 0),
                  (0, 'ALL', 0, 10,9,8)
        ) AS s(cfg, tourop, sc_short, sc_middle, sc_long) WHERE h.cfg = s.cfg AND h.tourop = s.tourop
       */
    }

    public void insertHoteloCalc(HoteloAufschlag aufschlag) {
        persist(aufschlag);
    }

    public void insertHotelo(List<HoteloDest> hoteloDestList) {
        Session session = getSession();
        for (HoteloDest hd : hoteloDestList) {
            persist(hd);
        }
        session.flush();
        session.clear();
    }

    public void updateCfgList(String user, final CfgMain cfgmain, final CfgAdminKunde adminKunde, final CfgBuchungsModus buchungsModus, final CfgMixer mixer) {

      final String cfgSqlStr = "UPDATE cfglist SET name=?,status=?,licence_validto=?,debitorennummer=?,configmode=?,comment=?,"
              + "layoutid=?,inkasso=?,affiliates=?,maxdays=?,xpwp=?,terminalweb=?,passwortweb=?,bumaagency=?,terminal=?,password=?,"
              + "giata_xmluser=?,giata_xmlpwd=?,hotelinfocenter=?,opcontrol=?,reviews=?,reviewprovider=?,primary_cfg=?,lastupdate=?,"
              + "ota_gtc=?,onrequest=?,agencynumber=?,tui_agencynumber=?,email=?,giata_ihg_uid=?,max_pricediff=?,insurance=?,"
              + "from_min=?,from_min1=?,online=?,online_till=?,book_to=?,"
              + "xsl=?,email_admin=?,cache_source=?,rating=?,ratingname=?,facetcount=?,mixer=?,hubpriority=?,update_by=? "
              + "WHERE cfg=" + cfgmain.getCfgNumber();

      jdbcTemplate.update(cfgSqlStr, new Object[] {cfgmain.getCfgName(), cfgmain.isCfgStatus(), cfgmain.getLicenceValidDate(),
              cfgmain.getDebitorenNr(), 3, cfgmain.getCfgComment(), cfgmain.getLayoutId(),
              cfgmain.getInkasso(), cfgmain.isAffiliates(), cfgmain.getMaxdays(), cfgmain.getXpwp(), cfgmain.getTerminalweb(),
              cfgmain.getPasswordweb(), cfgmain.getBumaAgency(), cfgmain.getTerminal(), cfgmain.getBumaPassword(),
              cfgmain.getGiataXmlUser(), cfgmain.getGiataXmlpwd(), cfgmain.isHotelInfoCenter(), cfgmain.isOpControl(),
              cfgmain.isReviews(), cfgmain.getReviewProvider(), cfgmain.getCfgMainVasetOrHaupt() == 1 ? Integer.parseInt(cfgmain.getCfgMainVaset()):null, new Date(),
              //admin kunde
              adminKunde.getRbagb(), false, "", adminKunde.getTuiAgencyNummer(),
              adminKunde.getEmail(), adminKunde.getGiataIhgUid(), adminKunde.getMaxPriceDiff(),adminKunde.getVersicherung(),
              //Buchungsmodus
              buchungsModus.getFromMin(), buchungsModus.getFromMin1(), buchungsModus.getOnline(), buchungsModus.getOnlineTill(), buchungsModus.getBookto(),
              //Mixer
              mixer.getXsl(), mixer.getEmailAdmin(), mixer.getCachesource(), mixer.getRating(), mixer.getRatingName(), mixer.getFacetcount(), mixer.getMixer(),mixer.isHubPriority(),
              user});
   }

    public List<ValistCfg> getValistCfgByCfg(int cfgId) {
        Session session = getSession();
        return session.createCriteria(ValistCfg.class).add(Restrictions.eq("valistCfgPK.cfg", cfgId)).list();
    }

    public void removeVasetFromValistCfg(int cfgId, List<String> vasetList) {
        Session session = getSession();
        StringBuilder hql = new StringBuilder("DELETE FROM ValistCfg WHERE cfg=").append(cfgId);
        if (!vasetList.isEmpty()) {
            session.createQuery(hql.append(" AND code IN :valist").toString()).setParameterList("valist", vasetList).executeUpdate();
        } else {
            session.createQuery(hql.toString()).executeUpdate();
        }
    }

    public void removeVasetByCfg(int cfgId) {
        removeVasetFromValistCfg(cfgId, new ArrayList<String>());
        removeVaaktivCfgs(cfgId, new ArrayList<String>());
    }

    public void updateHoteloCalc(HoteloAufschlag aufschlag) {
        Session session = getSession();
        session.update(aufschlag);
    }

    public void updateHotelo(List<HoteloDest> hoteloDestList) {
        Session session = getSession();
        for (HoteloDest hd : hoteloDestList) {
            session.update(hd);
        }
    }

    public void rbadminUpdateCfgList(String user, final CfgMain cfgmain, final CfgAdminKunde adminKunde, final CfgBuchungsModus buchungsModus) {

        final String cfgSqlStr = "UPDATE cfglist SET lastupdate=?,inkasso=?,"
                + "ota_gtc=?,onrequest=?,agencynumber=?,tui_agencynumber=?,email=?,giata_ihg_uid=?,max_pricediff=?,insurance=?,"
                + "from_min=?,from_min1=?,online=?,online_till=?,book_to=?,update_by=? "
                + "WHERE cfg=" + cfgmain.getCfgNumber();

        jdbcTemplate.update(cfgSqlStr, new Object[] {new Date(), cfgmain.getInkasso(),
                //admin kunde
                adminKunde.getRbagb(), false, "", adminKunde.getTuiAgencyNummer(),
                adminKunde.getEmail(), adminKunde.getGiataIhgUid(), adminKunde.getMaxPriceDiff(), adminKunde.getVersicherung(),
                //Buchungsmodus
                buchungsModus.getFromMin(), buchungsModus.getFromMin1(), buchungsModus.getOnline(), buchungsModus.getOnlineTill(), buchungsModus.getBookto(),
                user});
     }

    public void updateVaaktivCfgs(String user, int cfgKey, List<TourOperator> opList, List<String> activeList, List<String> onlineList) {
        if (opList.isEmpty()) {
            LOGGER.error("Could not get Veranstalters!");
            return;
        }

        StringBuilder vaAktivCfgSql = new StringBuilder("UPDATE va_aktiv_cfgs AS h SET ");
        vaAktivCfgSql.append("active=s.active, bookonline=s.bookonline, update_by=s.update_by FROM(VALUES ");
        String delimiter = " ";
        for (TourOperator tourop : opList) {
            String tourCode = tourop.getTourop();
            boolean active = activeList.contains(tourCode);
            boolean online = onlineList.contains(tourCode);
            vaAktivCfgSql.append(delimiter).append("($$" + tourCode + "$$,").append(active).append(",").append(online).append(",$$" + user + "$$)");
            delimiter = Constants.COMMA;
        }
        vaAktivCfgSql.append(") AS s(tourop, active, bookonline, update_by) ");
        vaAktivCfgSql.append("WHERE h.cfg =").append(cfgKey).append(" AND h.tourop=s.tourop");
        jdbcTemplate.update(vaAktivCfgSql.toString());
        /*
        UPDATE va_aktiv_cfgs AS h SET active=s.active, bookonline=s.bookonline
        FROM (
            VALUES('DTA', true,true),
                  ('JAHA', false,false)
        ) AS s(tourop, active, bookonline) WHERE h.cfg = 39 AND h.tourop=s.tourop
         */
    }

    public void updateVaaktivCfgs(String user, String tourop, List<String> columnNames, List<Integer> values) {
        int size = columnNames.size();
        if (size == 0 || size != values.size()) {
            return;
        }
        StringBuilder vaAktivCfgSql = new StringBuilder("UPDATE va_aktiv_cfgs SET update_by=");
        vaAktivCfgSql.append("$$" + user + "$$");

        for (int i = 0; i < size; i++) {
            vaAktivCfgSql.append(Constants.COMMA).append(columnNames.get(i)).append("=").append(values.get(i));
        }
        vaAktivCfgSql.append(" WHERE tourop=").append("$$" + tourop + "$$");
        jdbcTemplate.update(vaAktivCfgSql.toString());
    }

    public List<Range> getVaaktivCfgs(int cfgId, List<String> vasetList) {
        List<Range> rangeList = new ArrayList<>();

        StringBuilder vaAktivCfgSql = new StringBuilder("SELECT vaac.* FROM valist v, va_aktiv_cfgs vaac WHERE v.vacode=vaac.tourop ");
        vaAktivCfgSql.append(" AND vaac.cfg=").append(cfgId);
        for (String tourop : vasetList) {
            vaAktivCfgSql.append(" AND v.code=").append("$$" + tourop + "$$");
        }
        vaAktivCfgSql.append(" ORDER BY vaac.tourop");
        SqlRowSet rowSet = jdbcTemplate.queryForRowSet(vaAktivCfgSql.toString());
        while (rowSet.next()) {
            Range range = new Range();
            range.setActive(rowSet.getBoolean("active"));
            range.setCode(rowSet.getString("tourop"));
            range.setOnline(rowSet.getBoolean("bookonline"));
            rangeList.add(range);
        }
        return rangeList;
    }

    public List<Range> getVaaktivCfgsBycfgid(int cfgId) {
        String valistCfgSql = "SELECT vaac.tourop, op.touropname, vaac.active, vaac.bookonline, op.servicecharge "
                            + " FROM va_aktiv_cfgs vaac, touroperator op WHERE vaac.tourop=op.tourop AND vaac.cfg=" + cfgId
                            + " ORDER BY op.tourop";
        SqlRowSet rowSet = jdbcTemplate.queryForRowSet(valistCfgSql);
        List<Range> rangeList = new ArrayList<>();
        while (rowSet.next()) {
            Range range = new Range();
            range.setCode(rowSet.getString("tourop"));
            range.setName(rowSet.getString("touropname"));
            range.setActive(rowSet.getBoolean("active"));
            range.setOnline(rowSet.getBoolean("bookonline"));
            range.setServiceCharge(rowSet.getInt("servicecharge"));
            rangeList.add(range);
        }
        return rangeList;
    }

    public List<String> getTouropFromVaaktivCfgs(int cfgId) {
        String vaAktivCfgSql = "SELECT tourop FROM va_aktiv_cfgs WHERE cfg=" + cfgId;
        return jdbcTemplate.queryForList(vaAktivCfgSql, String.class);
    }

    public List<String> getVeranstaltersWithActiveHubOrCacheByCfg(int cfgNr) {
        String sql = "SELECT vaac.tourop FROM va_aktiv_cfgs vaac, touroperator op WHERE vaac.active=true AND (op.source_hub=true OR op.source_cache=true) AND vaac.tourop=op.tourop AND cfg=" + cfgNr + " ORDER BY vaac.tourop";
        return jdbcTemplate.queryForList(sql, String.class);
    }

    /**
     * Whether given CFG is a haupt-CFG of other CFGs
     *
     * @param cfg
     * @return
     */
    public boolean isCfgHaupt(String cfg) {
        int count = jdbcTemplate.queryForObject("SELECT COUNT(*) FROM cfglist WHERE primary_cfg=?", new Object[] { Integer.valueOf(cfg) }, Integer.class);
        return count > 0;
    }

    public Object[] getCfgStatusAndPrimary(int cfgId) {
        String sql = "SELECT status, primary_cfg FROM cfglist WHERE cfg=" + cfgId;
        Object[] objs = new Object[2];
        SqlRowSet rowSet = jdbcTemplate.queryForRowSet(sql);
        while (rowSet.next()) {
            objs[0] = rowSet.getBoolean("status");
            objs[1] = rowSet.getObject("primary_cfg");
        }
        return objs;
    }

}
