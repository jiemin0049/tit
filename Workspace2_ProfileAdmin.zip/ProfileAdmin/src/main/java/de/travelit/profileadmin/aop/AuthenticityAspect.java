package de.travelit.profileadmin.aop;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import de.travelit.profileadmin.Constants;
import de.travelit.profileadmin.model.Authenticity;

/**
 * This class is not used any more, but left here to remember RequestContextHolder.currentRequestAttributes().
 * @author zhang
 *
 */
@Aspect
public class AuthenticityAspect {

    private static final Logger LOGGER = Logger.getLogger(AuthenticityAspect.class);

    // Don't use AOP to check user status, use Interceptor. When user is in app but restart tomcat,
    // I get NullPointException, if use Interceptor, the exception is gone.

    //@Before("execution(public * de.travelit.profileadmin.controller.*.*(..)) && !execution(* de.travelit.profileadmin.controller.LoginController.*(..))")
    public void isloginAdvice() {
        ServletRequestAttributes requestAttr = (ServletRequestAttributes) RequestContextHolder.currentRequestAttributes();
        HttpServletRequest request = requestAttr.getRequest();
        Authenticity auth = (Authenticity) request.getSession().getAttribute(Constants.SESSION_KEY_AUTHENTICITY);
        if (null == auth) {
            LOGGER.fatal("Authenticity failed, redirect to login page!!!!");
            HttpServletResponse response = requestAttr.getResponse();
            try {
                response.sendRedirect("logout");
            } catch (IOException e) {
                LOGGER.fatal("Authenticity failed, redirect failed!!!!");
            }
        }
    }
}
