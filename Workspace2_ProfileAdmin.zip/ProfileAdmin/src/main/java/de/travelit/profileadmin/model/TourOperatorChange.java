package de.travelit.profileadmin.model;

public class TourOperatorChange {
    private String tourop;
    private String touropName;
    private boolean active;
    private boolean selected;
    private int serviceCharge;

    public String getTourop() {
        return tourop;
    }

    public void setTourop(String tourop) {
        this.tourop = tourop;
    }

    public String getTouropName() {
        return touropName;
    }

    public void setTouropName(String touropName) {
        this.touropName = touropName;
    }

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

    public boolean isSelected() {
        return selected;
    }

    public void setSelected(boolean selected) {
        this.selected = selected;
    }

    public int getServiceCharge() {
    	return serviceCharge;
    }

    public void setServiceCharge(int serviceCharge) {
    	this.serviceCharge = serviceCharge;
    }

}
