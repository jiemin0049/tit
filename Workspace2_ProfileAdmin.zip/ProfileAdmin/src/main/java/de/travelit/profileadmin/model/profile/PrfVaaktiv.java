package de.travelit.profileadmin.model.profile;

public class PrfVaaktiv {
    private int cfg;
    private String tourop;
    private boolean active;
    private boolean hub;
    private boolean cache;
    private boolean bookOnline;

    public int getCfg() {
        return cfg;
    }

    public void setCfg(int cfg) {
        this.cfg = cfg;
    }

    public String getTourop() {
        return tourop;
    }

    public void setTourop(String tourop) {
        this.tourop = tourop;
    }

    public boolean isActive() {
        return active;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

    public boolean getHub() {
        return hub;
    }

    public void setHub(boolean hub) {
        this.hub = hub;
    }

    public boolean getCache() {
        return cache;
    }

    public void setCache(boolean cache) {
        this.cache = cache;
    }

    public boolean getBookOnline() {
        return bookOnline;
    }

    public void setBookOnline(boolean bookOnline) {
        this.bookOnline = bookOnline;
    }

}
