package de.travelit.profileadmin.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "cfgs")
public class CfgList implements Serializable {

  private static final long serialVersionUID = -5815711195216442281L;

  private List<CfgMain> cfgs = new ArrayList<CfgMain>();

  @XmlElement(name = "cfg")
  public List<CfgMain> getCfgs() {
    return cfgs;
  }

  public void setCfgs(List<CfgMain> cfgs) {
    this.cfgs = cfgs;
  }
}