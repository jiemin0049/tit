package de.travelit.profileadmin;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import java.util.Timer;
import java.util.concurrent.TimeUnit;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.annotation.WebListener;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.google.common.base.Strings;

import de.travelit.profileadmin.task.BackupAndCleanProtokollTask;
import de.travelit.profileadmin.task.ProfileFileWriteTask;
import de.travelit.profileadmin.task.PushTask;

@WebListener()
public class ProfileAdminListener implements ServletContextListener {

    private static final Logger LOGGER = Logger.getLogger(ProfileAdminListener.class);
    private final Timer timer = new Timer();

    @Autowired
    private PushTask pushTask;

    public ProfileAdminListener() {
        setProperties();
    }

    private void setProperties() {
        try {
            FileInputStream propFile = new FileInputStream(Constants.PROPERTIES_FILE);
            Properties p = new Properties(System.getProperties());
            p.load(propFile);
            System.setProperties(p);
        } catch (IOException e) {
            LOGGER.error("load property files failed.", e);
        }
    }

    @Override
    public void contextDestroyed(ServletContextEvent sce) {
        timer.cancel();
        timer.purge();
    }

    @Override
    public void contextInitialized(ServletContextEvent sce) {
        startProfileTask();
        startBackupAndCleanProtokollTask();
        //http://stackoverflow.com/questions/4746041/spring-injecting-a-dependency-into-a-servletcontextlistener
        //At this time can not autowird "pushTask", so use this.
        WebApplicationContextUtils.getRequiredWebApplicationContext(sce.getServletContext()).getAutowireCapableBeanFactory().autowireBean(this);
        startPushTask();
    }

    /**
     * Task for rewrite Profile.ini file when CFG is changed.
     */
    private void startProfileTask() {
        ProfileFileWriteTask task = ProfileFileWriteTask.getInstance();
        long period = getPeriod(Constants.PROFILE_PERIOD);
        timer.schedule(task, period, period);
    }

    private void startBackupAndCleanProtokollTask() {
        String m = System.getProperty(Constants.PROTOKOLL_MAXDAYS);
        if (!Constants.isInteger(m)) {
            return;
        }

        int maxDays = Integer.parseInt(m);
        if (maxDays <= 0) {
            return;
        }

        String dir = System.getProperty(Constants.PROTOKOLL_DIR);
        if (Strings.isNullOrEmpty(dir)) {
            LOGGER.fatal("Can not write protokoll file, protokoll directory not found!");
            return;
        }

        BackupAndCleanProtokollTask task = BackupAndCleanProtokollTask.getInstance();
        task.setMaxDays(maxDays);
        task.setDirectory(dir);
        timer.schedule(task, 0, TimeUnit.DAYS.toMillis(1));

    }

    private long getPeriod(String prop) {
        long minute = Constants.DEFAULT_PERIOD;
        String p = System.getProperty(prop);
        if (Constants.isInteger(p)) {
            long longValue = Long.parseLong(p);
            if (longValue > 0) {
                minute = longValue;
            }
        }
        return TimeUnit.MINUTES.toMillis(minute);
    }

    /**
     * Start push timer to notify other systems that there are cfg or operator change.
     */
    private void startPushTask() {
        timer.schedule(pushTask, 0, TimeUnit.MINUTES.toMillis(5));
    }
}
