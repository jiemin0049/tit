package de.travelit.profileadmin.service.audit;

import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.google.common.base.Joiner;

import de.travelit.profileadmin.dao.ProtokollDao;
import de.travelit.profileadmin.model.Protokoll;
import de.travelit.profileadmin.model.Range;
import de.travelit.profileadmin.service.CfgService;

@Service
@Transactional
public class CfgAuditService {

    private static final Logger LOGGER = Logger.getLogger(CfgAuditService.class);

    @Autowired
    private ProtokollDao protokollDao;

    @Autowired
    private CfgService cfgService;

    public void logRemoveVasetFromCfg(String username, int cfgId, String tableName, List<String> vasetList) {
        String vaset = Joiner.on("|").join(vasetList);

        Protokoll protokoll = new Protokoll();
        protokoll.setOperation("DELETE");
        protokoll.setTabelle(tableName);
        protokoll.setField("code");
        protokoll.setPk1(cfgId + "");
        protokoll.setOldValue(vaset);
        protokoll.setUpdateBy(username);

        protokollDao.writeProtokoll(protokoll);
    }

    public void logInsertValistCfg(String username, int cfgId, List<String> vasetList) {
        String vaset = Joiner.on("|").join(vasetList);

        Protokoll protokoll = new Protokoll();
        protokoll.setOperation("INSERT");
        protokoll.setTabelle("valist_cfg");
        protokoll.setField("code");
        protokoll.setPk1(cfgId + "");
        protokoll.setNewValue(vaset);
        protokoll.setUpdateBy(username);

        protokollDao.writeProtokoll(protokoll);
    }

    @Transactional
    public void loginsertVaaktivCfgs(String username, int cfgId, final List<String> vasetList) {
        if (vasetList.isEmpty()) {
            LOGGER.error("Cound not get Veranstalter-Set by logging insert va_aktiv_cfgs!");
            return;
        }

        List<Protokoll> protokolls = new ArrayList<>();
        List<Range> vaaktivCfgsList = cfgService.getVaaktivCfgs(cfgId, vasetList);
        if (vaaktivCfgsList.isEmpty()) {
            return;
        }

        for (Range r : vaaktivCfgsList) {
            Protokoll p = new Protokoll();
            p.setOperation("INSERT");
            p.setTabelle("va_aktiv_cfgs");
            p.setPk1(cfgId + "");
            p.setPk2(r.getCode());
            p.setNewValue(r.isActive() + "|" + r.getOnline());
            p.setUpdateBy(username);
            //protokolls.add(p);
        }

        protokollDao.writeProtokolls(protokolls);
    }

}
