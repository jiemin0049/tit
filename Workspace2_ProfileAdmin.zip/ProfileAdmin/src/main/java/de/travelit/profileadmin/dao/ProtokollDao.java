package de.travelit.profileadmin.dao;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import org.apache.log4j.Logger;
import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import com.google.common.collect.Lists;

import de.travelit.profileadmin.Constants;
import de.travelit.profileadmin.model.Protokoll;
import de.travelit.profileadmin.model.ProtokollSearch;

@Repository
public class ProtokollDao extends AbstractDao {

    private static final Logger LOGGER = Logger.getLogger(ProtokollDao.class);

    public List<Protokoll> getProtokolls(String dateTime) {
        Session session = getSession();
        Query query = session.createQuery("FROM Protokoll WHERE datetime <= :datetime order by id");
        query.setParameter("datetime", dateTime);
        return (List<Protokoll>) query.list();
    }

    public void cleanProtokoll(List<Protokoll> protokolls) {
        LOGGER.info("Begin to clean protolls in database.");

        Session session = getSession();
        for (Protokoll p : protokolls) {
            session.delete(p);
        }
    }

    public void writeProtokoll(Protokoll protokoll) {
        persist(protokoll);
    }

    public void writeProtokolls(List<Protokoll> protokolls) {
        Session session = getSession();
        for (int i = 0; i < protokolls.size(); i++) {
            session.save(protokolls.get(i));
            //http://docs.jboss.org/hibernate/orm/4.3/manual/en-US/html/ch15.html
            //20, same as the JDBC batch size
            if (i % 20 == 0) {
                //flush a batch of inserts and release memory
                session.flush();
                session.clear();
            }
        }
    }

    public List<Protokoll> list(ProtokollSearch search) {
        return this.list(search, -1);
    }

    public List<Protokoll> list(ProtokollSearch search, int limit) {
        Session session = getSession();
        Criteria criteria = session.createCriteria(Protokoll.class);

        if (!search.getPk1().isEmpty()) {
            //criteria.add(Restrictions.ilike("pk1", "%" + search.getPk1() + "%"));
            criteria.add(Restrictions.eq("pk1", search.getPk1()).ignoreCase());
        }

        List<String> opList = new ArrayList<>();
        if (search.getInsert()) {
            opList.add("INSERT");
        }
        if (search.getUpdate()) {
            opList.add("UPDATE");
        }
        if (search.getDelete()) {
            opList.add("DELETE");
        }
        if (!opList.isEmpty()) {
            criteria.add(Restrictions.in("operation", opList));
        }

        if (!search.getDateFrom().isEmpty()) {
            criteria.add(Restrictions.ge("datetime", search.getDateFrom()));
        }
        if (!search.getDateTo().isEmpty()) {
            String dateTo = search.getDateTo();
            DateFormat format = new SimpleDateFormat("yyy-MM-dd", Locale.GERMANY);
            DateFormat format2 = new SimpleDateFormat("yyy-MM-dd HH:mm:ss", Locale.GERMANY);
            Calendar cal = Calendar.getInstance();
            try {
                Date date = format.parse(dateTo);
                cal.setTime(date);
                cal.set(Calendar.HOUR_OF_DAY, 23);
                cal.set(Calendar.MINUTE, 59);
                cal.set(Calendar.SECOND, 59);
                cal.set(Calendar.MILLISECOND, 999);
                dateTo = format2.format(cal.getTime()) + "+02"; //Postgres now(), sommertime +02, wintertime +01
            } catch (ParseException e) {
                LOGGER.info("Format date error!", e);
            }
            criteria.add(Restrictions.le("datetime", dateTo));
        }

        if (!search.getUpdatedBy().isEmpty()) {
            criteria.add(Restrictions.ilike("updateBy", "%" + search.getUpdatedBy() + "%"));
        }

        String tables = search.getTables();
        if (!tables.isEmpty()) {
            Iterable<String> iterable = Constants.ON_COMMA_OMITEMPTY.split(tables);
            List<String> tableList = Lists.newArrayList(iterable);
            if (!tableList.isEmpty()) {
                criteria.add(Restrictions.in("tabelle", tableList));
            }
        }

        criteria.addOrder(Order.asc("id"));
        if (limit < 0) {
            return criteria.list();
        } else {
            return criteria.setFirstResult(0).setMaxResults(limit).list();
        }
    }

    public List<Protokoll> list(Integer offset, Integer maxResults) {
        Session session = getSession();
        return session.createCriteria(Protokoll.class).setFirstResult(offset != null ? offset : 0).setMaxResults(maxResults != null ? maxResults : 10).list();
    }

    public Long count() {
        Session session = getSession();
        return (Long) session.createCriteria(Protokoll.class).setProjection(Projections.rowCount()).uniqueResult();
    }

}
