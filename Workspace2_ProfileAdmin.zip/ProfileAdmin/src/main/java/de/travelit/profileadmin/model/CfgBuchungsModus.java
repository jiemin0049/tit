package de.travelit.profileadmin.model;

import de.travelit.profileadmin.Constants;

public class CfgBuchungsModus {
    private int fromMin;
    private String fromMin1;
    private int online;
    private String onlineTill = Constants.DEFAULT_ONLINETILL;
    private int bookto;

    public int getFromMin() {
        return fromMin;
    }

    public void setFromMin(int fromMin) {
        this.fromMin = fromMin;
    }

    public String getFromMin1() {
        return fromMin1;
    }

    public void setFromMin1(String fromMin1) {
        this.fromMin1 = fromMin1;
    }

    public int getOnline() {
        return online;
    }

    public void setOnline(int online) {
        this.online = online;
    }

    public String getOnlineTill() {
        return onlineTill;
    }

    public void setOnlineTill(String onlineTill) {
        this.onlineTill = onlineTill;
    }

    public int getBookto() {
        return bookto;
    }

    public void setBookto(int bookto) {
        this.bookto = bookto;
    }

}
