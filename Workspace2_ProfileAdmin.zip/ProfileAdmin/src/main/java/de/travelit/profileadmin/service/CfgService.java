package de.travelit.profileadmin.service;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.log4j.Logger;
import org.springframework.aop.framework.AopContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.google.common.base.Joiner;
import com.google.common.base.Predicate;
import com.google.common.base.Strings;
import com.google.common.collect.ArrayListMultimap;
import com.google.common.collect.Collections2;
import com.google.common.collect.ListMultimap;
import com.google.common.collect.Lists;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

import de.travelit.profileadmin.Constants;
import de.travelit.profileadmin.dao.CfgDao;
import de.travelit.profileadmin.dao.HicContentDao;
import de.travelit.profileadmin.dao.VeranstalterListDao;
import de.travelit.profileadmin.model.CfgAdminKunde;
import de.travelit.profileadmin.model.CfgBuchungsModus;
import de.travelit.profileadmin.model.CfgHic;
import de.travelit.profileadmin.model.CfgMain;
import de.travelit.profileadmin.model.HicContent;
import de.travelit.profileadmin.model.HoteloAufschlag;
import de.travelit.profileadmin.model.HoteloDest;
import de.travelit.profileadmin.model.HoteloDest.HoteloDestPK;
import de.travelit.profileadmin.model.Range;
import de.travelit.profileadmin.model.TourOperator;
import de.travelit.profileadmin.model.ValistCfg;
import de.travelit.profileadmin.model.mixer.CfgMixer;

@Service
@Transactional
public class CfgService {

    private static final Logger LOGGER = Logger.getLogger(CfgService.class);

    @Autowired
    private CfgDao cfgDao;

    @Autowired
    private VeranstalterListDao vaListDao;

    @Autowired
    private HicContentDao hicContentDao;

    @Transactional(propagation = Propagation.NOT_SUPPORTED, readOnly = true)
    public List<CfgMain> getCfgList(String cfg, String kunde) {
        return cfgDao.getCfgList(cfg, kunde);
    }

    @Transactional(propagation = Propagation.NOT_SUPPORTED, readOnly = true)
    public List<CfgMain> getActiveCfgList() {
        List<CfgMain> allCfgs = cfgDao.getCfgList("", "");
        Collection<CfgMain> result = Collections2.filter(allCfgs, new Predicate<CfgMain>() {
            @Override
            public boolean apply(CfgMain cfg) {
                return cfg.isCfgStatus();
            }
        });
        return new ArrayList<>(result);
    }

    @Transactional(propagation = Propagation.NOT_SUPPORTED, readOnly = true)
    public List<String> getActiveHubvaList() {
        ListMultimap<Integer, String> hubvaMap = cfgDao.getActiveHubvaList();
        Map<Integer, Integer> cfgWithPrimaryCfg = cfgDao.getCfgPrimaryCfgMap();
        for (Integer key : cfgWithPrimaryCfg.keySet()) {
            Integer primayrCfg = cfgWithPrimaryCfg.get(key);
            hubvaMap.putAll(key, hubvaMap.get(primayrCfg));
        }
        List<String> hubvaList = new ArrayList<>();
        Set<Integer> keySet = hubvaMap.keySet();
        Iterator<Integer> keyIterator = keySet.iterator();
        while (keyIterator.hasNext()) {
            Integer key = keyIterator.next();
            StringBuilder sb = new StringBuilder(key + "");
            List<String> values = hubvaMap.get(key);
            sb.append(":").append(Joiner.on(Constants.BACK_SLASH).join(values)).append(Constants.BACK_SLASH);
            hubvaList.add(sb.toString());
        }
        return hubvaList;
    }

    @Transactional(propagation = Propagation.NOT_SUPPORTED, readOnly = true)
    public List<CfgMain> getCfgList(List<String> cfgList) {
        if (cfgList.isEmpty()) {
            return new ArrayList<CfgMain>();
        }

        List<CfgMain> cfgMainList = cfgDao.getCfgList(cfgList);
        if (cfgList.size() != cfgMainList.size()) {
            // some cfgs of user that I get from other system (@see
            // Constant.AUTHENTICATION_SERVLET)
            // maybe are not in my database, so I only show cfgs which are in my
            // database.
            cfgMainList = renewCfgMainList(cfgList, cfgMainList);
        }
        return cfgMainList;
    }

    private List<CfgMain> renewCfgMainList(List<String> cfgList, final List<CfgMain> cfgMainList) {
        List<CfgMain> rtnList = new ArrayList<CfgMain>();
        rtnList.addAll(cfgMainList);
        for (String c : cfgList) {
            CfgMain cfg = new CfgMain();
            cfg.setCfgNumber(Integer.parseInt(c));
            if (!cfgMainList.contains(cfg)) {
                rtnList.add(cfg);
            }
        }

        Collections.sort(rtnList, new Comparator<CfgMain>() {
            @Override
            public int compare(CfgMain o1, CfgMain o2) {
                return o1.getCfgNumber() - o2.getCfgNumber();
            }
        });
        return rtnList;
    }

    @Transactional(propagation = Propagation.NOT_SUPPORTED, readOnly = true)
    public Map<String, Object> getCfgData(String cfg) {
        Map<String, Object> cfgMap = cfgDao.getCfgbyId(cfg);
        HicContent hicConent = hicContentDao.readHicContent(Integer.parseInt(cfg));
        cfgMap.put("hitcontent", hicConent);
        if (!cfgMap.isEmpty()) {
            CfgBuchungsModus buchungsModus = (CfgBuchungsModus) cfgMap.get("buchungsmodus");
            updateOnlineTill(buchungsModus);
        }
        return cfgMap;
    }

    @Transactional(propagation = Propagation.NOT_SUPPORTED, readOnly = true)
    public Map<String, Object> getCfgMain(String cfg) {
        return cfgDao.getCfgMain(cfg);
    }

    @Transactional(propagation = Propagation.NOT_SUPPORTED, readOnly = true)
    public boolean isCfgHaupt(String cfg) {
        return cfgDao.isCfgHaupt(cfg);
    }

    @Transactional(propagation = Propagation.NOT_SUPPORTED, readOnly = true)
    public ListMultimap<String, Integer> getCharterflugProvisionen(String cfg) {
        return cfgDao.getCharterflugProvisionen(cfg);
    }

    public int createCfg(String user, CfgMain cfgmain, CfgAdminKunde adminKunde, CfgBuchungsModus buchungsModus,
            String vasetActive, String vasetOnline, String sgcollection, final HoteloAufschlag aufschlag,
            String hoteloCalc, HicContent hicContent, CfgMixer mixer) {

        updateOnlineTill(buchungsModus);

        int cfgKey = cfgmain.getCfgNumber();
        cfgDao.insertCfgList(user, cfgmain, adminKunde, buchungsModus, mixer);

        // vaset
        int vasetOrPrimaryCfg = cfgmain.getCfgMainVasetOrHaupt();
        if (vasetOrPrimaryCfg != 1) {
            String mainVaset = cfgmain.getCfgMainVaset();
            List<String> vasetList = stringWithCommaToList(mainVaset);
            cfgDao.insertValistCfg(cfgKey, vasetList);

            List<String> activeList = stringWithCommaToList(vasetActive);
            List<String> onlineList = stringWithCommaToList(vasetOnline);
            List<TourOperator> opList = vaListDao.getTourOperatorsBySetcodeList(new HashSet<String>(vasetList));
            cfgDao.insertVaaktivCfgs(cfgKey, opList, activeList, onlineList);
        }

        // Charterflug-Provisionen
        // 5VF:20_20_20/AB:5_5_5/ALL:10_10_10/CFI:10_10_10/FTI:20_20_20/ICC:20_20_20/ITS:0_0_0/JAHN:0_0_0/OGE:20_20_20/TIP:20_20_20/NEC:20_20_20/
        Map<String, String> sgMap = Constants.HOTELO_DEST_SPLITTER.split(sgcollection);
        ListMultimap<String, String> sgcollectionMap = convertChartProv(sgMap);
        cfgDao.insertCharterflugProvisionen(cfgKey, sgcollectionMap);
        aufschlag.setCfg(cfgKey);
        cfgDao.insertHoteloCalc(aufschlag);

        // hotelo
        // e.g. PMI:0_0_0_/HRG:0_0_0_/AGP:0_0_0_/FUE:0_0_0_/LPA:0_0_0_/...
        List<HoteloDest> hoteloDestList = convertToHoteloDestList(cfgKey, hoteloCalc);
        cfgDao.insertHotelo(hoteloDestList);

        // hiccontent
        if (cfgmain.isHotelInfoCenter()) {
            hicContent.setCfg(cfgKey);
            hicContentDao.createHicConent(hicContent);
        }

        LOGGER.info("Begin to push update HIC!");
        ServiceUtils.sendRequest(Constants.HIC_PUSH + cfgKey);

        return cfgKey;
    }

    private ListMultimap<String, String> convertChartProv(Map<String, String> chartProvMap) {
        ListMultimap<String, String> multimap = ArrayListMultimap.create();
        for (Map.Entry<String, String> entry : chartProvMap.entrySet()) {
            String op = entry.getKey();
            Iterable<String> iterable = Constants.ON_UNDERLINE_OMITEMPTY.split(entry.getValue());
            multimap.putAll(op, iterable);
        }
        return multimap;
    }

    private List<HoteloDest> convertToHoteloDestList(Integer cfgKey, String hoteloCalc) {
        return convertToHoteloDestList(null, cfgKey, hoteloCalc);
    }

    private List<HoteloDest> convertToHoteloDestList(String user, Integer cfgKey, String hoteloCalc) {
        // e.g. PMI:0_0_0_/HRG:0_0_0_/AGP:0_0_0_/FUE:0_0_0_/LPA:0_0_0_/...
        Map<String, String> tempMap = Constants.HOTELO_DEST_SPLITTER.split(hoteloCalc);
        List<HoteloDest> hoteloDestList = new ArrayList<>();
        for (Map.Entry<String, String> entry : tempMap.entrySet()) {
            HoteloDest hd = new HoteloDest();
            HoteloDestPK pk = new HoteloDestPK(cfgKey, entry.getKey());
            hd.setHoteloDestPK(pk);
            Iterable<String> iterable2 = Constants.ON_UNDERLINE_OMITEMPTY.split(entry.getValue());
            List<String> aufschlagList = Lists.newArrayList(iterable2);
            hd.setPercentageLow(Integer.parseInt(aufschlagList.get(0)));
            hd.setPercentageMiddle(Integer.parseInt(aufschlagList.get(1)));
            hd.setPercentageHigh(Integer.parseInt(aufschlagList.get(2)));
            if (!Strings.isNullOrEmpty(user)) {
                hd.setUpdateBy(user);
            }
            hoteloDestList.add(hd);
        }
        return hoteloDestList;
    }

    @Transactional(propagation = Propagation.NOT_SUPPORTED, readOnly = true)
    public CfgBuchungsModus getBuchungsModus(String cfg) {
        CfgBuchungsModus bm = cfgDao.getBuchungsModus(cfg);
        updateOnlineTill(bm);
        return bm;
    }

    private void updateOnlineTill(CfgBuchungsModus buchungsModus) {
        int online = buchungsModus.getOnline();
        if (online != 0) {
            String till = buchungsModus.getOnlineTill();
            Iterable<String> iterable = Constants.ON_BACKSLASH.split(till);
            List<String> tillList = Lists.newArrayList(iterable);
            for (int i = 0; i < tillList.size(); i++) {
                if (tillList.get(i).trim().isEmpty()) {
                    tillList.set(i, "23:59");
                }
            }
            buchungsModus.setOnlineTill(tillList.get(0) + "/" + tillList.get(1) + "/" + tillList.get(2));
        } else {
            buchungsModus.setOnlineTill(Constants.DEFAULT_ONLINETILL);
        }
    }

    public void commitCfgChange(String user, CfgMain cfgmain, CfgAdminKunde adminKunde, CfgBuchungsModus buchungsModus,
            String vasetActive, String vasetOnline, String sgcollection, final HoteloAufschlag aufschlag,
            String hoteloCalc, HicContent hicContent, CfgMixer mixer) {

        updateOnlineTill(buchungsModus);

        cfgDao.updateCfgList(user, cfgmain, adminKunde, buchungsModus, mixer);

        int vasetOrPrimaryCfg = cfgmain.getCfgMainVasetOrHaupt();
        int cfgKey = cfgmain.getCfgNumber();
        if (vasetOrPrimaryCfg == 0) {
            // va-set, and remove duplicate va-set
            List<String> vasetList = stringWithCommaToList(cfgmain.getCfgMainVaset());
            vasetList = new ArrayList<>(new HashSet<>(vasetList));

            List<String> activeList = stringWithCommaToList(vasetActive);
            List<String> onlineList = stringWithCommaToList(vasetOnline);

            updateValistForCfg(user, cfgKey, activeList, vasetList, onlineList);
        } else {
            cfgDao.removeVasetByCfg(cfgKey);
        }
        // Charterflug-Provisionen
        // 5VF:20_20_20/AB:5_5_5/ALL:10_10_10/CFI:10_10_10/FTI:20_20_20/ICC:20_20_20/ITS:0_0_0/JAHN:0_0_0/OGE:20_20_20/TIP:20_20_20/NEC:20_20_20/
        Map<String, String> sgMap = Constants.HOTELO_DEST_SPLITTER.split(sgcollection);
        ListMultimap<String, String> sgcollectionMap = convertChartProv(sgMap);

        // Update all CFGs which use this CFG as Haupt CFG
        List<Integer> cfgs = cfgDao.getCfgsWithPrimaryCfg(cfgKey);
        cfgDao.updateBumaAgencyAndInsuranceAndTui(user, cfgs, cfgmain.getBumaAgency(), adminKunde.getVersicherung(),
                adminKunde.getTuiAgencyNummer());
        cfgDao.updateBuchungsmodus(user, cfgs, buchungsModus);
        cfgs.add(cfgKey);
        cfgDao.updateCharterflugProvisionen(user, cfgs, sgcollectionMap);

        aufschlag.setCfg(cfgKey);
        aufschlag.setUpdateBy(user);
        cfgDao.updateHoteloCalc(aufschlag);

        // hotelo
        // e.g. PMI:0_0_0_/HRG:0_0_0_/AGP:0_0_0_/FUE:0_0_0_/LPA:0_0_0_/...
        List<HoteloDest> hoteloDestList = convertToHoteloDestList(user, cfgKey, hoteloCalc);
        cfgDao.updateHotelo(hoteloDestList);

        // hiccontent
        if (cfgmain.isHotelInfoCenter()) {
            hicContent.setCfg(cfgKey);
            hicContent.setUpdateBy(user);
            hicContentDao.saveOrUpdateHicContent(hicContent);
        }

        LOGGER.info("Begin to push update HIC!");
        ServiceUtils.sendRequest(Constants.HIC_PUSH + cfgKey);
    }

    private void updateValistForCfg(String user, int cfgKey, List<String> activeList, final List<String> vasetList,
            List<String> onlineList) {
        if (vasetList.isEmpty()) {
            LOGGER.error("Cound not get Veranstalter-Set!");
            return;
        }

        List<ValistCfg> valistCfgList = cfgDao.getValistCfgByCfg(cfgKey);
        List<String> oldvasetList = new ArrayList<>();
        for (ValistCfg vc : valistCfgList) {
            oldvasetList.add(vc.getValistCfgPK().getCode());
        }

        List<String> toInsertVasetList = (List<String>) CollectionUtils.removeAll(vasetList, oldvasetList);
        List<String> toDeleteVasetList = (List<String>) CollectionUtils.removeAll(oldvasetList, vasetList);
        List<String> stayVasetList = (List<String>) CollectionUtils.retainAll(oldvasetList, vasetList);

        List<TourOperator> oldOpList = vaListDao.getTourOperatorsBySetcodeList(new HashSet<String>(oldvasetList));
        List<TourOperator> newOpList = vaListDao.getTourOperatorsBySetcodeList(new HashSet<String>(vasetList));
        List<List<TourOperator>> threeVaaktivCfgs = ServiceUtils.getThreeToUpdateVaaktivCfgs(oldOpList, newOpList);

        // AOP can not intercept internal method call, I use AopContext to
        // resolve this problem.
        // But this is not a good idea, better solution is using AspectJ weaving
        // or implement interface.
        CfgService thisService = (CfgService) AopContext.currentProxy();
        if (!toDeleteVasetList.isEmpty()) {
            thisService.removeVasetFromValistCfg(cfgKey, toDeleteVasetList);
            List<String> touropList = ServiceUtils.getTourOpList(threeVaaktivCfgs.get(0));
            if (!touropList.isEmpty()) {
                thisService.removeVaaktivCfgs(cfgKey, touropList);
            }
        }

        if (!toInsertVasetList.isEmpty()) {
            thisService.insertValistCfg(cfgKey, toInsertVasetList);
            thisService.insertVaaktivCfgs(cfgKey, toInsertVasetList, threeVaaktivCfgs.get(2), activeList, onlineList);
        }

        if (!stayVasetList.isEmpty()) {
            cfgDao.updateVaaktivCfgs(user, cfgKey, threeVaaktivCfgs.get(1), activeList, onlineList);
        }
    }

    /**
     * This method is redundant, it can be intercepted by AOP, because I don't
     * want to intercept methods in DAO.
     *
     * @param cfgId
     * @param vasetList
     */
    public void removeVasetFromValistCfg(int cfgId, List<String> vasetList) {
        cfgDao.removeVasetFromValistCfg(cfgId, vasetList);
    }

    /**
     * This method is redundant, it can intercepted by AOP.
     *
     * @param cfgId
     * @param vasetList
     */
    public void removeVaaktivCfgs(int cfgId, List<String> touropList) {
        cfgDao.removeVaaktivCfgs(cfgId, touropList);
    }

    /**
     * cfgDao.insertValistCfg(..) is also used by create CFG, but I don't want
     * to intercept this by creating CFG. So I create this redundant method and
     * invoke it by CFG-update, it can be intercepted by AOP.
     */
    public void insertValistCfg(int cfgKey, final List<String> vasetList) {
        cfgDao.insertValistCfg(cfgKey, vasetList);
    }

    /**
     * cfgDao.insertVaaktivCfgs(..) is also used by create CFG, but I don't want
     * to intercept this by creating CFG. So I create this redundant method and
     * invoke it by CFG-update, it can be intercepted by AOP.
     *
     * Don't remove parameter vasetList, AOP needs it.
     *
     */
    public void insertVaaktivCfgs(int cfgKey, final List<String> vasetList, List<TourOperator> opList,
            List<String> activeList, List<String> onlineList) {
        cfgDao.insertVaaktivCfgs(cfgKey, opList, activeList, onlineList);
    }

    private List<String> stringWithCommaToList(String str) {
        Iterable<String> iterable = Constants.ON_COMMA_OMITEMPTY.split(str);
        return Lists.newArrayList(iterable);
    }

    public void rbadminCommitCfgChange(String user, CfgMain cfgmain, CfgAdminKunde adminKunde,
            CfgBuchungsModus buchungsModus, String vasetActive, String vasetOnline, String sgcollection,
            final HoteloAufschlag aufschlag, String hoteloCalc, HicContent hicContent) {

        updateOnlineTill(buchungsModus);

        cfgDao.rbadminUpdateCfgList(user, cfgmain, adminKunde, buchungsModus);

        int cfgKey = cfgmain.getCfgNumber();
        int vasetOrPrimaryCfg = cfgmain.getCfgMainVasetOrHaupt();
        if (vasetOrPrimaryCfg == 0) {
            // va-set
            List<String> vasetList = stringWithCommaToList(cfgmain.getCfgMainVaset());
            List<String> activeList = stringWithCommaToList(vasetActive);
            List<String> onlineList = stringWithCommaToList(vasetOnline);

            List<TourOperator> opList = vaListDao.getTourOperatorsBySetcodeList(new HashSet<String>(vasetList));
            cfgDao.updateVaaktivCfgs(user, cfgKey, opList, activeList, onlineList);
        } else {
            // Do nothing for vaset, because rbadmin can not change vaset, and
            // if cfg has primary cfg,
            // rbadmin can not change(check) any veranstalter-sortiment.
        }

        // Charterflug-Provisionen
        // 5VF:20_20_20/AB:5_5_5/ALL:10_10_10/CFI:10_10_10/FTI:20_20_20/ICC:20_20_20/ITS:0_0_0/JAHN:0_0_0/OGE:20_20_20/TIP:20_20_20/NEC:20_20_20/
        Map<String, String> sgMap = Constants.HOTELO_DEST_SPLITTER.split(sgcollection);
        ListMultimap<String, String> sgcollectionMap = convertChartProv(sgMap);
        List<Integer> cfgs = cfgDao.getCfgsWithPrimaryCfg(cfgKey);
        cfgs.add(cfgKey);
        cfgDao.updateCharterflugProvisionen(user, cfgs, sgcollectionMap);

        aufschlag.setCfg(cfgKey);
        aufschlag.setUpdateBy(user);
        cfgDao.updateHoteloCalc(aufschlag);

        // hotelo
        // e.g. PMI:0_0_0_/HRG:0_0_0_/AGP:0_0_0_/FUE:0_0_0_/LPA:0_0_0_/...
        List<HoteloDest> hoteloDestList = convertToHoteloDestList(user, cfgKey, hoteloCalc);
        cfgDao.updateHotelo(hoteloDestList);

        // hiccontent
        if (cfgmain.isHotelInfoCenter()) {
            hicContent.setCfg(cfgKey);
            hicContent.setUpdateBy(user);
            hicContentDao.saveOrUpdateHicContent(hicContent);
        }

        LOGGER.info("Begin to push update HIC!");
        ServiceUtils.sendRequest(Constants.HIC_PUSH + cfgKey);
    }

    @Transactional(propagation = Propagation.NOT_SUPPORTED, readOnly = true)
    public List<Range> getVaaktivCfgs(int cfgId, List<String> vasetList) {
        return cfgDao.getVaaktivCfgs(cfgId, vasetList);
    }

    @Transactional(propagation = Propagation.NOT_SUPPORTED, readOnly = true)
    public List<Range> getVaaktivCfgsBycfgid(int cfgId) {
        return cfgDao.getVaaktivCfgsBycfgid(cfgId);
    }

    @Transactional(propagation = Propagation.NOT_SUPPORTED, readOnly = true)
    public CfgHic getCfgHic(int cfgNr) {
        CfgHic cfgHic = cfgDao.getHicByCfgId(cfgNr);
        if (null == cfgHic) {
            return null;
        }

        Integer primary = cfgHic.getPrimaryCfg();
        List<String> list = cfgDao.getVeranstaltersWithActiveHubOrCacheByCfg(primary == null ? cfgNr : primary);

        cfgHic.setVeranstalters(new LinkedHashSet<String>(list));
        HicContent hicConent = hicContentDao.readHicContent(cfgNr);
        cfgHic.setHicContent(hicConent);

        return cfgHic;
    }

    @Transactional(propagation = Propagation.NOT_SUPPORTED, readOnly = true)
    public String getCfgTouroperator(final int cfgNr) {
        int cfg = cfgNr;
        Object[] statusAndPrimary = cfgDao.getCfgStatusAndPrimary(cfg);

        JsonObject rtnJson = new JsonObject();
        JsonObject jsonTouroperator = new JsonObject();
        JsonArray jsonArray = new JsonArray();
        jsonTouroperator.add("touroperator", jsonArray);
        rtnJson.add("touroperatorslist", jsonTouroperator);

        // cfg is active
        if (statusAndPrimary[0] != null && (Boolean) statusAndPrimary[0]) {
            if (statusAndPrimary[1] != null) {
                // cfg has primary_cfg
                cfg = (int) statusAndPrimary[1];
            }

            Set<TourOperator> cfgOps = cfgDao.getCfgTouroperator(cfg);
            for (TourOperator op : cfgOps) {
                JsonObject opJson = new JsonObject();
                opJson.addProperty("activecache", op.getCache() ? 1 : 0);
                opJson.addProperty("activehub", op.getHub() ? 1 : 0);
                opJson.addProperty("va", op.getTourop());
                opJson.addProperty("va", op.getTourop());
                opJson.addProperty("vaname", op.getTouropName());
                jsonArray.add(opJson);
            }
        }

        return rtnJson.toString();
    }

    @Transactional(propagation = Propagation.NOT_SUPPORTED, readOnly = true)
    public String getCfgTouroperator() {
        ListMultimap<Integer, TourOperator> cfgOp = cfgDao.getCfgTouroperator();

        JsonArray cfgJsonArray = new JsonArray();
        Set<Integer> keySet = cfgOp.keySet();
        Iterator<Integer> keyIterator = keySet.iterator();
        while (keyIterator.hasNext()) {
            Integer key = keyIterator.next();
            JsonObject jsonCfgTourop = new JsonObject();
            jsonCfgTourop.addProperty("cfg", key);

            JsonArray jsonArray = new JsonArray();
            List<TourOperator> values = cfgOp.get(key);
            for (TourOperator op : values) {
                JsonObject opJson = new JsonObject();
                opJson.addProperty("activecache", op.getCache() ? 1 : 0);
                opJson.addProperty("activehub", op.getHub() ? 1 : 0);
                opJson.addProperty("va", op.getTourop());
                opJson.addProperty("va", op.getTourop());
                opJson.addProperty("vaname", op.getTouropName());
                jsonArray.add(opJson);
            }

            jsonCfgTourop.add("touroperator", jsonArray);
            cfgJsonArray.add(jsonCfgTourop);
        }
        JsonObject rtnJson = new JsonObject();
        rtnJson.add("touroperatorslist", cfgJsonArray);

        return rtnJson.toString();
    }

}
