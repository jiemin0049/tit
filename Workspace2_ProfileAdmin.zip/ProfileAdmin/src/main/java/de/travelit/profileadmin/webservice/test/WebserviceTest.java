package de.travelit.profileadmin.webservice.test;

import de.travelit.profileadmin.webservice.client.CfgMixerList;
import de.travelit.profileadmin.webservice.client.MixerWebService;
import de.travelit.profileadmin.webservice.client.MixerWebServiceImplService;

public class WebserviceTest {
    public static void main(String[] args) {
        MixerWebServiceImplService service = new MixerWebServiceImplService();
        MixerWebService mixer = service.getMixerWebServiceImplPort();
        String hi = mixer.sayHi("jz");
        System.out.println(hi);

        System.out.println("-----------------------------------------------------");

        CfgMixerList cfgMixerList = mixer.getCfgs();
        System.out.println(cfgMixerList.getCfg().size());

        cfgMixerList = mixer.getCfgsWithMixerType("101");
        System.out.println(cfgMixerList.getCfg().size());
    }
}
