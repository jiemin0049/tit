package de.travelit.profileadmin.task;

import java.util.TimerTask;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.context.support.SpringBeanAutowiringSupport;

import de.travelit.profileadmin.service.audit.ProtokollService;

public class BackupAndCleanProtokollTask extends TimerTask {
    private static BackupAndCleanProtokollTask instance = new BackupAndCleanProtokollTask();

    // Days of protokoll to keep.
    private int maxDays;

    //Protokolls saving directory
    private String dir;

    @Autowired
    private ProtokollService protokollService;

    private BackupAndCleanProtokollTask() {
        SpringBeanAutowiringSupport.processInjectionBasedOnCurrentContext(this);
    }

    public static BackupAndCleanProtokollTask getInstance() {
        return instance;
    }

    public void setMaxDays(int days) {
        this.maxDays = days;
    }

    public void setDirectory(String dir) {
        this.dir = dir;
    }

    @Override
    public void run() {
        protokollService.backupAndCleanProtokoll(maxDays, dir);
    }
}
