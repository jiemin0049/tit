package de.travelit.profileadmin;

import java.util.HashMap;
import java.util.Map;

import com.google.common.base.Splitter;
import com.google.common.base.Splitter.MapSplitter;

/**
 *
 * @author zhang
 */
public final class Constants {

    public static final String SESSION_KEY_AUTHENTICITY = "authenticity";

    public static final String BACK_SLASH = "/";
    public static final String COMMA = ",";
    public static final String COLON = ":";
    public static final String UNDER_LINE = "_";
    public static final String AND = "&";

    /** minute */
    public static final int DEFAULT_PERIOD = 15;
    public static final String DEFAULT_ONLINETILL = "23:59/23:59/23:59";

    public static final String PROPERTIES_FILE = "d:/profileadmin/profileadmin.properties";
    public static final String PROFILE_PERIOD = "profile_period";
    public static final String PROFILE_INI = "profile_ini";

    public static final String PROTOKOLL_DIR = "protokoll_dir";
    public static final String PROTOKOLL_PERIOD = "protokoll_period";
    public static final String PROTOKOLL_FILENAME = "Protokoll";
    public static final String PROTOKOLL_MAXDAYS = "protokoll_maxdays";
    public static final String DOT_CSV = ".csv";
    public static final long TEN_MB = 10 * 1024 * 1024;

    public static final String REQUEST_FROM_AJAX = "from_ajax";

    public static final String HOST = System.getProperty("mail_host").trim();
    public static final String SMTP_PORT = System.getProperty("smtp_port").trim();
    public static final String RECIEVER = System.getProperty("reciever").trim();

    public static final String HIC_PUSH = System.getProperty("hic_push").trim();
    public static final String VERANSTALTER_PUSH = System.getProperty("veranstalter_push").trim();
    public static final String UPDATEHUB_PUSH = System.getProperty("updatehub_push").trim();
    public static final String UPDATEMIXER_PUSH = System.getProperty("updatemixer_push").trim();

    public static final Splitter ON_BACKSLASH = Splitter.on(BACK_SLASH).trimResults();
    public static final Splitter ON_BACKSLASH_OMITEMPTY = Splitter.on(BACK_SLASH).trimResults().omitEmptyStrings();
    public static final Splitter ON_COMMA_OMITEMPTY = Splitter.on(COMMA).trimResults().omitEmptyStrings();
    public static final Splitter ON_AND_OMITEMPTY = Splitter.on(AND).trimResults().omitEmptyStrings();
    public static final Splitter ON_UNDERLINE_OMITEMPTY = Splitter.on(UNDER_LINE).trimResults().omitEmptyStrings();

    public static final MapSplitter BACKSLASH_UNDERLINE_SPLITTER = Constants.ON_BACKSLASH_OMITEMPTY
            .withKeyValueSeparator(Constants.UNDER_LINE);
    public static final MapSplitter HOTELO_DEST_SPLITTER = Constants.ON_BACKSLASH_OMITEMPTY
            .withKeyValueSeparator(Constants.COLON);

    public static boolean isInteger(final String self) {
        if (null == self) {
            return false;
        }

        try {
            Integer.valueOf(self.trim());
            return true;
        } catch (NumberFormatException nfe) {
            return false;
        }
    }

    // Ticket 9050
    public static final Map<Integer, Integer> BCH_SERVICE_CHARGE = new HashMap<>();
    static {
        BCH_SERVICE_CHARGE.put(0, 0);
        BCH_SERVICE_CHARGE.put(5, 6);
        BCH_SERVICE_CHARGE.put(10, 13);
        BCH_SERVICE_CHARGE.put(15, 19);
        BCH_SERVICE_CHARGE.put(20, 25);
        BCH_SERVICE_CHARGE.put(25, 30);
        BCH_SERVICE_CHARGE.put(30, 35);
        BCH_SERVICE_CHARGE.put(35, 40);
    }
}
