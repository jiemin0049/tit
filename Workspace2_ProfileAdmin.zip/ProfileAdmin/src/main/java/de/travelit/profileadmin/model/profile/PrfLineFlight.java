package de.travelit.profileadmin.model.profile;

public class PrfLineFlight {
    private int cfg;
    private String tourop;
    private int lfshort;
    private int lfmiddle;
    private int lflong;

    public int getCfg() {
        return cfg;
    }

    public void setCfg(int cfg) {
        this.cfg = cfg;
    }

    public String getTourop() {
        return tourop;
    }

    public void setTourop(String tourop) {
        this.tourop = tourop;
    }

    public int getLfshort() {
        return lfshort;
    }

    public void setLfshort(int lfshort) {
        this.lfshort = lfshort;
    }

    public int getLfmiddle() {
        return lfmiddle;
    }

    public void setLfmiddle(int lfmiddle) {
        this.lfmiddle = lfmiddle;
    }

    public int getLflong() {
        return lflong;
    }

    public void setLflong(int lflong) {
        this.lflong = lflong;
    }

}
