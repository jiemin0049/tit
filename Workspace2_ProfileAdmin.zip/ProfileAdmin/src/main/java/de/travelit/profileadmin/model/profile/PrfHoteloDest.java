package de.travelit.profileadmin.model.profile;

public class PrfHoteloDest {
    private int cfg;
    private String dest3lc;
    private int percentageLow;
    private int percentageMiddle;
    private int percentageHigh;

    public int getCfg() {
        return cfg;
    }

    public void setCfg(int cfg) {
        this.cfg = cfg;
    }

    public String getDest3lc() {
        return dest3lc;
    }

    public void setDest3lc(String dest3lc) {
        this.dest3lc = dest3lc;
    }

    public int getPercentageLow() {
        return percentageLow;
    }

    public void setPercentageLow(int percentageLow) {
        this.percentageLow = percentageLow;
    }

    public int getPercentageMiddle() {
        return percentageMiddle;
    }

    public void setPercentageMiddle(int percentageMiddle) {
        this.percentageMiddle = percentageMiddle;
    }

    public int getPercentageHigh() {
        return percentageHigh;
    }

    public void setPercentageHigh(int percentageHigh) {
        this.percentageHigh = percentageHigh;
    }

}
