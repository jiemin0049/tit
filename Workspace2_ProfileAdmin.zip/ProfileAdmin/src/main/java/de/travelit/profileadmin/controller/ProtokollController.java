package de.travelit.profileadmin.controller;

import java.io.IOException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.google.gson.ExclusionStrategy;
import com.google.gson.FieldAttributes;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import de.travelit.profileadmin.model.Protokoll;
import de.travelit.profileadmin.model.ProtokollSearch;
import de.travelit.profileadmin.service.audit.ProtokollService;

@Controller
public class ProtokollController {

    private static final int PROTOKOLL_MAX_SHOW = 5000;

    @Autowired
    private ProtokollService protokollService;

    @RequestMapping("begin_log_page")
    public String beginLogPage() {
        return "log_page";
    }

    @RequestMapping("start_search_log")
    public String startSearchLog(final ProtokollSearch search, Model model) throws IOException {
        List<Protokoll> protokollList = protokollService.search(search, PROTOKOLL_MAX_SHOW + 1);
        Gson gson = new GsonBuilder().serializeNulls().disableHtmlEscaping().setExclusionStrategies(new ExclusionStrategy() {
            @Override
            public boolean shouldSkipField(FieldAttributes f) {
                // I don't want 'id' and 'pk3' in json.
                if (f.getName().equals("id") || f.getName().equals("pk3")) {
                    return true;
                }
                return false;
            }

            @Override
            public boolean shouldSkipClass(Class<?> clazz) {
                return false;
            }
        }).create();
        String json = "";
        if (protokollList.size() > PROTOKOLL_MAX_SHOW) {
            protokollList.remove(PROTOKOLL_MAX_SHOW);
            json = gson.toJson(protokollList);
            String msg = "Achtung: Da mehr als " + PROTOKOLL_MAX_SHOW + " Datensätze des Protokolls gefunden sind, werden nur die ersten " + PROTOKOLL_MAX_SHOW
                    + " Datensätze in der Tabelle angezeigt!";
            model.addAttribute("limit", msg);
        } else {
            json = gson.toJson(protokollList);
        }
        model.addAttribute("jsonValue", json);
        return "log_datatables";
    }

}
