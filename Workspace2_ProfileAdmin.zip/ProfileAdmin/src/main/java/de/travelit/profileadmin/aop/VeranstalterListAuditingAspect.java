package de.travelit.profileadmin.aop;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.log4j.Logger;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.beans.factory.annotation.Autowired;

import de.travelit.profileadmin.service.VeranstalterListService;
import de.travelit.profileadmin.service.audit.VeranstalterListAuditService;

/**
 * Audit database table changing. Class audits only for delete and insert
 * records of tables. Table updating is audited by db trigger.
 *
 * @author zhang
 *
 */
@Aspect
public class VeranstalterListAuditingAspect extends DataAuditingAspect {

    private static final Logger LOGGER = Logger.getLogger(VeranstalterListAuditingAspect.class);

    @Autowired
    private VeranstalterListAuditService veranstalterListAuditService;

    @Autowired
    private VeranstalterListService vaListService;

    public VeranstalterListAuditingAspect() {
        super();
    }

    @After(value = "execution(* de.travelit.profileadmin.service.VeranstalterListService.insertValist(..)) && args(code,..,vacodeArray)")
    public void createValistAdvice(String code, String[] vacodeArray) {
        veranstalterListAuditService.logCreateValist(getAuthName(), code, vacodeArray);
    }

    @After(value = "args(code) && execution(* de.travelit.profileadmin.service.VeranstalterListService.removeFromValist(..))")
    public void removeValistAdvice(String code) {
        veranstalterListAuditService.logRemoveValist(getAuthName(), code);
    }

    @Around(value = "execution(* de.travelit.profileadmin.service.VeranstalterListService.updateValist(..)) && args(code, newVacodesArray)")
    public void updateOperatorsFromValistAdvice(ProceedingJoinPoint joinPoint, String code, String[] newVacodesArray) {
        List<String> oldVacodes = vaListService.getOperatorsFor(code);
        try {
            joinPoint.proceed();
        } catch (Throwable e) {
            LOGGER.fatal("Log clear operators failed!!!!", e);
        }

        List<String> newVacodes = new ArrayList<>();
        if (newVacodesArray != null) {
            newVacodes = Arrays.asList(newVacodesArray);
        }

        if (newVacodes.containsAll(oldVacodes) && oldVacodes.containsAll(newVacodes)) {
            return;
        }
        veranstalterListAuditService.logUpdateOperatorsFromValist(getAuthName(), code, oldVacodes, newVacodes);
    }
}
