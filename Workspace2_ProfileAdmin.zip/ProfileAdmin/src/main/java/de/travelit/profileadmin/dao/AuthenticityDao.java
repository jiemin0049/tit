package de.travelit.profileadmin.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowCallbackHandler;
import org.springframework.stereotype.Repository;

import de.travelit.profileadmin.model.Authenticity;

@Repository
public class AuthenticityDao {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    public Authenticity getAuthenticity(String id, String password) {
        String sqlStr = "SELECT * FROM authenticity WHERE name =? and password=?";
        final Authenticity authenticity = new Authenticity();

        jdbcTemplate.query(sqlStr, new Object[] { id, password }, new RowCallbackHandler() {
            @Override
            public void processRow(ResultSet rs) throws SQLException {
                authenticity.setName(rs.getString("NAME"));
                authenticity.setRoleId(Integer.parseInt(rs.getString("ROLE_ID").trim()));
            }
        });
        return authenticity;
    }
}
