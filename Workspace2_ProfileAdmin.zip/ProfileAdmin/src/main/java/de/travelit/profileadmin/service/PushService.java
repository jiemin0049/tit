package de.travelit.profileadmin.service;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import de.travelit.profileadmin.Constants;
import de.travelit.profileadmin.dao.PushDao;

/**
 * Push notification if some tables are modified.
 *
 * @author zhang
 */
@Service
public class PushService {

    private static final Logger LOGGER = Logger.getLogger(PushService.class);

    @Autowired
    private PushDao pushDao;

    public void pushHubvaModifyNotification() {
        String key = "hubva";
        boolean b = pushDao.getStatus(key);
        if (b) {
            LOGGER.info("Begin to push update HUB!");
            pushDao.setStatus(key, false);
            ServiceUtils.sendRequest(Constants.UPDATEHUB_PUSH);
        }
    }

    public void pushTouroperatorModifyNotification() {
        String key = "touroperator";
        boolean b = pushDao.getStatus(key);
        if (b) {
            LOGGER.info("Begin to push update touroperator!");
            pushDao.setStatus(key, false);
            ServiceUtils.sendRequest(Constants.VERANSTALTER_PUSH);
        }
    }

    public void pushMixerModifyNotification() {
        String key = "mixer";
        boolean b = pushDao.getStatus(key);
        if (b) {
            LOGGER.info("Begin to push update mixer!");
            pushDao.setStatus(key, false);
            ServiceUtils.sendRequest(Constants.UPDATEMIXER_PUSH);
        }
    }

}
