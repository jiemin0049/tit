package de.travelit.profileadmin.model;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "LMWEB")
@XmlAccessorType(XmlAccessType.NONE)
public class Hubva {

    @XmlElement(name = "PAGE")
    private String page = "HUBVA";

    private List<String> hubvaList = new ArrayList<String>();

    @XmlElement(name = "HUB_VA")
    public List<String> getHubvaList() {
        return hubvaList;
    }

    public void setHubvaList(List<String> hubvaList) {
        this.hubvaList = hubvaList;
    }

    public String getPage() {
        return page;
    }

    public void setPage(String page) {
        this.page = page;
    }
}
