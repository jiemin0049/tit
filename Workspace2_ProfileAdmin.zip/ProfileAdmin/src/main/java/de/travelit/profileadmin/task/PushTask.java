package de.travelit.profileadmin.task;

import java.util.TimerTask;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import de.travelit.profileadmin.service.PushService;

@Component
public class PushTask extends TimerTask {

    @Autowired
    private PushService pushService;

    public PushTask() {
    }

    @Override
    public void run() {
        pushService.pushHubvaModifyNotification();
        pushService.pushTouroperatorModifyNotification();
        pushService.pushMixerModifyNotification();
    }

}