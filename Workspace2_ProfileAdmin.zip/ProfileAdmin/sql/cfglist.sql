CREATE TABLE cfglist(
   --cfg       SERIAL PRIMARY KEY NOT NULL,
   cfg       int PRIMARY KEY NOT NULL,
   status    boolean NOT NULL default true, --0: inaktiv, 1:produktiv
   primary_cfg   int,
   licence_validto  date NOT NULL default '2044-12-31',
   name      varchar(50) NOT NULL,
   affiliates boolean NOT NULL default true,
   maxdays   int default 56,
   xpwp      varchar(10) NOT NULL,
   debitorennummer varchar(10) NOT NULL,
   bumaagency  varchar(5) NOT NULL,
   terminal  varchar(5) NOT NULL,
   password  varchar(10) NOT NULL,
   terminalweb varchar(5) NOT NULL,
   passwortweb varchar(10) NOT NULL,
   Email varchar(120),
   onrequest boolean default false, --Deprecated, always false
   insurance int default 0, -- 0: ohne, 1: ERV, 4: ELVIA, 8: HANSE
   configmode int default 3, -- Deprecated, always 3
   tui_agencynumber varchar(10),
   online_till varchar(20),
   online      int default 0, -- 0: inaktiv, 3: Buchung, 2: Nur Option, 1: Option & Buchung
   agencynumber varchar(15), --Deprecated, always ""
   inkasso varchar(20),  -- Deprecated
   from_min int default 1,
   from_min1 varchar(4) default '0',
   book_to int default 1,
   ota_gtc TEXT,
   max_pricediff int default 25,
   opcontrol boolean default false,
   hotelinfocenter boolean default true, -- 0: deaktiviert, 1: aktiviert
   reviews boolean default true, -- Bewertungen aktiv / inaktiv
   reviewprovider int default 1, -- 1: Holidaycheck, 2:TripAdvisor
   GIATA_ihg_uid varchar(10),
   GIATA_xmluser varchar(10),
   GIATA_xmlpwd  varchar(10),
   layoutid    int default 2,
   comment TEXT,
   lastupdate date default CURRENT_DATE,
   update_by varchar(255) NOT NULL,
   ------mixer----
   xsl varchar(1024),
   email_admin varchar(255),
   vc_hub varchar(255),
   cache_source varchar(1024),
   rating int default 1,  -- 0 or 1
   facetcount int default 0,  -- 0 or 1
   ratingname varchar(50),
   mixer int NOT NULL default 0, -- 1-7 binary 001, 010, 011, .... stage, prod, lmp
   hubpriority boolean default false
);

CREATE OR REPLACE FUNCTION cfglist_insert_func() RETURNS TRIGGER AS $$
BEGIN
    INSERT INTO protokoll(datetime, operation, tabelle, field, pk1, new_value, update_by)
           VALUES(now(), TG_OP, TG_TABLE_NAME, 'cfg', NEW.cfg, NEW.name, NEW.update_by);
    RETURN NEW;
END;
$$  LANGUAGE plpgsql;

CREATE TRIGGER cfglist_insert_tg
  AFTER INSERT ON cfglist
  FOR EACH ROW
  EXECUTE PROCEDURE cfglist_insert_func();
