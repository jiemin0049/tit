CREATE TABLE protokoll (
   id        BIGSERIAL PRIMARY KEY NOT NULL,
   datetime  TEXT NOT NULL DEFAULT now(),
   operation   varchar(10) NOT NULL,
   tabelle   varchar(50) NOT NULL,
   field     varchar(50),
   pk1       varchar(20),
   pk2       varchar(20),
   pk3       varchar(20), -- reserved
   old_value TEXT,
   new_value TEXT,
   update_by varchar(255) NOT NULL
);