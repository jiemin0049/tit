CREATE TABLE va_aktiv_cfgs(
   cfg       int  references cfglist(cfg)  NOT NULL,
   tourop    varchar(4)  references touroperator(tourop) NOT NULL,
   active    boolean default false,
   bookonline  boolean default false,
   lastupdate  date default CURRENT_DATE,
   update_by varchar(255),
   PRIMARY KEY(cfg, tourop)
);