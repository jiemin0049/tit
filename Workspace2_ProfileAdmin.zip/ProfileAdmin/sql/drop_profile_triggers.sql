-- drop triggers which are for writing Profile.ini
SELECT * FROM pg_trigger;

DROP TRIGGER cfglist_profile_trigger  ON cfglist;

DROP TRIGGER hotelocalc_profile_trigger ON hotelocalc;

DROP TRIGGER hotelodest_profile_trigger ON hotelodest;

DROP TRIGGER servicecharges_cfg_profile_trigger ON servicecharges_cfg;

DROP TRIGGER lineflight_cfg_profile_trigger ON lineflight_cfg;

DROP TRIGGER va_aktiv_cfgs_profile_trigger ON va_aktiv_cfgs;

DROP TRIGGER valist_cfg_profile_trigger ON valist_cfg;

--DROP TRIGGER touroperator_trigger ON touroperator;

--DROP TRIGGER touroplist_trigger ON touroplist;

--DROP TRIGGER valist_trigger ON valist;

DROP FUNCTION profilelogfunc();