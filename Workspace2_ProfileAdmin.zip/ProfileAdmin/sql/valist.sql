CREATE TABLE valist (

  code varchar(2) references touroplist(code) NOT NULL,

  vacode varchar(4) references touroperator(tourop) NOT NULL,

  PRIMARY KEY (code, vacode)

);