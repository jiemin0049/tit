-- If tables(cfglist, hotelocalc, valist_cfg...) are modified (remove, update, insert), lastupdate change to 'true'
-- Profile.ini writer checks this flag. This table also saves flags for push information.
CREATE TABLE profile_update (
    id varchar PRIMARY KEY NOT NULL,
    lastupdate boolean NOT NULL default true
);

-- if 'hubva' is true, tell(push notification to) mixer that hubs of op are changed.
-- if touroperator is true, tell(push notification to) hic3-backend that ops are changed.
INSERT INTO profile_update(id, lastupdate) VALUES ('profile', false), ('hubva', false), ('touroperator', false), ('mixer', false);

--------------------------------- Triggers ---------------------------------------------------------

--change flag of table row 'profile' in table profile_update
CREATE OR REPLACE FUNCTION profilelogfunc() RETURNS TRIGGER AS $$
    BEGIN
        UPDATE profile_update SET lastupdate=true WHERE id='profile';
        RETURN NEW;
    END;
$$ LANGUAGE plpgsql;

--change flag of table row 'mixer' in table profile_update
CREATE OR REPLACE FUNCTION pushmixer() RETURNS TRIGGER AS $$
    BEGIN
        UPDATE profile_update SET lastupdate=true WHERE id='mixer';
        RETURN NEW;
    END;
$$ LANGUAGE plpgsql;

--Change flag of table row 'hubva' in profile_update, when active(in table va_aktiv_cfgs) is changed.
CREATE OR REPLACE FUNCTION pushhubva() RETURNS TRIGGER AS $$
    BEGIN
        IF TG_OP = 'DELETE' OR TG_OP = 'INSERT' OR OLD.active<>NEW.active THEN
            UPDATE profile_update SET lastupdate=true WHERE id='hubva';
        END IF;
        RETURN null;
    END;
$$ LANGUAGE plpgsql;

--Change flag of table rows 'hubva' and 'profile' in profile_update, when source_cache or source_hub (in operator) is changed.
CREATE OR REPLACE FUNCTION pushhubva2() RETURNS TRIGGER AS $$
    BEGIN
        IF TG_OP = 'DELETE' OR TG_OP = 'INSERT' OR OLD.source_cache<>NEW.source_cache OR OLD.source_hub<>NEW.source_hub OR OLD.active<>NEW.active THEN
            UPDATE profile_update SET lastupdate=true WHERE id='hubva';
            UPDATE profile_update SET lastupdate=true WHERE id='profile';
        END IF;
        RETURN null;
    END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION pushtouroperator() RETURNS TRIGGER AS $$
    BEGIN
        UPDATE profile_update SET lastupdate=true WHERE id=TG_ARGV[0];
        RETURN NEW;
    END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER cfglist_profile_trigger AFTER INSERT OR DELETE OR UPDATE ON cfglist
FOR EACH ROW EXECUTE PROCEDURE profilelogfunc();

CREATE TRIGGER cfglist_mixer_trigger AFTER INSERT OR DELETE OR UPDATE ON cfglist
FOR EACH ROW EXECUTE PROCEDURE pushmixer();

CREATE TRIGGER hotelocalc_profile_trigger AFTER INSERT OR DELETE OR UPDATE ON hotelocalc
FOR EACH ROW EXECUTE PROCEDURE profilelogfunc();

CREATE TRIGGER hotelodest_profile_trigger AFTER INSERT OR DELETE OR UPDATE ON hotelodest
FOR EACH ROW EXECUTE PROCEDURE profilelogfunc();

CREATE TRIGGER servicecharges_cfg_profile_trigger AFTER INSERT OR DELETE OR UPDATE ON servicecharges_cfg
FOR EACH ROW EXECUTE PROCEDURE profilelogfunc();

CREATE TRIGGER lineflight_cfg_profile_trigger AFTER INSERT OR DELETE OR UPDATE ON lineflight_cfg
FOR EACH ROW EXECUTE PROCEDURE profilelogfunc();

CREATE TRIGGER va_aktiv_cfgs_profile_trigger AFTER INSERT OR DELETE OR UPDATE ON va_aktiv_cfgs
FOR EACH ROW EXECUTE PROCEDURE profilelogfunc();

CREATE TRIGGER hubva_push_trigger AFTER INSERT OR DELETE OR UPDATE ON va_aktiv_cfgs
FOR EACH ROW EXECUTE PROCEDURE pushhubva();

CREATE TRIGGER hubva_push_trigger AFTER INSERT OR DELETE OR UPDATE ON touroperator
FOR EACH ROW EXECUTE PROCEDURE pushhubva2();

CREATE TRIGGER va_aktiv_cfgs_push_trigger AFTER INSERT OR DELETE OR UPDATE ON va_aktiv_cfgs
FOR EACH ROW EXECUTE PROCEDURE pushtouroperator('touroperator');

CREATE TRIGGER valist_cfg_profile_trigger AFTER INSERT OR DELETE OR UPDATE ON valist_cfg
FOR EACH ROW EXECUTE PROCEDURE profilelogfunc();

CREATE TRIGGER touroperator_push_tg AFTER INSERT OR DELETE OR UPDATE ON touroperator
FOR EACH ROW EXECUTE PROCEDURE pushtouroperator('touroperator');

--CREATE TRIGGER touroplist_profile_trigger AFTER INSERT OR DELETE OR UPDATE ON touroplist
--FOR EACH ROW EXECUTE PROCEDURE profilelogfunc();

--CREATE TRIGGER valist_profile_trigger AFTER INSERT OR DELETE OR UPDATE ON valist
--FOR EACH ROW EXECUTE PROCEDURE profilelogfunc();