CREATE TABLE touroplist (

  code varchar(2) NOT NULL PRIMARY KEY,

  name varchar(30) NOT NULL,

  update_by varchar(255)

);


CREATE OR REPLACE FUNCTION touroplist_update_name_func() RETURNS TRIGGER AS $$
BEGIN
    IF NEW.name <> OLD.name THEN
        INSERT INTO protokoll(datetime, operation, tabelle, field, pk1, old_value, new_value, update_by)
               VALUES(now(), TG_OP, TG_TABLE_NAME, 'name', NEW.code, OLD.name, NEW.name, NEW.update_by);
    END IF;
    RETURN NEW;
END;
$$  LANGUAGE plpgsql;


CREATE TRIGGER touroplist_update_name_tg
    AFTER UPDATE ON touroplist
    FOR EACH ROW
    WHEN (OLD.name IS DISTINCT FROM NEW.name)
    EXECUTE PROCEDURE touroplist_update_name_func();
