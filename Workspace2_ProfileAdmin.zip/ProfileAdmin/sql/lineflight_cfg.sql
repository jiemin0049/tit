CREATE TABLE lineflight_cfg(
   cfg       int  references cfglist(cfg)  NOT NULL,
   tourop    varchar(4)  references touroperator(tourop) NOT NULL,
   lf_short  int default 30,
   lf_middle  int default 40,
   lf_long  int default 50,
   update_by varchar(255),
   PRIMARY KEY(cfg, tourop)
);