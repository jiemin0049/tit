CREATE TABLE role (
   id int PRIMARY KEY,
   name TEXT NOT NULL
);

INSERT INTO role (id, name) VALUES (1, 'Travel-IT-Reiseb�ro'),(2, 'Reiseketten-Admin'),(4,'Gruppen-Admin'),(8,'Reiseb�roleiter'),(16,'Expedient');