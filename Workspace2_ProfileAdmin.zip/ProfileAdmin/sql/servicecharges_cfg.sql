CREATE TABLE servicecharges_cfg(
   cfg       int  references cfglist(cfg)  NOT NULL,
   tourop    varchar(4)  references touroperator(tourop) NOT NULL,
   sc_short  int default 10,
   sc_middle  int default 20,
   sc_long  int default 30,
   update_by varchar(255),
   PRIMARY KEY(cfg, tourop)
);