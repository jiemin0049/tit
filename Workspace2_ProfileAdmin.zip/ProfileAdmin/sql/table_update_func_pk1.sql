CREATE OR REPLACE FUNCTION table_update_func_pk1() RETURNS trigger AS $$
DECLARE
    ri RECORD;
    old_value TEXT;
    new_value TEXT;
BEGIN
    FOR ri IN
        SELECT column_name FROM information_schema.columns
        WHERE
            table_schema = quote_ident('public')
        AND table_name = quote_ident(TG_TABLE_NAME)
        ORDER BY ordinal_position
    LOOP
        EXECUTE 'SELECT ($1).' || ri.column_name || '::text' INTO new_value USING NEW;
        EXECUTE 'SELECT ($1).' || ri.column_name || '::text' INTO old_value USING OLD;

        IF new_value IS DISTINCT FROM old_value AND ri.column_name != 'update_by' THEN
            INSERT INTO protokoll(datetime, operation, tabelle, field, pk1, old_value, new_value, update_by)
                   VALUES(now(), TG_OP, TG_TABLE_NAME, ri.column_name, NEW.cfg, old_value, new_value, NEW.update_by);
       END IF;
    END LOOP;
    RETURN NEW;
END;
$$  LANGUAGE plpgsql;


CREATE TRIGGER cfglist_update_tg
  AFTER UPDATE ON cfglist
  FOR EACH ROW
  EXECUTE PROCEDURE table_update_func_pk1();

CREATE TRIGGER hotelocalc_update_tg
  AFTER UPDATE ON hotelocalc
  FOR EACH ROW
  EXECUTE PROCEDURE table_update_func_pk1();

CREATE TRIGGER hiccontent_update_tg
  AFTER UPDATE ON hiccontent
  FOR EACH ROW
  EXECUTE PROCEDURE table_update_func_pk1();